<?php
/**
 * Quiz Bank Menu Configuration Class
 * 
 * Handles loading and providing menu structure from JSON configuration
 */

class QuizBankMenuConfig {
    
    private $menu_data;
    private static $instance = null;
    
    /**
     * Singleton instance
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor - Load menu data from JSON
     */
    private function __construct() {
        $this->load_menu_data();
    }
    
    /**
     * Load menu data from JSON file
     */
    private function load_menu_data() {
        $json_file = QUIZ_BANK_PLUGIN_DIR . 'menu.json';
        
        if (file_exists($json_file)) {
            $json_content = file_get_contents($json_file);
            $this->menu_data = json_decode($json_content, true);
            
            if (json_last_error() !== JSON_ERROR_NONE) {
                error_log('Quiz Bank: JSON decode error in menu.json - ' . json_last_error_msg());
                $this->menu_data = $this->get_default_menu_data();
            }
        } else {
            error_log('Quiz Bank: menu.json file not found, using default structure');
            $this->menu_data = $this->get_default_menu_data();
        }
    }
    
    /**
     * Get default menu data if JSON file is not available
     */
    private function get_default_menu_data() {
        return array(
            'grades' => array(
                '12' => array(
                    'name' => 'Toán 12',
                    'chapters' => array(
                        '1' => array(
                            'name' => 'Chương 1: Ứng dụng đạo hàm',
                            'lessons' => array(
                                '1' => array(
                                    'name' => 'Bài 1: Sự đồng biến, nghịch biến',
                                    'types' => array(
                                        '1' => 'Dạng 1: Xét tính đơn điệu',
                                        '2' => 'Dạng 2: Tìm khoảng đơn điệu',
                                        '3' => 'Dạng 3: Tham số m'
                                    )
                                )
                            )
                        )
                    )
                )
            ),
            'categories' => array('Nhận biết', 'Thông hiểu', 'Vận dụng', 'Vận dụng cao')
        );
    }
    
    /**
     * Get all grades
     */
    public function get_grades() {
        return isset($this->menu_data['grades']) ? array_keys($this->menu_data['grades']) : array();
    }
    
    /**
     * Get grade name
     */
    public function get_grade_name($grade) {
        return isset($this->menu_data['grades'][$grade]['name']) ? 
               $this->menu_data['grades'][$grade]['name'] : 
               'Toán ' . $grade;
    }
    
    /**
     * Get chapters by grade
     */
    public function get_chapters_by_grade($grade) {
        if (!isset($this->menu_data['grades'][$grade]['chapters'])) {
            return array();
        }
        
        return array_keys($this->menu_data['grades'][$grade]['chapters']);
    }
    
    /**
     * Get chapter name
     */
    public function get_chapter_name($grade, $chapter) {
        return isset($this->menu_data['grades'][$grade]['chapters'][$chapter]['name']) ?
               $this->menu_data['grades'][$grade]['chapters'][$chapter]['name'] :
               'Chương ' . $chapter;
    }
    
    /**
     * Get lessons by grade and chapter
     */
    public function get_lessons_by_grade_chapter($grade, $chapter) {
        if (!isset($this->menu_data['grades'][$grade]['chapters'][$chapter]['lessons'])) {
            return array();
        }
        
        return array_keys($this->menu_data['grades'][$grade]['chapters'][$chapter]['lessons']);
    }
    
    /**
     * Get lesson name
     */
    public function get_lesson_name($grade, $chapter, $lesson) {
        return isset($this->menu_data['grades'][$grade]['chapters'][$chapter]['lessons'][$lesson]['name']) ?
               $this->menu_data['grades'][$grade]['chapters'][$chapter]['lessons'][$lesson]['name'] :
               'Bài ' . $lesson;
    }
    
    /**
     * Get types by grade, chapter and lesson
     */
    public function get_types_by_grade_chapter_lesson($grade, $chapter, $lesson) {
        if (!isset($this->menu_data['grades'][$grade]['chapters'][$chapter]['lessons'][$lesson]['types'])) {
            return array();
        }
        
        return array_keys($this->menu_data['grades'][$grade]['chapters'][$chapter]['lessons'][$lesson]['types']);
    }
    
    /**
     * Get type name
     */
    public function get_type_name($grade, $chapter, $lesson, $type) {
        return isset($this->menu_data['grades'][$grade]['chapters'][$chapter]['lessons'][$lesson]['types'][$type]) ?
               $this->menu_data['grades'][$grade]['chapters'][$chapter]['lessons'][$lesson]['types'][$type] :
               'Dạng ' . $type;
    }
    
    /**
     * Get all available categories
     */
    public function get_categories() {
        return isset($this->menu_data['categories']) ? $this->menu_data['categories'] : array();
    }
    
    /**
     * Get menu structure for a specific grade (for JavaScript)
     */
    public function get_grade_structure($grade) {
        if (!isset($this->menu_data['grades'][$grade])) {
            return array();
        }
        
        $structure = array();
        $chapters = $this->menu_data['grades'][$grade]['chapters'];
        
        foreach ($chapters as $chapter_id => $chapter_data) {
            $structure[$chapter_id] = array(
                'name' => $chapter_data['name'],
                'lessons' => array()
            );
            
            if (isset($chapter_data['lessons'])) {
                foreach ($chapter_data['lessons'] as $lesson_id => $lesson_data) {
                    $structure[$chapter_id]['lessons'][] = $lesson_id;
                }
            }
        }
        
        return $structure;
    }
    
    /**
     * Get full menu data for JavaScript
     */
    public function get_full_menu_data() {
        return $this->menu_data;
    }
    
    /**
     * Reload menu data (useful for development)
     */
    public function reload() {
        $this->load_menu_data();
    }
}