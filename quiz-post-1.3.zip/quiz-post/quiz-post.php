<?php
/*
Plugin Name: Quiz Display post
Plugin URI:
Description: Plugin hiển thị câu hỏi trắc nghiệm với tính năng tính điểm và xáo trộn
Version: 1.3
Author: Thay Do
*/

if (!defined('ABSPATH')) {
    exit;
}

// Kích hoạt plugin
register_activation_hook(__FILE__, 'quiz_display_activate');

function quiz_display_activate() {
    global $wpdb;

    // Thêm cài đặt mặc định
    add_option('quiz_display_settings', array(
        'shuffle_questions_single' => 'yes', // Giữ lại để tương thích, nhưng không dùng nữa
        'shuffle_options_single' => 'yes',   // Giữ lại để tương thích, nhưng không dùng nữa
    ));

    // Tạo bảng quiz_results
    $table_name = $wpdb->prefix . 'quiz_results';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        quiz_id VARCHAR(255) NOT NULL,
        score_part_1 DECIMAL(5,2) NOT NULL DEFAULT 0.00,
        score_part_2 DECIMAL(5,2) NOT NULL DEFAULT 0.00,
        score_part_3 DECIMAL(5,2) NOT NULL DEFAULT 0.00,
        total_score DECIMAL(5,2) NOT NULL DEFAULT 0.00,
        start_time DATETIME NOT NULL,
        end_time DATETIME NOT NULL,
        student_name VARCHAR(255) NOT NULL,
        post_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Enqueue scripts
function quiz_display_enqueue_scripts() {
    wp_enqueue_style('quiz-display-style', plugins_url('css/quiz-style.css', __FILE__));
    wp_enqueue_script('mathjs', 'https://math.booktoan.com/math.js', array(), null, true);
    wp_enqueue_script('quiz-display-script', plugins_url('js/quiz-script.js', __FILE__), array('jquery', 'mathjs'), '1.3', true);
    $settings = get_option('quiz_display_settings');
    wp_localize_script('quiz-display-script', 'quizDisplaySettings', $settings); // Giữ lại để tương thích, nhưng không dùng cho xáo trộn
    wp_localize_script('quiz-display-script', 'quizData', array(
        'postId' => get_the_ID(),
        'ajaxurl' => admin_url('admin-ajax.php')
    ));
}
add_action('wp_enqueue_scripts', 'quiz_display_enqueue_scripts');

// Hàm xử lý biến số
function replace_variables($text, &$variables) {
    return preg_replace_callback(
        '/\!([a-zA-Z0-9*]+)(?::(-?\d+):(-?\d+))?\!/',
        function($matches) use (&$variables) {
            $varName = $matches[1];
            $min = isset($matches[2]) ? (int)$matches[2] : -10;
            $max = isset($matches[3]) ? (int)$matches[3] : 10;

            $isNonZero = strpos($varName, '*0') !== false;
            $varName = str_replace('*0', '', $varName);

            if (!array_key_exists($varName, $variables)) {
                do {
                    $value = rand($min, $max);
                } while ($isNonZero && $value === 0);
                $variables[$varName] = $value;
            }

            return $variables[$varName];
        },
        $text
    );
}

// Làm đẹp biểu thức trong PHP
function process_variables_php($text, &$variables) {
    if (!is_string($text)) return $text;
    
    $text = preg_replace_callback(
        '/\!([a-zA-Z0-9]+(?:\*0)?)(?::(-?\d+):(-?\d+))?\!/',
        function($matches) use (&$variables) {
            $varName = $matches[1];
            $min = isset($matches[2]) ? (int)$matches[2] : -10;
            $max = isset($matches[3]) ? (int)$matches[3] : 10;
            $isNonZero = strpos($varName, '*0') !== false;
            $varName = str_replace('*0', '', $varName);
            
            if (!array_key_exists($varName, $variables)) {
                do {
                    $value = rand($min, $max);
                } while ($isNonZero && $value === 0);
                $variables[$varName] = $value;
            } else {
                $value = $variables[$varName];
            }
            
            return $value;
        },
        $text
    );
    
    if (substr($text, 0, 1) === '+') {
        $text = substr($text, 1);
    }
    
    $text = preg_replace_callback(
        '/([+-]?)(\d*\.?\d+)([x](?:\^?\d*)?(?:_[0-9]+)?)?/',
        function ($matches) {
            $sign = $matches[1] ?: '';
            $coefficient = (float)$matches[2];
            $xPart = $matches[3] ?? '';
            
            if ($coefficient == 0) {
                return '';
            }
            
            if ($coefficient < 0) {
                $sign = ($sign == '+') ? '-' : '+';
                $coefficient = abs($coefficient);
            }
            
            if ($xPart) {
                if ($coefficient == 1) {
                    return $sign . $xPart;
                } else {
                    return $sign . $coefficient . $xPart;
                }
            } else {
                if ($coefficient == 0) {
                    return "";
                }
                return $sign . $coefficient;
            }
        },
        $text
    );
    
    $text = str_replace('+-', '-', $text);
    
    if ($text == "=0") {
        $text = "0=0";
    } elseif (empty($text)) {
        $text = "0";
    }
    
    return $text;
}

// Shortcode cho bộ câu hỏi
function quiz_set_shortcode($atts, $content = null) {
    $atts = shortcode_atts(array(
        'type' => 'practice',
        'time' => 0,
        'single_choice_points' => 0.25,
        'true_false_points' => 0.25,
        'short_answer_points' => 0.5,
        'single_choice_tron' => 'y,y', // Mặc định xáo trộn cả câu hỏi và đáp án cho single-choice
        'true_false_tron' => 'y,y',    // Mặc định xáo trộn cả câu hỏi và đáp án cho true-false
        'short_answer_tron' => 'y'     // Mặc định xáo trộn câu hỏi cho short-answer
    ), $atts);

    $quiz_id = 'quiz_set_' . uniqid();
    $variables = array();
    $content = do_shortcode(shortcode_unautop($content));

    $quiz_class = ($atts['type'] === 'exam') ? 'quiz-set-exam' : 'quiz-set-practice';
    $post_title = get_the_title(get_the_ID());

    $output = '<div class="quiz-set ' . $quiz_class . '" id="' . $quiz_id . '" 
                data-type="' . esc_attr($atts['type']) . '" 
                data-time="' . intval($atts['time']) . '" 
                data-post-title="' . esc_attr($post_title) . '"
                data-single-choice-points="' . floatval($atts['single_choice_points']) . '"
                data-true-false-points="' . floatval($atts['true_false_points']) . '"
                data-short-answer-points="' . floatval($atts['short_answer_points']) . '"
                data-single-choice-tron="' . esc_attr($atts['single_choice_tron']) . '"
                data-true-false-tron="' . esc_attr($atts['true_false_tron']) . '"
                data-short-answer-tron="' . esc_attr($atts['short_answer_tron']) . '">';

    if ($atts['type'] === 'exam') {
        $output .= '<div class="quiz-header">
                        <div class="quiz-student-info">
                            <label for="student_name_' . $quiz_id . '">Họ và tên:</label>
                            <input type="text" name="student_name" id="student_name_' . $quiz_id . '" class="student-name-input">
                        </div>
                        <div class="quiz-timer" style="display:none;">Thời gian còn lại: <span id="timer_' . $quiz_id . '"></span></div>
                        <button class="start-quiz">Làm bài</button>
                    </div>';
    }

    $output .= '<div class="quiz-questions" style="' . ($atts['type'] === 'exam' ? 'display:none;' : '') . '">' . $content . '</div>';

    $output .= '<div class="quiz-score" style="display:none;">
                    <h3>Kết quả</h3>
                    <p>Điểm phần I: <span class="score-part-1">0</span></p>
                    <p>Điểm phần II: <span class="score-part-2">0</span></p>
                    <p>Điểm phần III: <span class="score-part-3">0</span></p>
                    <p><strong><span style="color: red;">Tổng điểm bài thi:</span> <span class="total-score" style="color: red;">0</span></strong></p>
                    <p class="quiz-result-message"></p>
                </div>
                <button class="submit-quiz" style="' . ($atts['type'] === 'exam' ? 'display:none;' : '') . '">Nộp bài</button>
                <button class="retry-quiz" style="display:none;">Làm lại</button>
            </div>';

    return $output;
}
add_shortcode('quiz_set', 'quiz_set_shortcode');

// Shortcode cho câu hỏi trắc nghiệm một đáp án
function quiz_question_shortcode($atts, $content = null, $tag = '', &$variables = array()) {
    $atts = shortcode_atts(array(
        'question' => '',
        'option_a' => '',
        'option_b' => '',
        'option_c' => '',
        'option_d' => '',
        'correct' => 'A',
        'explanation' => ''
    ), $atts, $tag);

    foreach ($atts as $key => &$value) {
        $value = process_variables_php($value, $variables);
    }

    $options = array('A' => $atts['option_a'], 'B' => $atts['option_b'], 'C' => $atts['option_c'], 'D' => $atts['option_d']);
    $quiz_id = uniqid();
    $encoded_correct = 'ENC:' . base64_encode($atts['correct']); // Mã hóa correct
    return '<div class="quiz-box" id="quiz-box-' . $quiz_id . '" data-correct="' . esc_attr($encoded_correct) . '" data-options="' . esc_attr(json_encode($options)) . '" data-type="single-choice">
                <div class="question-section"><h5>' . $atts['question'] . '</h5></div>
                <div class="options-section">' . generate_options_html($options, $quiz_id) . '</div>
                <div class="explanation" style="display:none;"><div class="explanation-content">' . $atts['explanation'] . '</div></div>
            </div>';
}
add_shortcode('quiz_question', 'quiz_question_shortcode');

// Shortcode cho câu hỏi trắc nghiệm đúng/sai
function quiz_question_T_F_shortcode($atts, $content = null, $tag = '', &$variables = array()) {
    $atts = shortcode_atts(array(
        'question' => '',
        'option_a' => '',
        'option_b' => '',
        'option_c' => '',
        'option_d' => '',
        'correct' => '',
        'explanation' => ''
    ), $atts, $tag);

    foreach ($atts as $key => &$value) {
        $value = process_variables_php($value, $variables);
    }

    $options = array('A' => $atts['option_a'], 'B' => $atts['option_b'], 'C' => $atts['option_c'], 'D' => $atts['option_d']);
    $quiz_id = uniqid();
    $encoded_correct = 'ENC:' . base64_encode($atts['correct']); // Mã hóa correct
    return '<div class="quiz-box quiz-box-tf" id="quiz-box-tf-' . $quiz_id . '" data-correct="' . esc_attr($encoded_correct) . '" data-options="' . esc_attr(json_encode($options)) . '" data-type="true-false">
                <div class="question-section"><h5>' . $atts['question'] . '</h5></div>
                <div class="options-section">' . generate_true_false_options_html($options, $quiz_id) . '</div>
                <div class="explanation" style="display:none;"><div class="explanation-content">' . $atts['explanation'] . '</div></div>
            </div>';
}
add_shortcode('quiz_question_T_F', 'quiz_question_T_F_shortcode');

// Shortcode cho câu hỏi trả lời ngắn
function quiz_question_short_answer_shortcode($atts, $content = null, $tag = '', &$variables = array()) {
    $atts = shortcode_atts(array(
        'question' => '',
        'correct' => '',
        'explanation' => ''
    ), $atts, $tag);

    foreach ($atts as $key => &$value) {
        $value = process_variables_php($value, $variables);
    }

    $quiz_id = uniqid();
    $encoded_correct = 'ENC:' . base64_encode($atts['correct']); // Mã hóa correct
    return '<div class="quiz-box quiz-box-sa" id="quiz-box-sa-' . $quiz_id . '" data-correct="' . esc_attr($encoded_correct) . '" data-type="short-answer">
                <div class="question-section"><h5>' . $atts['question'] . '</h5></div>
                <div class="answer-section"><input type="text" name="short_answer_' . $quiz_id . '" id="short_answer_' . $quiz_id . '" class="short-answer-input" maxlength="4"></div>
                <div class="explanation" style="display:none;"><div class="explanation-content">' . $atts['explanation'] . '</div></div>
            </div>';
}
add_shortcode('quiz_question_TLN', 'quiz_question_short_answer_shortcode');

// Thêm menu quản trị
function quiz_display_admin_menu() {
    add_menu_page('Quiz Display Settings', 'Quiz Display', 'manage_options', 'quiz-display-settings', 'quiz_display_settings_page', 'dashicons-clipboard');
    add_submenu_page('quiz-display-settings', 'Xem Điểm', 'Xem Điểm', 'manage_options', 'quiz-results', 'quiz_display_results_page');
}
add_action('admin_menu', 'quiz_display_admin_menu');

// Trang cài đặt plugin (giữ nguyên để tương thích, nhưng không dùng cho xáo trộn)
function quiz_display_settings_page() {
    if (isset($_POST['quiz_display_submit'])) {
        $settings = array(
            'shuffle_questions_single' => isset($_POST['shuffle_questions_single']) ? 'yes' : 'no',
            'shuffle_options_single' => isset($_POST['shuffle_options_single']) ? 'yes' : 'no',
        );
        update_option('quiz_display_settings', $settings);
        echo '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>';
    }

    $settings = get_option('quiz_display_settings');
    ?>
    <div class="wrap">
        <h2>Quiz Display Settings</h2>
        <form method="post" action="">
            <table class="form-table">
                <tr>
                    <th><label for="shuffle_questions_single">Xáo trộn câu hỏi (Trắc nghiệm 1 đáp án - cũ)</label></th>
                    <td><input type="checkbox" name="shuffle_questions_single" id="shuffle_questions_single" value="yes" <?php checked($settings['shuffle_questions_single'] ?? 'yes', 'yes'); ?>></td>
                </tr>
                <tr>
                    <th><label for="shuffle_options_single">Xáo trộn đáp án (Trắc nghiệm 1 đáp án - cũ)</label></th>
                    <td><input type="checkbox" name="shuffle_options_single" id="shuffle_options_single" value="yes" <?php checked($settings['shuffle_options_single'] ?? 'yes', 'yes'); ?>></td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="quiz_display_submit" class="button button-primary" value="Save Changes">
            </p>
        </form>
        <p><strong>Lưu ý:</strong> Các cài đặt trên chỉ áp dụng cho phiên bản cũ. Để xáo trộn câu hỏi và đáp án, sử dụng thuộc tính trong shortcode <code>[quiz_set]</code> (ví dụ: <code>single_choice_tron="y,y"</code>).</p>
    </div>
    <?php
}

// Hàm lưu điểm vào CSDL
add_action('wp_ajax_save_quiz_results', 'save_quiz_results');
add_action('wp_ajax_nopriv_save_quiz_results', 'save_quiz_results');
function save_quiz_results() {
    global $wpdb;

    $quiz_id = sanitize_text_field($_POST['quiz_id'] ?? '');
    $score_part_1 = floatval($_POST['score_part_1'] ?? 0);
    $score_part_2 = floatval($_POST['score_part_2'] ?? 0);
    $score_part_3 = floatval($_POST['score_part_3'] ?? 0);
    $total_score = floatval($_POST['total_score'] ?? 0);
    $quiz_type = sanitize_text_field($_POST['type'] ?? 'practice');
    $start_time = sanitize_text_field($_POST['start_time'] ?? date('Y-m-d H:i:s'));
    $end_time = sanitize_text_field($_POST['end_time'] ?? date('Y-m-d H:i:s'));

    if (empty($quiz_id)) {
        wp_send_json_error('Thiếu ID bài kiểm tra.');
        return;
    }

    $user_id = get_current_user_id();

    if ($quiz_type === 'exam') {
        $table_name = $wpdb->prefix . 'quiz_results';
        $data = array(
            'user_id' => $user_id,
            'quiz_id' => $quiz_id,
            'score_part_1' => $score_part_1,
            'score_part_2' => $score_part_2,
            'score_part_3' => $score_part_3,
            'total_score' => $total_score,
            'start_time' => $start_time,
            'end_time' => $end_time,
            'student_name' => sanitize_text_field($_POST['student_name'] ?? ''),
            'post_id' => intval($_POST['post_id'] ?? 0),
        );

        if (empty($data['student_name'])) {
            wp_send_json_error('Vui lòng nhập tên của bạn.');
            return;
        }

        if (empty($data['post_id'])) {
            wp_send_json_error('Không tìm thấy ID bài viết.');
            return;
        }

        $result = $wpdb->insert($table_name, $data);
        if ($result === false) {
            wp_send_json_error('Lỗi khi lưu điểm: ' . $wpdb->last_error);
            return;
        }
    }

    $response_data = array(
        'student_name' => sanitize_text_field($_POST['student_name'] ?? ''),
        'start_time' => $start_time,
        'end_time' => $end_time
    );

    if ($user_id && empty($response_data['student_name'])) {
        $user_info = get_userdata($user_id);
        $response_data['student_name'] = $user_info->display_name;
    }

    wp_send_json_success($response_data);
}

// Hàm hiển thị trang xem điểm
function quiz_display_results_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'quiz_results';

    if (isset($_POST['delete_selected']) && !empty($_POST['selected_results'])) {
        $selected_ids = array_map('intval', $_POST['selected_results']);
        $wpdb->query("DELETE FROM $table_name WHERE id IN (" . implode(',', $selected_ids) . ")");
        echo '<div class="notice notice-success is-dismissible"><p>Đã xóa các kết quả được chọn.</p></div>';
    }

    $post_id_filter = isset($_GET['post_id_filter']) ? intval($_GET['post_id_filter']) : '';
    $per_page = 50;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;

    $where = '';
    if (!empty($post_id_filter)) {
        $where = $wpdb->prepare(" WHERE post_id = %d", $post_id_filter);
    }

    $total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table_name" . $where);
    $results = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $table_name" . $where . " ORDER BY end_time DESC LIMIT %d OFFSET %d", $per_page, $offset)
    );

    $total_pages = ceil($total_items / $per_page);

    ?>
    <div class="wrap">
        <h2>Kết quả thi</h2>
        <form method="get" action="">
            <input type="hidden" name="page" value="quiz-results">
            <p class="search-box">
                <label for="post_id_filter">Lọc theo Post ID:</label>
                <input type="number" name="post_id_filter" id="post_id_filter" value="<?php echo esc_attr($post_id_filter); ?>" min="0">
                <input type="submit" class="button" value="Lọc">
            </p>
        </form>
        <form method="post" action="">
            <div class="tablenav top">
                <div class="alignleft actions">
                    <input type="submit" name="delete_selected" class="button action" value="Xóa các mục đã chọn" onclick="return confirm('Bạn có chắc chắn muốn xóa các kết quả đã chọn?');">
                </div>
            </div>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width: 30px;"><input type="checkbox" id="select_all"></th>
                        <th>ID</th>
                        <th>User ID</th>
                        <th>Tên học sinh</th>
                        <th>Quiz ID</th>
                        <th>Post ID</th>
                        <th>Điểm phần I</th>
                        <th>Điểm phần II</th>
                        <th>Điểm phần III</th>
                        <th>Tổng điểm</th>
                        <th>Thời gian bắt đầu</th>
                        <th>Thời gian kết thúc</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($results)) : ?>
                        <tr><td colspan="12">Không có kết quả nào.</td></tr>
                    <?php else : ?>
                        <?php foreach ($results as $result) : ?>
                            <tr>
                                <td><input type="checkbox" name="selected_results[]" value="<?php echo esc_attr($result->id); ?>"></td>
                                <td><?php echo esc_html($result->id); ?></td>
                                <td><?php echo esc_html($result->user_id); ?></td>
                                <td><?php echo esc_html($result->student_name ?: ($result->user_id ? get_userdata($result->user_id)->display_name : 'N/A')); ?></td>
                                <td><?php echo esc_html($result->quiz_id); ?></td>
                                <td><?php echo esc_html($result->post_id ?: 'N/A'); ?></td>
                                <td><?php echo esc_html($result->score_part_1); ?></td>
                                <td><?php echo esc_html($result->score_part_2); ?></td>
                                <td><?php echo esc_html($result->score_part_3); ?></td>
                                <td><?php echo esc_html($result->total_score); ?></td>
                                <td><?php echo esc_html(date('d/m/Y H:i:s', strtotime($result->start_time . ' UTC') + 7 * 3600)); ?></td>
                                <td><?php echo esc_html(date('d/m/Y H:i:s', strtotime($result->end_time . ' UTC') + 7 * 3600)); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <?php
                    echo paginate_links(array(
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => __('« Trước'),
                        'next_text' => __('Tiếp »'),
                        'total' => $total_pages,
                        'current' => $current_page,
                        'add_args' => !empty($post_id_filter) ? array('post_id_filter' => $post_id_filter) : false
                    ));
                    ?>
                    <span class="displaying-num"><?php echo esc_html($total_items); ?> mục</span>
                </div>
            </div>
        </form>
        <script>
            document.getElementById('select_all').addEventListener('change', function() {
                const checkboxes = document.querySelectorAll('input[name="selected_results[]"]');
                checkboxes.forEach(checkbox => checkbox.checked = this.checked);
            });
        </script>
    </div>
    <?php
}

// Hàm tạo HTML cho các options
function generate_options_html($options, $quiz_id) {
    $output = '';
    foreach ($options as $key => $value) {
        $output .= '<div class="option" style="display: flex; align-items: center;">
                        <input type="radio" name="question_' . $quiz_id . '" id="question_' . $quiz_id . '_option_' . $key . '" value="' . $key . '" style="margin-right: 5px;">
                        <label for="question_' . $quiz_id . '_option_' . $key . '" style="margin: 0;"><strong>' . $key . '.</strong> ' . $value . '</label>
                    </div>';
    }
    return $output;
}

function generate_true_false_options_html($options, $quiz_id) {
    $output = '';
    $option_letters = array('a', 'b', 'c', 'd');
    $i = 0;
    foreach ($options as $key => $value) {
        $output .= '<div class="option-tf">
                <label class="option-tf-label" for="question_tf_' . $quiz_id . '_option_' . $key . '">' . $option_letters[$i] . ') ' . $value . '</label>
                <div class="tf-buttons">
                    <input type="radio" name="question_tf_' . $quiz_id . '_option_' . $key . '" id="question_tf_' . $quiz_id . '_option_' . $key . '_true" value="true">
                    <label class="true-label" for="question_tf_' . $quiz_id . '_option_' . $key . '_true">Đ</label>
                    <input type="radio" name="question_tf_' . $quiz_id . '_option_' . $key . '" id="question_tf_' . $quiz_id . '_option_' . $key . '_false" value="false">
                    <label class="false-label" for="question_tf_' . $quiz_id . '_option_' . $key . '_false">S</label>
                </div>
            </div>';
        $i++;
    }
    return $output;
}