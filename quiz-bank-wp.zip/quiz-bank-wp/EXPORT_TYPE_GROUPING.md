# Export Format Update - Question Type Grouping

## Summary
Updated the Quiz Bank export functionality to organize questions by type with section headers.

## New Export Format Structure

### TXT and Word Export Format:
```
NGÂN HÀNG CÂU HỎI TRẮC NGHIỆM
Xuất ngày: [date]
Tổng số câu: [count]
==================================================

Phần I: Câu hỏi trắc nghiệm 1 đáp án đúng
--------------------------------------------------

Câu 1: [MCQ question content]
A. [option A]
B. [option B] 
C. [option C]
D. [option D]
Lời giải
[explanation]
Đáp án: A

Câu 2: [next MCQ question...]

Phần II: Câu hỏi Đúng - sai
--------------------------------------------------

Câu X: [MSQ question content]
A. [option A]
B. [option B]
C. [option C] 
D. [option D]
Lời giải
[explanation]
Đáp án: A,C

Phần III: Trả lời ngắn
--------------------------------------------------

Câu Y: [SA question content]
Lời giải
[explanation]
Đáp án: [correct_answer]
```

## Changes Made

### 1. Added Question Grouping Method
**File:** `includes/class-quiz-bank-export.php`
- Added `group_questions_by_type()` method to organize questions by type (MCQ, MSQ, SA)

### 2. Updated TXT Export Format
- **Section Headers:** Added Vietnamese section titles
- **MCQ Section:** "Phần I: Câu hỏi trắc nghiệm 1 đáp án đúng"
- **MSQ Section:** "Phần II: Câu hỏi Đúng - sai" 
- **SA Section:** "Phần III: Trả lời ngắn"
- **Continuous Numbering:** Questions numbered sequentially across all sections

### 3. Updated Word Export Format
- **Enhanced Styling:** Added section title and divider styles
- **Same Structure:** Mirrors TXT format with better HTML presentation
- **Professional Layout:** Clear section separation with divider lines

### 4. Special Handling for Question Types
- **MCQ/MSQ Questions:** Display A,B,C,D options + correct_option
- **SA Questions:** No options shown, uses correct_answer field
- **Flexible Grouping:** Handles missing type field by defaulting to MCQ

## Benefits
- ✅ **Better Organization:** Questions grouped logically by type
- ✅ **Professional Format:** Clear section headers and structure  
- ✅ **Continuous Numbering:** Sequential question numbering across sections
- ✅ **Type-Appropriate Display:** SA questions don't show irrelevant options
- ✅ **Backward Compatible:** Works with existing question data