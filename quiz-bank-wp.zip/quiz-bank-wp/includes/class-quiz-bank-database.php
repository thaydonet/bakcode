<?php
/**
 * Quiz Bank Database Class
 * 
 * Handles all database operations for the quiz bank plugin
 */

class QuizBankDatabase {
    
    private $table_name;
    
    /**
     * Constructor
     */
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . QUIZ_BANK_TABLE_NAME;
    }
    
    /**
     * Get all questions with pagination and filtering
     * 
     * @param array $args Query arguments
     * @return array
     */
    public function get_questions($args = array()) {
        global $wpdb;
        
        $defaults = array(
            'lop' => '',
            'chuong' => '',
            'bai_hoc' => '',
            'dang' => '',
            'muc_do' => '',
            'type' => '',
            'search' => '',
            'limit' => 20,
            'offset' => 0,
            'orderby' => 'id',
            'order' => 'DESC'
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where_conditions = array('1=1');
        $where_values = array();
        
        if (!empty($args['lop'])) {
            $where_conditions[] = 'lop = %s';
            $where_values[] = $args['lop'];
        }
        
        if (!empty($args['chuong'])) {
            $where_conditions[] = 'chuong = %s';
            $where_values[] = $args['chuong'];
        }
        
        if (!empty($args['bai_hoc'])) {
            $where_conditions[] = 'bai_hoc = %s';
            $where_values[] = $args['bai_hoc'];
        }
        
        if (!empty($args['dang'])) {
            $where_conditions[] = 'dang = %s';
            $where_values[] = $args['dang'];
        }
        
        if (!empty($args['muc_do'])) {
            $where_conditions[] = 'muc_do = %s';
            $where_values[] = $args['muc_do'];
        }
        
        if (!empty($args['type'])) {
            $where_conditions[] = 'type = %s';
            $where_values[] = $args['type'];
        }
        
        if (!empty($args['search'])) {
            $where_conditions[] = '(cau_hoi LIKE %s OR option_a LIKE %s OR option_b LIKE %s OR option_c LIKE %s OR option_d LIKE %s)';
            $search_term = '%' . $wpdb->esc_like($args['search']) . '%';
            $where_values = array_merge($where_values, array($search_term, $search_term, $search_term, $search_term, $search_term));
        }
        
        $where_clause = implode(' AND ', $where_conditions);
        
        $orderby = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']);
        if (!$orderby) {
            $orderby = 'id DESC';
        }
        
        $limit_clause = '';
        if ($args['limit'] > 0) {
            $limit_clause = $wpdb->prepare(' LIMIT %d OFFSET %d', $args['limit'], $args['offset']);
        }
        
        $sql = "SELECT * FROM {$this->table_name} WHERE {$where_clause} ORDER BY {$orderby}{$limit_clause}";
        
        if (!empty($where_values)) {
            $sql = $wpdb->prepare($sql, $where_values);
        }
        
        return $wpdb->get_results($sql);
    }

    /**
     * Get total count of questions
     * 
     * @param array $args Query arguments
     * @return int
     */
    public function get_questions_count($args = array()) {
        global $wpdb;
        
        $defaults = array(
            'lop' => '',
            'chuong' => '',
            'bai_hoc' => '',
            'dang' => '',
            'muc_do' => '',
            'type' => '',
            'search' => ''
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where_conditions = array('1=1');
        $where_values = array();
        
        if (!empty($args['lop'])) {
            $where_conditions[] = 'lop = %s';
            $where_values[] = $args['lop'];
        }
        
        if (!empty($args['chuong'])) {
            $where_conditions[] = 'chuong = %s';
            $where_values[] = $args['chuong'];
        }
        
        if (!empty($args['bai_hoc'])) {
            $where_conditions[] = 'bai_hoc = %s';
            $where_values[] = $args['bai_hoc'];
        }
        
        if (!empty($args['dang'])) {
            $where_conditions[] = 'dang = %s';
            $where_values[] = $args['dang'];
        }
        
        if (!empty($args['muc_do'])) {
            $where_conditions[] = 'muc_do = %s';
            $where_values[] = $args['muc_do'];
        }
        
        if (!empty($args['type'])) {
            $where_conditions[] = 'type = %s';
            $where_values[] = $args['type'];
        }

        if (!empty($args['search'])) {
            $where_conditions[] = '(cau_hoi LIKE %s OR option_a LIKE %s OR option_b LIKE %s OR option_c LIKE %s OR option_d LIKE %s)';
            $search_term = '%' . $wpdb->esc_like($args['search']) . '%';
            $where_values = array_merge($where_values, array($search_term, $search_term, $search_term, $search_term, $search_term));
        }
        
        $where_clause = implode(' AND ', $where_conditions);
        
        $sql = "SELECT COUNT(*) FROM {$this->table_name} WHERE {$where_clause}";
        
        if (!empty($where_values)) {
            $sql = $wpdb->prepare($sql, $where_values);
        }
        
        return (int) $wpdb->get_var($sql);
    }
    
    /**
     * Get question by ID
     * 
     * @param int $id Question ID
     * @return object|null
     */
    public function get_question($id) {
        global $wpdb;
        
        $sql = $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE id = %d", $id);
        return $wpdb->get_row($sql);
    }
    
    /**
     * Get questions by IDs
     * 
     * @param array $ids Question IDs
     * @return array
     */
    public function get_questions_by_ids($ids) {
        global $wpdb;
        
        if (empty($ids)) {
            return array();
        }
        
        $ids = array_map('intval', $ids);
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        
        $sql = $wpdb->prepare("SELECT * FROM {$this->table_name} WHERE id IN ($placeholders) ORDER BY id DESC", $ids);
        return $wpdb->get_results($sql);
    }
    
    /**
     * Insert new question
     * 
     * @param array $data Question data
     * @return int|false Question ID on success, false on failure
     */
    public function insert_question($data) {
        global $wpdb;
        
        $defaults = array(
            'lop' => '',
            'chuong' => '',
            'bai_hoc' => '',
            'dang' => '',
            'muc_do' => '',
            'type' => 'mcq',
            'cau_hoi' => '',
            'option_a' => '',
            'option_b' => '',
            'option_c' => '',
            'option_d' => '',
            'correct_option' => '',
            'correct_answer' => '',
            'explanation' => ''
        );
        
        $data = wp_parse_args($data, $defaults);
        
        // Validate required fields based on question type
        $type = $data['type'];
        $required_fields = array('lop', 'chuong', 'bai_hoc', 'dang', 'muc_do', 'cau_hoi');
        
        error_log('Quiz Bank: Validating question type: ' . $type);
        
        if ($type === 'sa') {
            // Short answer - require correct_option (now standardized across all types)
            if (empty($data['correct_option'])) {
                error_log('Quiz Bank: SA question missing correct_option');
                return false;
            }
        } else {
            // MCQ or MSQ - require options and correct_option
            $mcq_required_fields = array('option_a', 'option_b', 'option_c', 'option_d', 'correct_option');
            foreach ($mcq_required_fields as $field) {
                if (empty($data[$field])) {
                    error_log('Quiz Bank: MCQ/MSQ question missing field: ' . $field);
                    return false;
                }
            }
        }
        
        // Validate basic required fields
        foreach ($required_fields as $field) {
            if (empty($data[$field])) {
                error_log('Quiz Bank: Missing required field: ' . $field);
                return false;
            }
        }
        
        // Validate correct option for MCQ/MSQ
        if (in_array($type, array('mcq', 'msq')) && !empty($data['correct_option'])) {
            $correct_options = array_map('trim', explode(',', $data['correct_option']));
            foreach ($correct_options as $option) {
                if (!in_array($option, array('A', 'B', 'C', 'D'))) {
                    error_log('Quiz Bank: Invalid correct_option: ' . $option);
                    return false;
                }
            }
        }
        
        $result = $wpdb->insert(
            $this->table_name,
            array(
                'lop' => sanitize_text_field($data['lop']),
                'chuong' => sanitize_text_field($data['chuong']),
                'bai_hoc' => sanitize_text_field($data['bai_hoc']),
                'dang' => sanitize_text_field($data['dang']),
                'muc_do' => sanitize_text_field($data['muc_do']),
                'type' => sanitize_text_field($data['type']),
                'cau_hoi' => wp_kses_post($data['cau_hoi']),
                'option_a' => wp_kses_post($data['option_a']),
                'option_b' => wp_kses_post($data['option_b']),
                'option_c' => wp_kses_post($data['option_c']),
                'option_d' => wp_kses_post($data['option_d']),
                'correct_option' => sanitize_text_field($data['correct_option']),
                'correct_answer' => wp_kses_post($data['correct_answer']),
                'explanation' => wp_kses_post($data['explanation'])
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
        
        if ($result === false) {
            error_log('Quiz Bank: Database insert failed. Error: ' . $wpdb->last_error);
            error_log('Quiz Bank: Last query: ' . $wpdb->last_query);
        } else {
            error_log('Quiz Bank: Question inserted successfully with ID: ' . $wpdb->insert_id);
        }
        
        return $result ? $wpdb->insert_id : false;
    }
    
    /**
     * Update question
     * 
     * @param int $id Question ID
     * @param array $data Question data
     * @return bool
     */
    public function update_question($id, $data) {
        global $wpdb;
        
        // Validate correct option if provided (now used for all question types)
        if (!empty($data['correct_option'])) {
            // For MCQ and MSQ, validate format
            if (isset($data['type']) && in_array($data['type'], array('mcq', 'msq'))) {
                $correct_options = array_map('trim', explode(',', $data['correct_option']));
                foreach ($correct_options as $option) {
                    if (!in_array($option, array('A', 'B', 'C', 'D'))) {
                        return false;
                    }
                }
            }
            // For SA type, correct_option can be any text, no validation needed
        }
        
        $update_data = array();
        $update_format = array();
        
        $allowed_fields = array('lop', 'chuong', 'bai_hoc', 'dang', 'muc_do', 'type', 'cau_hoi', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_option', 'correct_answer', 'explanation');
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                if (in_array($field, array('cau_hoi', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_answer', 'explanation'))) {
                    $update_data[$field] = wp_kses_post($data[$field]);
                } else {
                    $update_data[$field] = sanitize_text_field($data[$field]);
                }
                $update_format[] = '%s';
            }
        }
        
        if (empty($update_data)) {
            return false;
        }
        
        $result = $wpdb->update(
            $this->table_name,
            $update_data,
            array('id' => $id),
            $update_format,
            array('%d')
        );
        
        return $result !== false;
    }
    
    /**
     * Delete question
     * 
     * @param int $id Question ID
     * @return bool
     */
    public function delete_question($id) {
        global $wpdb;
        
        $result = $wpdb->delete(
            $this->table_name,
            array('id' => $id),
            array('%d')
        );
        
        return $result !== false;
    }
    
    /**
     * Get unique values for a field
     * 
     * @param string $field Field name
     * @param array $conditions Additional conditions
     * @return array
     */
    public function get_unique_values($field, $conditions = array()) {
        global $wpdb;
        
        $allowed_fields = array('lop', 'chuong', 'bai_hoc', 'dang', 'muc_do');
        if (!in_array($field, $allowed_fields)) {
            return array();
        }
        
        $where_conditions = array('1=1');
        $where_values = array();
        
        foreach ($conditions as $key => $value) {
            if (in_array($key, $allowed_fields) && !empty($value)) {
                $where_conditions[] = $key . ' = %s';
                $where_values[] = $value;
            }
        }
        
        $where_clause = implode(' AND ', $where_conditions);
        
        $sql = "SELECT DISTINCT {$field} FROM {$this->table_name} WHERE {$where_clause} AND {$field} != '' ORDER BY {$field}";
        
        if (!empty($where_values)) {
            $sql = $wpdb->prepare($sql, $where_values);
        }
        
        $results = $wpdb->get_col($sql);
        return $results ? $results : array();
    }
    
    /**
     * Get chapters by grade
     * 
     * @param string $grade Grade level
     * @return array
     */
    public function get_chapters_by_grade($grade) {
        return $this->get_unique_values('chuong', array('lop' => $grade));
    }
    
    /**
     * Get lessons by grade and chapter
     * 
     * @param string $grade Grade level
     * @param string $chapter Chapter
     * @return array
     */
    public function get_lessons_by_grade_chapter($grade, $chapter) {
        return $this->get_unique_values('bai_hoc', array('lop' => $grade, 'chuong' => $chapter));
    }
    
    /**
     * Get predefined structure for grade 12
     * 
     * @return array
     */
    public function get_grade_12_structure() {
        return array(
            '1' => array(
                'name' => 'Chương 1',
                'lessons' => array('1', '2', '3')
            ),
            '2' => array(
                'name' => 'Chương 2', 
                'lessons' => array('1', '2', '3')
            ),
            '3' => array(
                'name' => 'Chương 3',
                'lessons' => array('1', '2', '3')
            )
        );
    }
    
    /**
     * Get predefined types
     * 
     * @return array
     */
    public function get_predefined_types() {
        return array('1', '2', '3');
    }
    
    /**
     * Get lessons by grade
     * 
     * @param string $grade Grade level
     * @return array
     */
    public function get_lessons_by_grade($grade) {
        return $this->get_unique_values('bai_hoc', array('lop' => $grade));
    }
    
    /**
     * Get types by grade, chapter and lesson
     * 
     * @param string $grade Grade level
     * @param string $chapter Chapter
     * @param string $lesson Lesson name
     * @return array
     */
    public function get_types_by_grade_chapter_lesson($grade, $chapter, $lesson) {
        return $this->get_unique_values('dang', array('lop' => $grade, 'chuong' => $chapter, 'bai_hoc' => $lesson));
    }
    
    /**
     * Get types by grade and lesson
     * 
     * @param string $grade Grade level
     * @param string $lesson Lesson name
     * @return array
     */
    public function get_types_by_grade_lesson($grade, $lesson) {
        return $this->get_unique_values('dang', array('lop' => $grade, 'bai_hoc' => $lesson));
    }
    
    /**
     * Get categories by grade, lesson, and type
     * 
     * @param string $grade Grade level
     * @param string $lesson Lesson name
     * @param string $type Question type
     * @return array
     */
    public function get_categories_by_grade_lesson_type($grade, $lesson, $type) {
        return $this->get_unique_values('muc_do', array('lop' => $grade, 'bai_hoc' => $lesson, 'dang' => $type));
    }
    
    /**
     * Get all grades
     * 
     * @return array
     */
    public function get_all_grades() {
        return $this->get_unique_values('lop');
    }
    
    /**
     * Bulk insert questions
     * 
     * @param array $questions Array of question data
     * @return array Result with success/error counts
     */
    public function bulk_insert_questions($questions) {
        $success_count = 0;
        $error_count = 0;
        $errors = array();
        
        foreach ($questions as $index => $question) {
            $result = $this->insert_question($question);
            if ($result) {
                $success_count++;
            } else {
                $error_count++;
                $errors[] = sprintf(__('Lỗi tại câu hỏi %d: Dữ liệu không hợp lệ', 'quiz-bank'), $index + 1);
            }
        }
        
        return array(
            'success_count' => $success_count,
            'error_count' => $error_count,
            'errors' => $errors
        );
    }
    
    /**
     * Check if table exists
     * 
     * @return bool
     */
    public function table_exists() {
        global $wpdb;
        
        $table_name = $this->table_name;
        $query = $wpdb->prepare("SHOW TABLES LIKE %s", $table_name);
        
        return $wpdb->get_var($query) === $table_name;
    }
    
    /**
     * Get database statistics
     * 
     * @return array
     */
    public function get_statistics() {
        global $wpdb;
        
        $stats = array();
        
        // Total questions
        $stats['total_questions'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}");
        
        // Total questions by type
        $total_by_type = $wpdb->get_results("SELECT type, COUNT(*) as count FROM {$this->table_name} GROUP BY type");
        $stats['total_mcq'] = 0;
        $stats['total_msq'] = 0;
        $stats['total_sa'] = 0;
        foreach ($total_by_type as $type_stat) {
            switch ($type_stat->type) {
                case 'mcq':
                    $stats['total_mcq'] = (int) $type_stat->count;
                    break;
                case 'msq':
                    $stats['total_msq'] = (int) $type_stat->count;
                    break;
                case 'sa':
                    $stats['total_sa'] = (int) $type_stat->count;
                    break;
            }
        }
        
        // Questions by grade
        $grades = $wpdb->get_results("SELECT lop, COUNT(*) as count FROM {$this->table_name} GROUP BY lop ORDER BY lop");
        $stats['by_grade'] = array();
        foreach ($grades as $grade) {
            $stats['by_grade'][$grade->lop] = (int) $grade->count;
        }
        
        // Questions by grade and type
        $grade_types = $wpdb->get_results("SELECT lop, type, COUNT(*) as count FROM {$this->table_name} GROUP BY lop, type ORDER BY lop, type");
        $stats['by_grade_type'] = array();
        foreach ($grade_types as $grade_type) {
            if (!isset($stats['by_grade_type'][$grade_type->lop])) {
                $stats['by_grade_type'][$grade_type->lop] = array(
                    'mcq' => 0,
                    'msq' => 0,
                    'sa' => 0
                );
            }
            $stats['by_grade_type'][$grade_type->lop][$grade_type->type] = (int) $grade_type->count;
        }
        
        // Recent questions (last 7 days)
        $stats['recent_questions'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name} WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
        
        // Recent questions by type
        $recent_by_type = $wpdb->get_results("SELECT type, COUNT(*) as count FROM {$this->table_name} WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY type");
        $stats['recent_mcq'] = 0;
        $stats['recent_msq'] = 0;
        $stats['recent_sa'] = 0;
        foreach ($recent_by_type as $type_stat) {
            switch ($type_stat->type) {
                case 'mcq':
                    $stats['recent_mcq'] = (int) $type_stat->count;
                    break;
                case 'msq':
                    $stats['recent_msq'] = (int) $type_stat->count;
                    break;
                case 'sa':
                    $stats['recent_sa'] = (int) $type_stat->count;
                    break;
            }
        }
        
        return $stats;
    }
}