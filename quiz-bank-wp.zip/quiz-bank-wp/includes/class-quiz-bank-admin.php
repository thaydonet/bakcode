<?php
/**
 * Quiz Bank Admin Class
 * 
 * Handles all admin interface functionality
 */

class QuizBankAdmin {
    
    private $db;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->db = new QuizBankDatabase();
        $this->init_hooks();
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        add_action('admin_post_quiz_bank_save_question', array($this, 'save_question'));
        add_action('admin_post_quiz_bank_update_question', array($this, 'update_question'));
    }
    
    /**
     * Display questions page
     */
    public function display_questions_page() {
        if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
            $this->display_edit_question_page(intval($_GET['id']));
            return;
        }
        
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $per_page = 20;
        
        $filters = array(
            'lop' => isset($_GET['lop']) ? sanitize_text_field($_GET['lop']) : '',
            'chuong' => isset($_GET['chuong']) ? sanitize_text_field($_GET['chuong']) : '',
            'bai_hoc' => isset($_GET['bai_hoc']) ? sanitize_text_field($_GET['bai_hoc']) : '',
            'dang' => isset($_GET['dang']) ? sanitize_text_field($_GET['dang']) : '',
            'muc_do' => isset($_GET['muc_do']) ? sanitize_text_field($_GET['muc_do']) : '',
            'type' => isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '',
            'search' => isset($_GET['search']) ? sanitize_text_field($_GET['search']) : ''
        );
        
        $args = array_merge($filters, array(
            'limit' => $per_page,
            'offset' => ($current_page - 1) * $per_page
        ));
        
        $questions = $this->db->get_questions($args);
        $total_questions = $this->db->get_questions_count($filters);
        $total_pages = ceil($total_questions / $per_page);
        
        include QUIZ_BANK_PLUGIN_DIR . 'admin/questions-list.php';
    }
    
    /**
     * Display add question page
     */
    public function display_add_question_page() {
        if (isset($_POST['submit'])) {
            $this->save_question();
            return;
        }
        
        include QUIZ_BANK_PLUGIN_DIR . 'admin/add-question.php';
    }
    
    /**
     * Display edit question page
     */
    public function display_edit_question_page($id) {
        $question = $this->db->get_question($id);
        
        if (!$question) {
            wp_die(__('Câu hỏi không tồn tại.', 'quiz-bank'));
        }
        
        if (isset($_POST['submit'])) {
            $this->update_question();
            return;
        }
        
        include QUIZ_BANK_PLUGIN_DIR . 'admin/edit-question.php';
    }
    
    /**
     * Save new question
     */
    public function save_question() {
        try {
            // Enable error reporting for debugging
            error_log('Quiz Bank: Starting save_question process');
            
            if (!wp_verify_nonce($_POST['_wpnonce'], 'quiz_bank_save_question')) {
                error_log('Quiz Bank: Nonce verification failed');
                wp_die(__('Security check failed', 'quiz-bank'));
            }
            
            // Log POST data for debugging
            error_log('Quiz Bank: POST data - ' . print_r($_POST, true));
            
            $question_type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : 'mcq';
            
            $data = array(
                'lop' => sanitize_text_field($_POST['lop']),
                'chuong' => sanitize_text_field($_POST['chuong']),
                'bai_hoc' => sanitize_text_field($_POST['bai_hoc']),
                'dang' => sanitize_text_field($_POST['dang']),
                'muc_do' => sanitize_text_field($_POST['muc_do']),
                'type' => $question_type,
                'cau_hoi' => wp_kses_post($_POST['cau_hoi']),
                'explanation' => wp_kses_post($_POST['explanation'])
            );
            
            // Handle different question types - All types now use correct_option
            if ($question_type === 'sa') {
                // Short answer - use correct_option (standardized across all types)
                $data['option_a'] = '';
                $data['option_b'] = '';
                $data['option_c'] = '';
                $data['option_d'] = '';
                $data['correct_option'] = isset($_POST['correct_answer']) ? wp_kses_post($_POST['correct_answer']) : '';
                $data['correct_answer'] = '';
            } else {
                // MCQ or MSQ - need all options and correct_option
                $data['option_a'] = wp_kses_post($_POST['option_a']);
                $data['option_b'] = wp_kses_post($_POST['option_b']);
                $data['option_c'] = wp_kses_post($_POST['option_c']);
                $data['option_d'] = wp_kses_post($_POST['option_d']);
                // Handle MSQ text input or regular select
                if ($question_type === 'msq') {
                    // For MSQ, prioritize correct_option_text over correct_option_msq over correct_option
                    if (!empty($_POST['correct_option_text'])) {
                        $data['correct_option'] = strtoupper(str_replace(' ', '', sanitize_text_field($_POST['correct_option_text'])));
                    } elseif (!empty($_POST['correct_option_msq'])) {
                        $data['correct_option'] = strtoupper(str_replace(' ', '', sanitize_text_field($_POST['correct_option_msq'])));
                    } else {
                        $data['correct_option'] = sanitize_text_field($_POST['correct_option']);
                    }
                    error_log('Quiz Bank: MSQ correct_option set to: ' . $data['correct_option']);
                } else {
                    $data['correct_option'] = sanitize_text_field($_POST['correct_option']);
                }
                $data['correct_answer'] = '';
            }
            
            error_log('Quiz Bank: Processed data - ' . print_r($data, true));
            
            $result = $this->db->insert_question($data);
            
            if ($result) {
                error_log('Quiz Bank: Question saved successfully with ID: ' . $result);
                wp_redirect(admin_url('admin.php?page=quiz-bank&message=success'));
            } else {
                error_log('Quiz Bank: Failed to insert question - ' . print_r($data, true));
                wp_redirect(admin_url('admin.php?page=quiz-bank-add&message=error'));
            }
            exit;
        } catch (Exception $e) {
            error_log('Quiz Bank Error in save_question: ' . $e->getMessage());
            error_log('Quiz Bank Stack trace: ' . $e->getTraceAsString());
            wp_redirect(admin_url('admin.php?page=quiz-bank-add&message=error'));
            exit;
        }
    }
    
    /**
     * Update question
     */
    public function update_question() {
        try {
            error_log('Quiz Bank: Starting update_question process');
            
            if (!wp_verify_nonce($_POST['_wpnonce'], 'quiz_bank_update_question')) {
                error_log('Quiz Bank: Update nonce verification failed');
                wp_die(__('Security check failed', 'quiz-bank'));
            }
            
            $id = intval($_POST['question_id']);
            $question_type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : 'mcq';
            
            error_log('Quiz Bank: Updating question ID: ' . $id . ' with type: ' . $question_type);
            
            $data = array(
                'lop' => sanitize_text_field($_POST['lop']),
                'chuong' => sanitize_text_field($_POST['chuong']),
                'bai_hoc' => sanitize_text_field($_POST['bai_hoc']),
                'dang' => sanitize_text_field($_POST['dang']),
                'muc_do' => sanitize_text_field($_POST['muc_do']),
                'type' => $question_type,
                'cau_hoi' => wp_kses_post($_POST['cau_hoi']),
                'explanation' => wp_kses_post($_POST['explanation'])
            );
            
            // Handle different question types - All types now use correct_option
            if ($question_type === 'sa') {
                // Short answer - use correct_option (standardized across all types)
                $data['option_a'] = '';
                $data['option_b'] = '';
                $data['option_c'] = '';
                $data['option_d'] = '';
                $data['correct_option'] = isset($_POST['correct_answer']) ? wp_kses_post($_POST['correct_answer']) : '';
                $data['correct_answer'] = '';
            } else {
                // MCQ or MSQ - need all options and correct_option
                $data['option_a'] = wp_kses_post($_POST['option_a']);
                $data['option_b'] = wp_kses_post($_POST['option_b']);
                $data['option_c'] = wp_kses_post($_POST['option_c']);
                $data['option_d'] = wp_kses_post($_POST['option_d']);
                // Handle MSQ text input or regular select for update
                if ($question_type === 'msq') {
                    // For MSQ, prioritize correct_option_text over correct_option_msq over correct_option
                    if (!empty($_POST['correct_option_text'])) {
                        $data['correct_option'] = strtoupper(str_replace(' ', '', sanitize_text_field($_POST['correct_option_text'])));
                    } elseif (!empty($_POST['correct_option_msq'])) {
                        $data['correct_option'] = strtoupper(str_replace(' ', '', sanitize_text_field($_POST['correct_option_msq'])));
                    } else {
                        $data['correct_option'] = sanitize_text_field($_POST['correct_option']);
                    }
                    error_log('Quiz Bank: MSQ update correct_option set to: ' . $data['correct_option']);
                } else {
                    $data['correct_option'] = sanitize_text_field($_POST['correct_option']);
                }
                $data['correct_answer'] = '';
            }
            
            error_log('Quiz Bank: Update data - ' . print_r($data, true));
            
            $result = $this->db->update_question($id, $data);
            
            if ($result) {
                error_log('Quiz Bank: Question updated successfully');
                wp_redirect(admin_url('admin.php?page=quiz-bank&message=updated'));
            } else {
                error_log('Quiz Bank: Failed to update question');
                wp_redirect(admin_url('admin.php?page=quiz-bank&action=edit&id=' . $id . '&message=error'));
            }
            exit;
        } catch (Exception $e) {
            error_log('Quiz Bank Error in update_question: ' . $e->getMessage());
            error_log('Quiz Bank Stack trace: ' . $e->getTraceAsString());
            wp_redirect(admin_url('admin.php?page=quiz-bank&action=edit&id=' . $id . '&message=error'));
            exit;
        }
    }
}