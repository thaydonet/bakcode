<?php
if (!defined('ABSPATH')) {
    exit;
}

$import = new QuizBankImport();
?>

<div class="wrap">
    <h1><?php _e('Import câu hỏi', 'quiz-bank'); ?></h1>
    
    <div class="import-instructions">
        <h3><?php _e('Hướng dẫn import', 'quiz-bank'); ?></h3>
        <p><?php _e('Để import câu hỏi hàng loạt, vui lòng:', 'quiz-bank'); ?></p>
        <ol>
            <li><?php _e('Chọn lớp, chương và bài học - thông tin này sẽ áp dụng cho tất cả câu hỏi', 'quiz-bank'); ?></li>
            <li><?php _e('Tạo file JSON theo cấu trúc mẫu bên dưới', 'quiz-bank'); ?></li>
            <li><?php _e('Đảm bảo tất cả các trường bắt buộc đều có dữ liệu', 'quiz-bank'); ?></li>
            <li><?php _e('Chọn file và click "Import"', 'quiz-bank'); ?></li>
        </ol>
        <p><strong><?php _e('Mới:', 'quiz-bank'); ?></strong> <?php _e('Hỗ trợ 3 loại câu hỏi - MCQ (một lựa chọn), MSQ (nhiều lựa chọn), SA (câu hỏi ngắn)', 'quiz-bank'); ?></p>
    </div>
    
    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" enctype="multipart/form-data">
        <input type="hidden" name="action" value="quiz_bank_import">
        <?php wp_nonce_field('quiz_bank_import'); ?>
        
        <div class="import-form-section">
            <h4><?php _e('Thông tin chung cho tất cả câu hỏi', 'quiz-bank'); ?></h4>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="import_lop"><?php _e('Toán', 'quiz-bank'); ?> *</label></th>
                    <td>
                        <select name="import_lop" id="import_lop" required>
                            <option value=""><?php _e('Chọn lớp', 'quiz-bank'); ?></option>
                            <option value="12">Toán 12</option>
                        <option value="11">Toán 11</option>
                        <option value="10">Toán 10</option>
                        </select>
                        <p class="description"><?php _e('Chọn lớp để áp dụng cho tất cả câu hỏi import', 'quiz-bank'); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row"><label for="import_chuong"><?php _e('Chương', 'quiz-bank'); ?> *</label></th>
                    <td>
                        <select name="import_chuong" id="import_chuong" required>
                            <option value=""><?php _e('Chọn chương', 'quiz-bank'); ?></option>
                        </select>
                        <p class="description"><?php _e('Chọn chương để áp dụng cho tất cả câu hỏi import', 'quiz-bank'); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row"><label for="import_bai_hoc"><?php _e('Bài học', 'quiz-bank'); ?> *</label></th>
                    <td>
                        <select name="import_bai_hoc" id="import_bai_hoc" required>
                            <option value=""><?php _e('Chọn bài học', 'quiz-bank'); ?></option>
                        </select>
                        <p class="description"><?php _e('Chọn bài học để áp dụng cho tất cả câu hỏi import', 'quiz-bank'); ?></p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row"><label for="import_dang"><?php _e('Dạng', 'quiz-bank'); ?></label></th>
                    <td>
                        <select name="import_dang" id="import_dang">
                            <option value=""><?php _e('Chọn dạng', 'quiz-bank'); ?></option>
                        </select>
                        <p class="description"><?php _e('Dạng câu hỏi (tùy chọn - nếu để trống sẽ lấy từ file JSON)', 'quiz-bank'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="import-form-section">
            <h4><?php _e('Phương thức import', 'quiz-bank'); ?></h4>
            <table class="form-table">
                <tr>
                    <th scope="row"><label><?php _e('Chọn phương thức', 'quiz-bank'); ?></label></th>
                    <td>
                        <input type="radio" name="import_method" id="import_method_file" value="file" checked>
                        <label for="import_method_file"><?php _e('Import từ file JSON', 'quiz-bank'); ?></label><br>
                        <input type="radio" name="import_method" id="import_method_text" value="text">
                        <label for="import_method_text"><?php _e('Import từ nội dung JSON', 'quiz-bank'); ?></label>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="import-form-section" id="file-import-section">
            <h4><?php _e('File dữ liệu', 'quiz-bank'); ?></h4>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="import_file"><?php _e('Chọn file JSON', 'quiz-bank'); ?></label></th>
                    <td>
                        <input type="file" name="import_file" id="import_file" accept=".json">
                        <p class="description"><?php _e('Chỉ chấp nhận file .json', 'quiz-bank'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="import-form-section" id="text-import-section" style="display: none;">
            <h4><?php _e('Nội dung JSON', 'quiz-bank'); ?></h4>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="import_text"><?php _e('Dán nội dung JSON', 'quiz-bank'); ?></label></th>
                    <td>
                        <textarea name="import_text" id="import_text" rows="15" cols="80" class="large-text code" placeholder="<?php _e('Dán nội dung JSON vào đây...', 'quiz-bank'); ?>"></textarea>
                        <p class="description"><?php _e('Dán nội dung JSON hợp lệ vào ô text này', 'quiz-bank'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <p class="submit">
            <input type="submit" name="submit" class="button-primary" value="<?php _e('Import câu hỏi', 'quiz-bank'); ?>">
        </p>
    </form>
    
    <h3><?php _e('File JSON mẫu', 'quiz-bank'); ?></h3>
    <div class="sample-json-download">
        <p><?php _e('Tải xuống file JSON mẫu để tham khảo cấu trúc:', 'quiz-bank'); ?></p>
        <a href="<?php echo plugin_dir_url(dirname(__FILE__)) . 'sample-import.json'; ?>" class="button button-secondary" download>
            <span class="dashicons dashicons-download"></span>
            <?php _e('Tải xuống sample-import.json', 'quiz-bank'); ?>
        </a>
        <p class="description"><?php _e('File mẫu chứa các ví dụ về 3 loại câu hỏi: MCQ, MSQ và SA', 'quiz-bank'); ?></p>
    </div>
    
    <h3><?php _e('Lưu ý quan trọng', 'quiz-bank'); ?></h3>
    <ul>
        <li><?php _e('Toán, chương và bài học sẽ được lấy từ form, không cần đặt trong file JSON', 'quiz-bank'); ?></li>
        <li><?php _e('Trường "type" chỉ chấp nhận giá trị: mcq, msq, sa', 'quiz-bank'); ?></li>
        <li><?php _e('Trường "dang" chỉ chấp nhận giá trị: 1, 2, 3', 'quiz-bank'); ?></li>
        <li><?php _e('MCQ: "correct_option" chỉ chấp nhận A, B, C hoặc D', 'quiz-bank'); ?></li>
        <li><?php _e('MSQ: "correct_option" có thể là A,B,C hoặc A,C (nhiều đáp án phân cách bằng dấu phẩy)', 'quiz-bank'); ?></li>
        <li><?php _e('SA: Cần trường "correct_option" giống như MCQ và MSQ', 'quiz-bank'); ?></li>
        <li><?php _e('Có thể sử dụng HTML trong các trường câu hỏi và đáp án', 'quiz-bank'); ?></li>
        <li><?php _e('Trường "explanation" có thể để trống', 'quiz-bank'); ?></li>
        <li><?php _e('File không được vượt quá giới hạn upload của server', 'quiz-bank'); ?></li></li>
    </ul>
</div>

<script type="text/javascript">
jQuery(document).ready(function($) {
    var menuStructure = {};
    
    // Load menu structure from server
    function loadMenuStructure() {
        $.post(quiz_bank_ajax.ajax_url, {
            action: 'quiz_bank_action',
            quiz_action: 'get_menu_structure',
            nonce: quiz_bank_ajax.nonce
        }, function(response) {
            if (response.success) {
                menuStructure = response.data;
            }
        });
    }
    
    // Initialize menu structure
    loadMenuStructure();
    
    // Handle import method toggle
    $('input[name="import_method"]').on('change', function() {
        var method = $(this).val();
        if (method === 'file') {
            $('#file-import-section').show();
            $('#text-import-section').hide();
            $('#import_file').prop('required', true);
            $('#import_text').prop('required', false);
        } else {
            $('#file-import-section').hide();
            $('#text-import-section').show();
            $('#import_file').prop('required', false);
            $('#import_text').prop('required', true);
        }
    });
    
    // Handle grade selection
    $('#import_lop').on('change', function() {
        var grade = $(this).val();
        var $chuong = $('#import_chuong');
        var $baiHoc = $('#import_bai_hoc');
        
        // Clear and reset chapter and lesson dropdowns
        $chuong.html('<option value="">Chọn chương</option>');
        $baiHoc.html('<option value="">Chọn bài học</option>');
        
        if (grade && menuStructure.grades && menuStructure.grades[grade]) {
            // Populate chapters for selected grade
            var chapters = menuStructure.grades[grade].chapters;
            $.each(chapters, function(chapterId, chapterData) {
                $chuong.append('<option value="' + chapterId + '">' + chapterData.name + '</option>');
            });
        }
    });
    
    // Handle chapter selection
    $('#import_chuong').on('change', function() {
        var grade = $('#import_lop').val();
        var chapter = $(this).val();
        var $baiHoc = $('#import_bai_hoc');
        var $dang = $('#import_dang');
        
        // Clear lesson and type dropdowns
        $baiHoc.html('<option value="">Chọn bài học</option>');
        $dang.html('<option value="">Chọn dạng</option>');
        
        if (grade && chapter && menuStructure.grades && menuStructure.grades[grade] && menuStructure.grades[grade].chapters[chapter]) {
            // Populate lessons for selected chapter
            var lessons = menuStructure.grades[grade].chapters[chapter].lessons;
            $.each(lessons, function(lessonId, lessonData) {
                $baiHoc.append('<option value="' + lessonId + '">Bài ' + lessonId + ': ' + lessonData.name + '</option>');
            });
        }
    });
    
    // Handle lesson selection
    $('#import_bai_hoc').on('change', function() {
        var grade = $('#import_lop').val();
        var chapter = $('#import_chuong').val();
        var lesson = $(this).val();
        var $dang = $('#import_dang');
        
        // Clear type dropdown
        $dang.html('<option value="">Chọn dạng</option>');
        
        if (grade && chapter && lesson && 
            menuStructure.grades && 
            menuStructure.grades[grade] && 
            menuStructure.grades[grade].chapters[chapter] && 
            menuStructure.grades[grade].chapters[chapter].lessons[lesson] &&
            menuStructure.grades[grade].chapters[chapter].lessons[lesson].types) {
                
            // Populate types for selected lesson
            var types = menuStructure.grades[grade].chapters[chapter].lessons[lesson].types;
            $.each(types, function(typeId, typeName) {
                $dang.append('<option value="' + typeId + '">Dạng ' + typeId + ': ' + typeName + '</option>');
            });
        }
    });
});
</script>