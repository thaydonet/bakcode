<?php
/**
 * Quiz Bank Import Class
 * 
 * Handles importing questions from JSON files
 */

class QuizBankImport {
    
    private $db;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->db = new QuizBankDatabase();
        $this->init_hooks();
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        add_action('admin_post_quiz_bank_import', array($this, 'process_import'));
    }
    
    /**
     * Display import page
     */
    public function display_import_page() {
        if (isset($_GET['message'])) {
            $this->display_message($_GET['message']);
        }
        
        include QUIZ_BANK_PLUGIN_DIR . 'admin/import.php';
    }
    
    /**
     * Process import
     */
    public function process_import() {
        try {
            error_log('Quiz Bank: Starting import process - POST data: ' . print_r($_POST, true));
            error_log('Quiz Bank: FILES data: ' . print_r($_FILES, true));
            
            if (!wp_verify_nonce($_POST['_wpnonce'], 'quiz_bank_import')) {
                error_log('Quiz Bank: Import nonce verification failed');
                wp_die(__('Security check failed', 'quiz-bank'));
            }
            
            // Get form values
            $import_lop = sanitize_text_field($_POST['import_lop']);
            $import_chuong = sanitize_text_field($_POST['import_chuong']);
            $import_bai_hoc = sanitize_text_field($_POST['import_bai_hoc']);
            $import_dang = !empty($_POST['import_dang']) ? sanitize_text_field($_POST['import_dang']) : '';
            $import_method = sanitize_text_field($_POST['import_method']);
            
            error_log('Quiz Bank: Import form data - Lop: ' . $import_lop . ', Chuong: ' . $import_chuong . ', Bai hoc: ' . $import_bai_hoc . ', Dang: ' . $import_dang . ', Method: ' . $import_method);
            
            if (empty($import_lop) || empty($import_chuong) || empty($import_bai_hoc)) {
                error_log('Quiz Bank: Missing import form data');
                wp_redirect(admin_url('admin.php?page=quiz-bank-import&message=missing_info'));
                exit;
            }
            
            // Get JSON content based on import method
            $json_content = '';
            if ($import_method === 'file') {
                // File import method
                if (!isset($_FILES['import_file']) || $_FILES['import_file']['error'] !== UPLOAD_ERR_OK) {
                    wp_redirect(admin_url('admin.php?page=quiz-bank-import&message=file_error'));
                    exit;
                }
                
                $file = $_FILES['import_file'];
                
                // Check file type
                $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                if ($file_extension !== 'json') {
                    wp_redirect(admin_url('admin.php?page=quiz-bank-import&message=invalid_format'));
                    exit;
                }
                
                // Read file content
                $json_content = file_get_contents($file['tmp_name']);
                if ($json_content === false) {
                    wp_redirect(admin_url('admin.php?page=quiz-bank-import&message=read_error'));
                    exit;
                }
            } else {
                // Text import method
                if (empty($_POST['import_text'])) {
                    wp_redirect(admin_url('admin.php?page=quiz-bank-import&message=text_empty'));
                    exit;
                }
                
                $json_content = stripslashes($_POST['import_text']);
            }
            
            // Parse JSON
            $data = json_decode($json_content, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                error_log('Quiz Bank JSON Error: ' . json_last_error_msg());
                wp_redirect(admin_url('admin.php?page=quiz-bank-import&message=json_error'));
                exit;
            }
            
            // Validate structure
            if (!$this->validate_import_data($data)) {
                error_log('Quiz Bank: Invalid data structure - ' . print_r($data, true));
                wp_redirect(admin_url('admin.php?page=quiz-bank-import&message=structure_error'));
                exit;
            }
            
            // Process and enhance questions with form data
            $processed_questions = array();
            foreach ($data['questions'] as $question) {
                $processed_question = array(
                    'lop' => $import_lop,
                    'chuong' => $import_chuong,
                    'bai_hoc' => $import_bai_hoc,
                    'dang' => !empty($import_dang) ? $import_dang : (isset($question['dang']) ? $question['dang'] : '1'),
                    'type' => isset($question['type']) ? $question['type'] : 'mcq',
                    'muc_do' => isset($question['muc_do']) ? $question['muc_do'] : 'Nhận biết',
                    'cau_hoi' => isset($question['question']) ? $question['question'] : $question['cau_hoi'],
                    'correct_option' => $question['correct_option'],
                    'explanation' => isset($question['explanation']) ? $question['explanation'] : ''
                );
                
                // Handle different question types - All types now use correct_option
                $processed_question['option_a'] = isset($question['option_a']) ? $question['option_a'] : '';
                $processed_question['option_b'] = isset($question['option_b']) ? $question['option_b'] : '';
                $processed_question['option_c'] = isset($question['option_c']) ? $question['option_c'] : '';
                $processed_question['option_d'] = isset($question['option_d']) ? $question['option_d'] : '';
                $processed_question['correct_answer'] = ''; // Not used anymore
                
                $processed_questions[] = $processed_question;
            }
            
            // Import questions
            $result = $this->db->bulk_insert_questions($processed_questions);
            
            $redirect_url = admin_url('admin.php?page=quiz-bank-import&message=success&imported=' . $result['success_count'] . '&errors=' . $result['error_count']);
            wp_redirect($redirect_url);
            exit;
        } catch (Exception $e) {
            error_log('Quiz Bank Error in process_import: ' . $e->getMessage());
            wp_redirect(admin_url('admin.php?page=quiz-bank-import&message=error'));
            exit;
        }
    }
    
    /**
     * Validate import data structure
     * 
     * @param array $data
     * @return bool
     */
    private function validate_import_data($data) {
        if (!is_array($data) || !isset($data['questions']) || !is_array($data['questions'])) {
            return false;
        }
        
        foreach ($data['questions'] as $question) {
            if (!is_array($question)) {
                return false;
            }
            
            // Check question text (either 'question' or 'cau_hoi')
            if (!isset($question['question']) && !isset($question['cau_hoi'])) {
                return false;
            }
            
            // Check question type
            $type = isset($question['type']) ? $question['type'] : 'mcq';
            if (!in_array($type, array('mcq', 'msq', 'sa'))) {
                return false;
            }
            
            // Check correct option - all question types now use correct_option
            if (!isset($question['correct_option']) || empty($question['correct_option'])) {
                return false;
            }
            
            // For MCQ and MSQ, validate options and correct_option
            if (in_array($type, array('mcq', 'msq'))) {
                $required_options = array('option_a', 'option_b', 'option_c', 'option_d');
                foreach ($required_options as $option) {
                    if (!isset($question[$option]) || empty($question[$option])) {
                        return false;
                    }
                }
                
                // Validate correct option format
                if (isset($question['correct_option'])) {
                    $correct_option = $question['correct_option'];
                    if ($type === 'mcq') {
                        // Single correct answer: A, B, C, or D
                        if (!in_array($correct_option, array('A', 'B', 'C', 'D'))) {
                            return false;
                        }
                    } elseif ($type === 'msq') {
                        // Multiple correct answers: A,B or A,C,D etc.
                        $correct_options = array_map('trim', explode(',', $correct_option));
                        foreach ($correct_options as $option) {
                            if (!in_array($option, array('A', 'B', 'C', 'D'))) {
                                return false;
                            }
                        }
                    }
                }
            } elseif ($type === 'sa') {
                // For short answer, correct_option can be any text answer
                // No additional validation needed for SA type
            }
        }
        
        return true;
    }
    
    /**
     * Display message
     * 
     * @param string $message
     */
    private function display_message($message) {
        switch ($message) {
            case 'success':
                $imported = isset($_GET['imported']) ? intval($_GET['imported']) : 0;
                $errors = isset($_GET['errors']) ? intval($_GET['errors']) : 0;
                echo '<div class="notice notice-success is-dismissible">';
                echo '<p>' . sprintf(__('Import thành công! Đã thêm %d câu hỏi. Có %d lỗi.', 'quiz-bank'), $imported, $errors) . '</p>';
                echo '</div>';
                break;
            case 'missing_info':
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p>' . __('Vui lòng chọn lớp và nhập tên bài học.', 'quiz-bank') . '</p>';
                echo '</div>';
                break;
            case 'file_error':
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p>' . __('Lỗi upload file. Vui lòng thử lại.', 'quiz-bank') . '</p>';
                echo '</div>';
                break;
            case 'text_empty':
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p>' . __('Vui lòng nhập nội dung JSON vào ô text.', 'quiz-bank') . '</p>';
                echo '</div>';
                break;
            case 'invalid_format':
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p>' . __('File không đúng định dạng. Chỉ chấp nhận file JSON.', 'quiz-bank') . '</p>';
                echo '</div>';
                break;
            case 'read_error':
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p>' . __('Không thể đọc file. Vui lòng kiểm tra lại file.', 'quiz-bank') . '</p>';
                echo '</div>';
                break;
            case 'json_error':
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p>' . __('File JSON không hợp lệ. Vui lòng kiểm tra cú pháp.', 'quiz-bank') . '</p>';
                echo '</div>';
                break;
            case 'structure_error':
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p>' . __('Cấu trúc dữ liệu không đúng. Vui lòng xem hướng dẫn.', 'quiz-bank') . '</p>';
                echo '</div>';
                break;
            case 'error':
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p>' . __('Có lỗi xảy ra trong quá trình xử lý. Vui lòng kiểm tra lại.', 'quiz-bank') . '</p>';
                echo '</div>';
                break;
        }
    }
    
    /**
     * Generate sample JSON structure
     * 
     * @return string
     */
    public function get_sample_json() {
        $sample = array(
            'questions' => array(
                array(
                    'type' => 'mcq',
                    'question' => 'Trong các hàm số sau, hàm số nào đồng biến trên $\\mathbb{R}$?',
                    'option_a' => '$y=x^3-x$',
                    'option_b' => '$y=x^4$',
                    'option_c' => '$y=2x+1$',
                    'option_d' => '$y=\\frac{1}{x}$',
                    'correct_option' => 'C',
                    'muc_do' => 'Nhận biết',
                    'explanation' => 'Để xét tính đồng biến, nghịch biến của hàm số, ta cần tính đạo hàm của hàm số đó. Hàm số $y=ax+b$ với $a>0$ luôn đồng biến trên $\\mathbb{R}$. Hàm số $y=2x+1$ có $y\'=2 > 0$ với mọi $x \\in \\mathbb{R}$. Vậy hàm số $y=2x+1$ đồng biến trên $\\mathbb{R}$.'
                ),
                array(
                    'type' => 'msq',
                    'question' => 'Chọn các phương án đúng về hàm số bậc hai (đáp án nhiều lựa chọn):',
                    'option_a' => 'Hàm số bậc hai luôn có đồ thị là parabol',
                    'option_b' => 'Trục đối xứng của parabol luôn là trục Oy',
                    'option_c' => 'Hàm số bậc hai có thể không có nghiệm',
                    'option_d' => 'Parabol luôn có đỉnh',
                    'correct_option' => 'A,C,D',
                    'muc_do' => 'Vận dụng',
                    'explanation' => 'A đúng: Hàm bậc hai luôn có đồ thị parabol. B sai: Trục đối xứng là x=-b/2a. C đúng: Khi delta < 0. D đúng: Parabol luôn có đỉnh.'
                ),
                array(
                    'type' => 'sa',
                    'question' => 'Viết công thức tính diện tích hình tròn có bán kính r:',
                    'correct_option' => 'S = πr²',
                    'muc_do' => 'Nhận biết',
                    'explanation' => 'Diện tích hình tròn bằng π nhân với bình phương bán kính: S = πr²'
                )
            )
        );
        
        return json_encode($sample, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
}