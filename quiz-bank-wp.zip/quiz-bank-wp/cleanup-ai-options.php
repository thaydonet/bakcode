<?php
/**
 * AI Options Cleanup Script
 * 
 * This script removes all AI-related database options from WordPress
 * Run this once after removing AI functionality to clean up the database
 */

// Load WordPress
require_once('../../../wp-load.php');

// Check user permissions
if (!current_user_can('manage_options')) {
    die('Permission denied. You must be an administrator to run this script.');
}

echo "<!DOCTYPE html>
<html>
<head>
    <title>Quiz Bank AI Cleanup</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .success { color: green; }
        .info { color: blue; }
        .warning { color: orange; }
    </style>
</head>
<body>";

echo "<h1>Quiz Bank AI Options Cleanup</h1>";

// List of AI-related options to remove
$ai_options = array(
    'quiz_bank_gemini_api_key'
);

echo "<h2>Cleaning up AI-related database options...</h2>";

foreach ($ai_options as $option) {
    $option_value = get_option($option, null);
    
    if ($option_value !== null) {
        $deleted = delete_option($option);
        if ($deleted) {
            echo "<p class='success'>✓ Removed option: {$option}</p>";
        } else {
            echo "<p class='warning'>⚠ Failed to remove option: {$option}</p>";
        }
    } else {
        echo "<p class='info'>ℹ Option not found: {$option}</p>";
    }
}

echo "<h2>Cleanup Complete!</h2>";
echo "<p>All AI-related database options have been processed.</p>";
echo "<p><strong>Note:</strong> You can safely delete this cleanup script file after running it.</p>";

echo "</body></html>";
?>