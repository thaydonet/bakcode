<?php
if (!defined('ABSPATH')) {
    exit;
}

$db = new QuizBankDatabase();
$menu_config = QuizBankMenuConfig::getInstance();
$grades = $db->get_all_grades();
if (empty($grades)) {
    $grades = array('12', '11', '10');
}

// Get existing filter data for dropdowns
$chapters = array();
$lessons = array();
$types = array();
$categories = array();

if (!empty($filters['lop'])) {
    $chapters = $db->get_chapters_by_grade($filters['lop']);
    
    if (!empty($filters['chuong'])) {
        $lessons = $db->get_lessons_by_grade_chapter($filters['lop'], $filters['chuong']);
    } else {
        $lessons = $db->get_lessons_by_grade($filters['lop']);
    }
    
    if (!empty($filters['bai_hoc'])) {
        if (!empty($filters['chuong'])) {
            $types = $db->get_types_by_grade_chapter_lesson($filters['lop'], $filters['chuong'], $filters['bai_hoc']);
        } else {
            $types = $db->get_types_by_grade_lesson($filters['lop'], $filters['bai_hoc']);
        }
        
        if (!empty($filters['dang'])) {
            $categories = $db->get_categories_by_grade_lesson_type($filters['lop'], $filters['bai_hoc'], $filters['dang']);
        }
    }
}
?>

<div class="wrap">
    <h1><?php _e('Danh sách câu hỏi trắc nghiệm', 'quiz-bank'); ?></h1>
    
    <?php if (isset($_GET['message'])): ?>
        <div class="notice notice-success is-dismissible">
            <p><?php 
                switch ($_GET['message']) {
                    case 'success':
                        _e('Câu hỏi đã được thêm thành công!', 'quiz-bank');
                        break;
                    case 'updated':
                        _e('Câu hỏi đã được cập nhật thành công!', 'quiz-bank');
                        break;
                    case 'deleted':
                        _e('Câu hỏi đã được xóa thành công!', 'quiz-bank');
                        break;
                }
            ?></p>
        </div>
    <?php endif; ?>
    
    <!-- Filters -->
    <div class="quiz-bank-filters">
        <form method="get" id="quiz-bank-filter-form">
            <input type="hidden" name="page" value="quiz-bank">
            
            <div class="filter-row">
                <select name="lop" id="filter-lop">
                    <option value=""><?php _e('Tất cả lớp', 'quiz-bank'); ?></option>
                    <?php foreach ($grades as $grade): ?>
                        <option value="<?php echo esc_attr($grade); ?>" <?php selected($filters['lop'], $grade); ?>>
                            Toán <?php echo esc_html($grade); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <select name="chuong" id="filter-chuong">
                    <option value=""><?php _e('Tất cả chương', 'quiz-bank'); ?></option>
                    <?php foreach ($chapters as $chapter): ?>
                        <option value="<?php echo esc_attr($chapter); ?>" <?php selected($filters['chuong'], $chapter); ?>>
                            <?php 
                            if (!empty($filters['lop'])) {
                                echo esc_html($menu_config->get_chapter_name($filters['lop'], $chapter));
                            } else {
                                echo 'Chương ' . esc_html($chapter);
                            }
                            ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <select name="bai_hoc" id="filter-bai-hoc">
                    <option value=""><?php _e('Tất cả bài học', 'quiz-bank'); ?></option>
                    <?php foreach ($lessons as $lesson): ?>
                        <option value="<?php echo esc_attr($lesson); ?>" <?php selected($filters['bai_hoc'], $lesson); ?>>
                            <?php 
                            if (!empty($filters['lop']) && !empty($filters['chuong'])) {
                                echo esc_html($menu_config->get_lesson_name($filters['lop'], $filters['chuong'], $lesson));
                            } else {
                                echo 'Bài ' . esc_html($lesson);
                            }
                            ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <select name="dang" id="filter-dang">
                    <option value=""><?php _e('Tất cả dạng', 'quiz-bank'); ?></option>
                    <?php foreach ($types as $type): ?>
                        <option value="<?php echo esc_attr($type); ?>" <?php selected($filters['dang'], $type); ?>>
                            <?php 
                            if (!empty($filters['lop']) && !empty($filters['chuong']) && !empty($filters['bai_hoc'])) {
                                echo esc_html($menu_config->get_type_name($filters['lop'], $filters['chuong'], $filters['bai_hoc'], $type));
                            } else {
                                echo 'Dạng ' . esc_html($type);
                            }
                            ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <select name="muc_do" id="filter-muc-do">
                    <option value=""><?php _e('Tất cả mức độ', 'quiz-bank'); ?></option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo esc_attr($category); ?>" <?php selected($filters['muc_do'], $category); ?>>
                            <?php echo esc_html($category); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <select name="type" id="filter-type">
                    <option value=""><?php _e('Tất cả loại', 'quiz-bank'); ?></option>
                    <option value="mcq" <?php selected($filters['type'], 'mcq'); ?>>MCQ</option>
                    <option value="msq" <?php selected($filters['type'], 'msq'); ?>>MSQ</option>
                    <option value="sa" <?php selected($filters['type'], 'sa'); ?>>SA</option>
                </select>
                
                <input type="text" name="search" value="<?php echo esc_attr($filters['search']); ?>" placeholder="<?php _e('Tìm kiếm...', 'quiz-bank'); ?>">
                
                <button type="submit" class="button"><?php _e('Lọc', 'quiz-bank'); ?></button>
                <a href="<?php echo admin_url('admin.php?page=quiz-bank'); ?>" class="button"><?php _e('Xóa bộ lọc', 'quiz-bank'); ?></a>
            </div>
        </form>
    </div>
    
    <!-- Export controls -->
    <div class="quiz-bank-export-controls">
        <button type="button" id="select-all-questions" class="button"><?php _e('Chọn tất cả', 'quiz-bank'); ?></button>
        <button type="button" id="clear-all-selections" class="button"><?php _e('Bỏ chọn tất cả', 'quiz-bank'); ?></button>
        <button type="button" id="export-txt" class="button button-secondary"><?php _e('Xuất TXT', 'quiz-bank'); ?></button>
        <button type="button" id="export-word" class="button button-secondary"><?php _e('Xuất Word', 'quiz-bank'); ?></button>
        <span id="selected-count">0 câu hỏi được chọn</span>
        
        <!-- View toggle -->
        <div class="view-toggle">
            <button type="button" id="grid-view" class="view-btn active" title="Xem dạng lưới">
                <span class="dashicons dashicons-grid-view"></span>
            </button>
            <button type="button" id="table-view" class="view-btn" title="Xem dạng bảng">
                <span class="dashicons dashicons-list-view"></span>
            </button>
        </div>
    </div>
    
    <!-- Questions grid/card layout -->
    <form id="quiz-bank-questions-form">
        <div class="quiz-bank-questions-grid" style="display: block;">
            <?php if (!empty($questions)): ?>
                <?php foreach ($questions as $question): ?>
                    <div class="question-card">
                        <div class="question-header">
                            <div class="question-checkbox-wrapper">
                                <input type="checkbox" name="question_ids[]" value="<?php echo $question->id; ?>" class="question-checkbox">
                            </div>
                            <div class="question-meta">
                                <span class="question-type question-type-<?php echo esc_attr($question->type); ?>">
                                    <?php echo strtoupper(esc_html($question->type)); ?>
                                </span>
                                <span class="question-grade">Toán <?php echo esc_html($question->lop); ?></span>
                            </div>
                            <div class="question-actions">
                                <a href="<?php echo admin_url('admin.php?page=quiz-bank&action=edit&id=' . $question->id); ?>" 
                                   class="button button-small edit-btn" title="Chỉnh sửa">
                                    <span class="dashicons dashicons-edit"></span>
                                </a>
                                <button type="button" class="button button-small delete-question delete-btn" 
                                        data-id="<?php echo $question->id; ?>" title="Xóa">
                                    <span class="dashicons dashicons-trash"></span>
                                </button>
                            </div>
                        </div>
                        
                        <div class="question-content">
                            <div class="question-text">
                                <?php echo wp_kses($question->cau_hoi, array(
                                    'p' => array(),
                                    'br' => array(),
                                    'strong' => array(),
                                    'em' => array(),
                                    'u' => array(),
                                    'span' => array('class' => array()),
                                    'sub' => array(),
                                    'sup' => array(),
                                    'div' => array('class' => array()),
                                )); ?>
                            </div>
                            
                            <?php if ($question->type !== 'sa'): // Only show options for MCQ and MSQ ?>
                                <div class="question-options">
                                    <div class="options-row">
                                        <div class="option-item <?php echo ($question->correct_option === 'A' || strpos($question->correct_option, 'A') !== false) ? 'correct-option' : ''; ?>">
                                            <span class="option-label">A.</span>
                                            <span class="option-text"><?php echo wp_kses($question->option_a, array(
                                                'p' => array(),
                                                'br' => array(),
                                                'strong' => array(),
                                                'em' => array(),
                                                'u' => array(),
                                                'span' => array('class' => array()),
                                                'sub' => array(),
                                                'sup' => array(),
                                            )); ?></span>
                                        </div>
                                        <div class="option-item <?php echo ($question->correct_option === 'B' || strpos($question->correct_option, 'B') !== false) ? 'correct-option' : ''; ?>">
                                            <span class="option-label">B.</span>
                                            <span class="option-text"><?php echo wp_kses($question->option_b, array(
                                                'p' => array(),
                                                'br' => array(),
                                                'strong' => array(),
                                                'em' => array(),
                                                'u' => array(),
                                                'span' => array('class' => array()),
                                                'sub' => array(),
                                                'sup' => array(),
                                            )); ?></span>
                                        </div>
                                    </div>
                                    <div class="options-row">
                                        <div class="option-item <?php echo ($question->correct_option === 'C' || strpos($question->correct_option, 'C') !== false) ? 'correct-option' : ''; ?>">
                                            <span class="option-label">C.</span>
                                            <span class="option-text"><?php echo wp_kses($question->option_c, array(
                                                'p' => array(),
                                                'br' => array(),
                                                'strong' => array(),
                                                'em' => array(),
                                                'u' => array(),
                                                'span' => array('class' => array()),
                                                'sub' => array(),
                                                'sup' => array(),
                                            )); ?></span>
                                        </div>
                                        <div class="option-item <?php echo ($question->correct_option === 'D' || strpos($question->correct_option, 'D') !== false) ? 'correct-option' : ''; ?>">
                                            <span class="option-label">D.</span>
                                            <span class="option-text"><?php echo wp_kses($question->option_d, array(
                                                'p' => array(),
                                                'br' => array(),
                                                'strong' => array(),
                                                'em' => array(),
                                                'u' => array(),
                                                'span' => array('class' => array()),
                                                'sub' => array(),
                                                'sup' => array(),
                                            )); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php else: // Show answer for SA type ?>
                                <div class="sa-answer">
                                    <strong>Đáp án:</strong> <?php echo esc_html($question->correct_option ?? ''); ?>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($question->explanation)): ?>
                                <div class="explanation-section">
                                    <button type="button" class="explanation-toggle" data-question-id="<?php echo $question->id; ?>">
                                        <span class="dashicons dashicons-visibility"></span>
                                        <span class="toggle-text">Hiện lời giải</span>
                                    </button>
                                    <div class="explanation-content" id="explanation-<?php echo $question->id; ?>" style="display: none;">
                                        <div class="explanation-text">
                                            <?php echo wp_kses($question->explanation, array(
                                                'p' => array(),
                                                'br' => array(),
                                                'strong' => array(),
                                                'em' => array(),
                                                'u' => array(),
                                                'span' => array('class' => array()),
                                                'sub' => array(),
                                                'sup' => array(),
                                                'div' => array('class' => array()),
                                            )); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="question-details">
                            <div class="detail-item">
                                <span class="label">Chương:</span>
                                <span class="value"><?php 
                                    echo esc_html($menu_config->get_chapter_name($question->lop, $question->chuong));
                                ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Bài:</span>
                                <span class="value"><?php 
                                    echo esc_html($menu_config->get_lesson_name($question->lop, $question->chuong, $question->bai_hoc));
                                ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Dạng:</span>
                                <span class="value"><?php 
                                    echo esc_html($menu_config->get_type_name($question->lop, $question->chuong, $question->bai_hoc, $question->dang));
                                ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="label">Mức độ:</span>
                                <span class="value level-<?php echo sanitize_html_class(strtolower($question->muc_do)); ?>">
                                    <?php echo esc_html($question->muc_do); ?>
                                </span>
                            </div>
                            <div class="detail-item correct-answer">
                                <span class="label">Đáp án đúng:</span>
                                <span class="value answer"><?php echo esc_html($question->correct_option ?? ''); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="no-questions">
                    <div class="no-questions-icon">
                        <span class="dashicons dashicons-clipboard"></span>
                    </div>
                    <h3>Chưa có câu hỏi nào</h3>
                    <p>Hãy bắt đầu bằng cách thêm câu hỏi đầu tiên của bạn.</p>
                    <a href="<?php echo admin_url('admin.php?page=quiz-bank-add'); ?>" class="button button-primary">
                        <span class="dashicons dashicons-plus-alt"></span> Thêm câu hỏi mới
                    </a>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Traditional table view -->
        <div class="quiz-bank-questions-table" style="display: none;">
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <td class="manage-column column-cb check-column">
                            <input type="checkbox" id="cb-select-all">
                        </td>
                        <th><?php _e('Câu hỏi', 'quiz-bank'); ?></th>
                        <th><?php _e('Toán', 'quiz-bank'); ?></th>
                        <th><?php _e('Chương', 'quiz-bank'); ?></th>
                        <th><?php _e('Bài học', 'quiz-bank'); ?></th>
                        <th><?php _e('Dạng', 'quiz-bank'); ?></th>
                        <th><?php _e('Mức độ', 'quiz-bank'); ?></th>
                        <th><?php _e('Loại', 'quiz-bank'); ?></th>
                        <th><?php _e('Đáp án', 'quiz-bank'); ?></th>
                        <th><?php _e('Thao tác', 'quiz-bank'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($questions)): ?>
                        <?php foreach ($questions as $question): ?>
                            <tr>
                                <th class="check-column">
                                    <input type="checkbox" name="question_ids[]" value="<?php echo $question->id; ?>" class="question-checkbox">
                                </th>
                                <td>
                                    <strong><?php echo wp_trim_words(strip_tags($question->cau_hoi), 10); ?></strong>
                                </td>
                                <td><?php echo esc_html($question->lop); ?></td>
                                <td><?php echo esc_html($question->chuong); ?></td>
                                <td><?php echo esc_html($question->bai_hoc); ?></td>
                                <td><?php echo esc_html($question->dang); ?></td>
                                <td><?php echo esc_html($question->muc_do); ?></td>
                                <td><span class="question-type-<?php echo esc_attr($question->type); ?>"><?php echo strtoupper(esc_html($question->type)); ?></span></td>
                                <td><strong><?php echo esc_html($question->correct_option ?? ''); ?></strong></td>
                                <td>
                                    <a href="<?php echo admin_url('admin.php?page=quiz-bank&action=edit&id=' . $question->id); ?>" class="button button-small"><?php _e('Sửa', 'quiz-bank'); ?></a>
                                    <button type="button" class="button button-small delete-question" data-id="<?php echo $question->id; ?>"><?php _e('Xóa', 'quiz-bank'); ?></button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9"><?php _e('Không có câu hỏi nào.', 'quiz-bank'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </form>

    
    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
        <div class="tablenav-pages">
            <?php
            echo paginate_links(array(
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'prev_text' => '&laquo;',
                'next_text' => '&raquo;',
                'total' => $total_pages,
                'current' => $current_page
            ));
            ?>
        </div>
    <?php endif; ?>
</div>

<script>
// Trigger LaTeX rendering when page loads
jQuery(document).ready(function($) {
    // Trigger LaTeX rendering after a short delay to ensure content is loaded
    setTimeout(function() {
        if (typeof initializeLaTeXRendering === 'function') {
            initializeLaTeXRendering();
        }
        // Trigger custom event for LaTeX rendering
        $(document).trigger('latex-render-needed');
    }, 500);
});
</script>