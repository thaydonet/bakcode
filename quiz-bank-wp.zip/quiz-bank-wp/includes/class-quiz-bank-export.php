<?php
/**
 * Quiz Bank Export Class - Optimized Version
 * 
 * Handles exporting questions to various formats with reduced code duplication
 */

class QuizBankExport {
    
    private $db;
    private $template;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->db = new QuizBankDatabase();
        $this->template = new ExportTemplate();
    }
    
    /**
     * Export questions to specified format
     * 
     * @param array $question_ids Array of question IDs
     * @param string $format Export format (txt, word)
     * @param array $options Export options
     * @return string|false Download URL on success, false on failure
     */
    public function export_questions($question_ids, $format = 'txt', $options = []) {
        $questions = $this->db->get_questions_by_ids($question_ids);
        
        if (empty($questions)) {
            return false;
        }
        
        $options = array_merge([
            'exam_mode' => false,
            'exam_code' => null,
            'shuffle_questions' => false,
            'shuffle_answers' => false,
            'num_exams' => 1
        ], $options);
        
        // Handle multiple exams
        if ($options['num_exams'] > 1) {
            return $this->export_multiple_exams($questions, $format, $options);
        }
        
        // Single export
        $content = $this->generate_content($questions, $format, $options);
        $filename = $this->generate_filename($format, $options['exam_code']);
        
        return $this->save_and_get_download_url($content, $filename);
    }
    
    /**
     * Force immediate file download
     */
    public function force_download($question_ids, $format = 'txt', $options = []) {
        $questions = $this->db->get_questions_by_ids($question_ids);
        
        if (empty($questions)) {
            wp_die('No questions found for export.');
        }
        
        $options = array_merge([
            'exam_mode' => false,
            'exam_code' => null,
            'shuffle_questions' => false,
            'shuffle_answers' => false,
            'num_exams' => 1
        ], $options);
        
        // Handle multiple exams
        if ($options['num_exams'] > 1) {
            $this->download_multiple_exams($questions, $format, $options);
            return;
        }
        
        // Single download
        $content = $this->generate_content($questions, $format, $options);
        $filename = $this->generate_filename($format, $options['exam_code']);
        $content_type = $this->get_content_type($format);
        
        $this->output_file_download($content, $filename, $content_type);
    }
    
    /**
     * Generate content based on format and options
     */
    private function generate_content($questions, $format, $options) {
        // Prepare questions
        $prepared_questions = $this->prepare_questions($questions, $options);
        
        switch ($format) {
            case 'txt':
                return $this->template->generate_txt($prepared_questions, $options);
            case 'word':
                return $this->template->generate_docx($prepared_questions, $options);
            default:
                throw new InvalidArgumentException('Invalid export format.');
        }
    }
    
    /**
     * Prepare questions (group, shuffle, etc.)
     */
    private function prepare_questions($questions, $options) {
        // Group questions by type
        $grouped = $this->group_questions_by_type($questions);
        
        // Shuffle questions if needed
        if ($options['shuffle_questions']) {
            foreach ($grouped as $type => $type_questions) {
                shuffle($grouped[$type]);
            }
        }
        
        // Shuffle answers for MCQ if needed
        if ($options['shuffle_answers']) {
            $grouped['mcq'] = $this->shuffle_mcq_answers($grouped['mcq']);
        }
        
        return $grouped;
    }
    
    /**
     * Group questions by type
     */
    private function group_questions_by_type($questions) {
        $grouped = ['mcq' => [], 'msq' => [], 'sa' => []];
        
        foreach ($questions as $question) {
            $type = $question->type ?? 'mcq';
            $grouped[$type][] = $question;
        }
        
        return $grouped;
    }
    
    /**
     * Shuffle MCQ answers while maintaining correct answer
     */
    private function shuffle_mcq_answers($mcq_questions) {
        foreach ($mcq_questions as $question) {
            $options = [
                'A' => $question->option_a,
                'B' => $question->option_b,
                'C' => $question->option_c,
                'D' => $question->option_d
            ];
            
            $shuffled = $this->shuffle_mcq_options($options, $question->correct_option);
            
            // Update question with shuffled options
            $question->option_a = $shuffled['options']['A'];
            $question->option_b = $shuffled['options']['B'];
            $question->option_c = $shuffled['options']['C'];
            $question->option_d = $shuffled['options']['D'];
            $question->correct_option = $shuffled['correct'];
        }
        
        return $mcq_questions;
    }
    
    /**
     * Shuffle MCQ options utility
     */
    private function shuffle_mcq_options($options, $correct_answer) {
        $option_texts = array_values($options);
        $option_keys = ['A', 'B', 'C', 'D'];
        
        $correct_index = array_search($correct_answer, array_keys($options));
        $correct_text = $option_texts[$correct_index];
        
        shuffle($option_texts);
        
        $new_correct_index = array_search($correct_text, $option_texts);
        $new_correct = $option_keys[$new_correct_index];
        
        $shuffled_options = array_combine($option_keys, $option_texts);
        
        return [
            'options' => $shuffled_options,
            'correct' => $new_correct
        ];
    }
    
    /**
     * Export multiple exam papers
     */
    private function export_multiple_exams($questions, $format, $options) {
        $zip_files = [];
        
        for ($exam = 1; $exam <= $options['num_exams']; $exam++) {
            $exam_code = str_pad($exam, 3, '0', STR_PAD_LEFT);
            $exam_options = array_merge($options, [
                'exam_mode' => true,
                'exam_code' => $exam_code
            ]);
            
            $content = $this->generate_content($questions, $format, $exam_options);
            $filename = $this->generate_filename($format, $exam_code);
            
            $zip_files[$filename] = $content;
        }
        
        // Set Vietnam timezone for zip filename
        $original_timezone = date_default_timezone_get();
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $zip_result = $this->create_and_save_zip($zip_files, 'exams-' . date('Y-m-d-H-i-s') . '.zip');
        date_default_timezone_set($original_timezone);
        
        return $zip_result;
    }
    
    /**
     * Download multiple exam papers
     */
    private function download_multiple_exams($questions, $format, $options) {
        $zip_files = [];
        
        for ($exam = 1; $exam <= $options['num_exams']; $exam++) {
            $exam_code = str_pad($exam, 3, '0', STR_PAD_LEFT);
            $exam_options = array_merge($options, [
                'exam_mode' => true,
                'exam_code' => $exam_code
            ]);
            
            $content = $this->generate_content($questions, $format, $exam_options);
            $filename = $this->generate_filename($format, $exam_code);
            
            $zip_files[$filename] = $content;
        }
        
        // Set Vietnam timezone for zip filename
        $original_timezone = date_default_timezone_get();
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $this->create_and_download_zip($zip_files, 'exams-' . date('Y-m-d-H-i-s') . '.zip');
        date_default_timezone_set($original_timezone);
    }
    
    /**
     * Generate filename based on format and options
     */
    private function generate_filename($format, $exam_code = null) {
        // Set Vietnam timezone
        $original_timezone = date_default_timezone_get();
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        
        $timestamp = date('Y-m-d-H-i-s');
        $prefix = $exam_code ? "exam-{$exam_code}" : 'quiz-export';
        $extension = ($format === 'word') ? 'docx' : $format;
        
        $filename = "{$prefix}-{$timestamp}.{$extension}";
        
        // Restore original timezone
        date_default_timezone_set($original_timezone);
        
        return $filename;
    }
    
    /**
     * Get content type for format
     */
    private function get_content_type($format) {
        $types = [
            'txt' => 'text/plain',
            'word' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ];
        
        return $types[$format] ?? 'text/plain';
    }
    
    /**
     * Save content to file and return download URL
     */
    private function save_and_get_download_url($content, $filename) {
        $upload_dir = wp_upload_dir();
        $quiz_dir = $upload_dir['basedir'] . '/quiz-bank-exports/';
        
        if (!file_exists($quiz_dir)) {
            wp_mkdir_p($quiz_dir);
        }
        
        $file_path = $quiz_dir . $filename;
        
        if (file_put_contents($file_path, $content) !== false) {
            return $upload_dir['baseurl'] . '/quiz-bank-exports/' . $filename;
        }
        
        return false;
    }
    
    /**
     * Output file for download
     */
    private function output_file_download($content, $filename, $content_type) {
        if (ob_get_level()) {
            ob_end_clean();
        }
        
        header('Content-Type: ' . $content_type . '; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($content));
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Expires: 0');
        
        echo $content;
        exit;
    }
    
    /**
     * Create and save zip file
     */
    private function create_and_save_zip($files, $zip_filename) {
        $upload_dir = wp_upload_dir();
        $quiz_dir = $upload_dir['basedir'] . '/quiz-bank-exports/';
        
        if (!file_exists($quiz_dir)) {
            wp_mkdir_p($quiz_dir);
        }
        
        $zip_path = $quiz_dir . $zip_filename;
        $zip = new ZipArchive();
        
        if ($zip->open($zip_path, ZipArchive::CREATE) !== TRUE) {
            return false;
        }
        
        foreach ($files as $filename => $content) {
            $zip->addFromString($filename, $content);
        }
        
        $zip->close();
        
        return $upload_dir['baseurl'] . '/quiz-bank-exports/' . $zip_filename;
    }
    
    /**
     * Create and download zip file
     */
    private function create_and_download_zip($files, $zip_filename) {
        $temp_file = tempnam(sys_get_temp_dir(), 'quiz_export_');
        $zip = new ZipArchive();
        
        if ($zip->open($temp_file, ZipArchive::CREATE) !== TRUE) {
            wp_die('Cannot create ZIP file.');
        }
        
        foreach ($files as $filename => $content) {
            $zip->addFromString($filename, $content);
        }
        
        $zip->close();
        
        $this->output_file_download(file_get_contents($temp_file), $zip_filename, 'application/zip');
        
        unlink($temp_file);
    }
}

/**
 * Export Template Class
 * 
 * Handles all template generation logic
 */
class ExportTemplate {
    
    /**
     * Generate TXT content
     */
    public function generate_txt($grouped_questions, $options) {
        $content = $this->get_txt_header($options);
        
        // For TXT format, always generate exam-style body with inline explanations
        // No separate answer key section as per requirements
        $content .= $this->generate_txt_exam_questions($grouped_questions);
        
        return $content;
    }
    
    /**
     * Generate DOCX content for Word
     */
    public function generate_docx($grouped_questions, $options) {
        // Create a proper Word document content
        $content = $this->generate_word_document($grouped_questions, $options);
        return $content;
    }
    
    /**
     * Generate Word document content
     */
    private function generate_word_document($grouped_questions, $options) {
        // Create proper Word-compatible HTML
        $html = $this->get_word_html_structure($options);
        
        // Add content sections
        $html .= $this->generate_word_questions_section($grouped_questions);
        $html .= $this->generate_word_answer_key($grouped_questions, $options);
        
        $html .= '</body></html>';
        
        return $html;
    }
    
    /**
     * Get TXT header
     */
    private function get_txt_header($options) {
        // Set Vietnam timezone
        $original_timezone = date_default_timezone_get();
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        
        // Always show as exam format for TXT
        $content = "ĐỀ THI TRẮC NGHIỆM\n";
        
        if ($options['exam_code']) {
            $content .= "Mã đề: {$options['exam_code']}\n";
        }
        
        $content .= "Ngày thi: " . date('d/m/Y H:i:s') . "\n";
        $content .= str_repeat("=", 50) . "\n\n";
        
        // Restore original timezone
        date_default_timezone_set($original_timezone);
        
        return $content;
    }
    
    /**
     * Get HTML header
     */
    private function get_html_header($options) {
        $title = "Đề thi trắc nghiệm";
        $exam_code = $options['exam_code'] ? " - Mã đề {$options['exam_code']}" : "";
        
        return '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>' . $title . $exam_code . '</title>
    <style>
        @page { 
            size: A4; 
            margin: 2cm 2cm 3cm 2cm;
            @bottom-center {
                content: "Trang " counter(page) " / " counter(pages) " - Mã đề: ' . ($options['exam_code'] ?: 'N/A') . '";
                font-size: 10pt;
                font-family: "Times New Roman", serif;
            }
        }
        body { 
            font-family: "Times New Roman", serif; 
            font-size: 13pt; 
            line-height: 1.5; 
            margin: 0;
            padding: 0;
        }
        .header { text-align: center; margin-bottom: 30px; }
        .exam-code { font-weight: bold; font-size: 16pt; }
        .section-title { 
            font-weight: bold; 
            font-size: 14pt; 
            margin-top: 25px; 
            margin-bottom: 15px; 
            text-align: center;
        }
        .section-divider { border-bottom: 1px solid #000; margin-bottom: 20px; }
        .question { margin-bottom: 20px; page-break-inside: avoid; }
        .question-text { margin-bottom: 8px; }
        .question-number { font-weight: bold; }
        .options { margin-left: 20px; }
        .option { margin-bottom: 3px; }
        .option-label { font-weight: bold; }
        .explanation { margin-top: 10px; font-weight: bold; }
        .explanation-content { margin-top: 5px; }
        .answer { font-weight: bold; margin-top: 10px; }
        .page-break { page-break-before: always; }
        .answer-section { margin-top: 30px; }
        .answer-item { margin-bottom: 15px; }
        @media print {
            @page {
                @bottom-center {
                    content: "Trang " counter(page) " / " counter(pages) " - Mã đề: ' . ($options['exam_code'] ?: 'N/A') . '";
                }
            }
        }
    </style>
</head>
<body>' . $this->get_html_header_content($options);
    }
    
    /**
     * Get HTML header content
     */
    private function get_html_header_content($options) {
        // Set Vietnam timezone
        $original_timezone = date_default_timezone_get();
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        
        $html = '<div class="header"><h1>ĐỀ THI TRẮC NGHIỆM</h1>';
        
        if ($options['exam_code']) {
            $html .= '<div class="exam-code">Mã đề: ' . $options['exam_code'] . '</div>';
        }
        
        $html .= '<p>Ngày thi: ' . date('d/m/Y H:i:s') . '</p></div>';
        
        // Restore original timezone
        date_default_timezone_set($original_timezone);
        
        return $html;
    }
    
    /**
     * Get Word-compatible HTML structure
     */
    private function get_word_html_structure($options) {
        $title = "Đề thi trắc nghiệm";
        $exam_code = $options['exam_code'] ? " - Mã đề {$options['exam_code']}" : "";
        
        // Set Vietnam timezone
        $original_timezone = date_default_timezone_get();
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        
        $html = '<!DOCTYPE html>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <meta charset="UTF-8">
    <meta name="ProgId" content="Word.Document">
    <meta name="Generator" content="Microsoft Word">
    <meta name="Originator" content="Microsoft Word">
    <title>' . $title . $exam_code . '</title>
    <!--[if gte mso 9]>
    <xml>
        <w:WordDocument>
            <w:View>Print</w:View>
            <w:Zoom>90</w:Zoom>
            <w:DoNotPromptForConvert/>
            <w:DoNotShowRevisions/>
            <w:DoNotPrintRevisions/>
            <w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery>
            <w:DisplayVerticalDrawingGridEvery>2</w:DisplayVerticalDrawingGridEvery>
            <w:UseMarginsForDrawingGridOrigin/>
        </w:WordDocument>
    </xml>
    <![endif]-->
    <style>
        @page {
            size: A4;
            margin: 2cm;
            mso-page-orientation: portrait;
        }
        body {
            font-family: "Times New Roman", serif;
            font-size: 13pt;
            line-height: 1.5;
            margin: 0;
            padding: 0;
            mso-style-parent: "";
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .header h1 {
            font-size: 16pt;
            font-weight: bold;
            margin: 10px 0;
        }
        .exam-code {
            font-weight: bold;
            font-size: 14pt;
            margin: 10px 0;
        }
        .section-title {
            font-weight: bold;
            font-size: 14pt;
            margin-top: 25px;
            margin-bottom: 15px;
            text-align: center;
        }
        .question {
            margin-bottom: 20px;
            page-break-inside: avoid;
        }
        .question-text {
            margin-bottom: 8px;
        }
        .question-number {
            font-weight: bold;
        }
        .options {
            margin-left: 20px;
        }
        .option {
            margin-bottom: 3px;
        }
        .option-label {
            font-weight: bold;
        }
        .explanation {
            margin-top: 10px;
            font-weight: bold;
        }
        .answer {
            font-weight: bold;
            margin-top: 10px;
        }
        .page-break {
            page-break-before: always;
        }
        .answer-section {
            margin-top: 30px;
        }
        .answer-item {
            margin-bottom: 15px;
        }
        p {
            margin: 6pt 0;
            mso-pagination: widow-orphan;
        }
        h1, h2, h3 {
            mso-style-next: Normal;
        }
    </style>
</head>
<body>';
        
        // Add header content
        $html .= '<div class="header">';
        $html .= '<h1>ĐỀ THI TRẮC NGHIỆM</h1>';
        
        if ($options['exam_code']) {
            $html .= '<div class="exam-code">Mã đề: ' . $options['exam_code'] . '</div>';
        }
        
        $html .= '<p>Ngày thi: ' . date('d/m/Y H:i:s') . '</p>';
        $html .= '</div>';
        
        // Restore original timezone
        date_default_timezone_set($original_timezone);
        
        return $html;
    }
    
    /**
     * Generate TXT exam questions with inline explanations
     */
    private function generate_txt_exam_questions($grouped_questions) {
        $content = "";
        $question_counter = 1;
        
        foreach (['mcq', 'msq', 'sa'] as $type) {
            if (empty($grouped_questions[$type])) continue;
            
            foreach ($grouped_questions[$type] as $question) {
                $content .= "Câu {$question_counter}: " . strip_tags($question->cau_hoi) . "\n";
                
                // Add options for MCQ and MSQ types
                if ($question->type !== 'sa') {
                    $options = [$question->option_a, $question->option_b, $question->option_c, $question->option_d];
                    // Use different labels based on question type
                    $labels = ($question->type === 'msq') ? ['a)', 'b)', 'c)', 'd)'] : ['A.', 'B.', 'C.', 'D.'];
                    
                    foreach ($labels as $i => $label) {
                        $option_text = !empty($options[$i]) ? strip_tags($options[$i]) : '';
                        $content .= "{$label} {$option_text}\n";
                    }
                }
                
                // Add explanation if available
                if (!empty($question->explanation)) {
                    $content .= "Lời giải:\n";
                    
                    // Add correct answer - now SA questions also use correct_option
                    $answer = $question->correct_option ?? '';
                    $content .= "Đáp án: {$answer}\n";
                    
                    // Add explanation content
                    $content .= strip_tags($question->explanation) . "\n";
                }
                
                $content .= "\n";
                $question_counter++;
            }
        }
        
        // Add shortcode section
        $content .= $this->generate_shortcode_section($grouped_questions);
        
        return $content;
    }
    
    /**
     * Generate HTML questions section (questions only, no explanations)
     */
    private function generate_html_questions_section($grouped_questions) {
        $html = "";
        $question_counter = 1;
        $sections = [
            'mcq' => 'Phần I: Câu hỏi trắc nghiệm 1 đáp án đúng',
            'msq' => 'Phần II: Câu hỏi Đúng - sai',
            'sa' => 'Phần III: Trả lời ngắn'
        ];
        
        foreach ($sections as $type => $title) {
            if (empty($grouped_questions[$type])) continue;
            
            $html .= '<div class="section-title"><strong>' . $title . '</strong></div>';
            $html .= '<div class="section-divider"></div>';
            
            foreach ($grouped_questions[$type] as $question) {
                $html .= '<div class="question">';
                $html .= '<div class="question-text"><span class="question-number"><strong>Câu ' . $question_counter . ':</strong></span> ' . $question->cau_hoi . '</div>';
                
                // Add options for MCQ and MSQ types (no explanations in this section)
                if ($question->type !== 'sa') {
                    $html .= $this->format_question_options($question, 'html');
                }
                
                $html .= '</div>';
                $question_counter++;
            }
        }
        
        return $html;
    }
    
    /**
     * Generate HTML answer key with questions, answers and explanations
     */
    private function generate_html_answer_key($grouped_questions, $options) {
        $html = '<div class="page-break"></div>';
        
        $html .= '<div class="header"><h1><strong>ĐÁP ÁN VÀ LỜI GIẢI</strong></h1></div>';
        
        $question_counter = 1;
        $sections = [
            'mcq' => 'Phần I: Đáp án trắc nghiệm',
            'msq' => 'Phần II: Đáp án đúng - sai',
            'sa' => 'Phần III: Đáp án trả lời ngắn'
        ];
        
        foreach ($sections as $type => $title) {
            if (empty($grouped_questions[$type])) continue;
            
            $html .= '<div class="section-title"><strong>' . $title . '</strong></div>';
            
            foreach ($grouped_questions[$type] as $question) {
                $html .= '<div class="answer-item">';
                $html .= '<strong>Câu ' . $question_counter . ':</strong> ' . $question->cau_hoi . '<br>';
                
                // Add options for MCQ and MSQ
                if ($question->type !== 'sa') {
                    $html .= $this->format_question_options($question, 'html');
                }
                
                // Add correct answer - all question types now use correct_option
                $answer = esc_html($question->correct_option);
                $html .= '<div class="answer"><strong>Lời giải</strong></div>';
                $html .= '<div class="answer"><strong>Đáp án:</strong> ' . $answer . '</div>';
                
                // Add explanation if available
                if (!empty($question->explanation)) {
                    $html .= '<div class="explanation-content">' . $question->explanation . '</div>';
                } else {
                    $html .= '<div class="explanation-content">Không có lời giải</div>';
                }
                
                $html .= '</div>';
                $question_counter++;
            }
        }
        
        return $html;
    }
    

    
    /**
     * Format question options based on type and format
     */
    private function format_question_options($question, $format) {
        if ($question->type === 'sa') {
            return '';
        }
        
        // Use different labels based on question type
        $labels = ($question->type === 'msq') ? ['a)', 'b)', 'c)', 'd)'] : ['A.', 'B.', 'C.', 'D.'];
        $options = [$question->option_a, $question->option_b, $question->option_c, $question->option_d];
        
        if ($format === 'txt') {
            $content = '';
            foreach ($labels as $i => $label) {
                // Handle missing options gracefully
                $text = !empty($options[$i]) ? strip_tags($options[$i]) : '';
                $content .= "{$label} {$text}\n";
            }
            return $content;
        } else {
            $html = '<div class="options">';
            foreach ($labels as $i => $label) {
                // Handle missing options gracefully
                $option_text = !empty($options[$i]) ? $options[$i] : '';
                $html .= '<div class="option"><span class="option-label"><strong>' . $label . '</strong></span> ' . $option_text . '</div>';
            }
            $html .= '</div>';
            return $html;
        }
    }
    
    /**
     * Generate shortcode section for TXT export
     */
    private function generate_shortcode_section($grouped_questions) {
        $shortcode = "\n\n[quiz_set]\n";
        
        $sections = [
            'mcq' => ['title' => 'Phần I: Câu hỏi trắc nghiệm 1 đáp án đúng', 'tag' => 'quiz_question'],
            'msq' => ['title' => 'Phần II: Câu hỏi Đúng - sai', 'tag' => 'quiz_question_T_F'],
            'sa' => ['title' => 'Phần III: Trả lời ngắn', 'tag' => 'quiz_question_TLN']
        ];
        
        foreach ($sections as $type => $section_info) {
            if (empty($grouped_questions[$type])) continue;
            
            // Add section header
            if ($type === 'mcq') {
                $shortcode .= '[q_group title="' . $section_info['title'] . '" single_choice_tron="y,y"]' . "\n";
            } else {
                $shortcode .= '[q_group title="' . $section_info['title'] . '"]' . "\n";
            }
            
            // Add questions for this section
            foreach ($grouped_questions[$type] as $question) {
                $shortcode .= $this->generate_question_shortcode($question, $section_info['tag']);
            }
            
            $shortcode .= "[/q_group]\n\n";
        }
        
        $shortcode .= "[/quiz_set]";
        
        return $shortcode;
    }
    
    /**
     * Generate shortcode for individual question
     */
    private function generate_question_shortcode($question, $tag) {
        $question_text = $this->clean_shortcode_text($question->cau_hoi);
        $explanation = !empty($question->explanation) ? $this->clean_shortcode_text($question->explanation) : '';
        $correct = $question->correct_option ?? '';
        
        if ($tag === 'quiz_question_TLN') {
            // SA questions - short answer format
            return '[' . $tag . ' question="' . $question_text . '" correct="' . $correct . '" explanation="' . $explanation . '"]' . "\n";
        } else {
            // MCQ and MSQ questions - with options
            $option_a = $this->clean_shortcode_text($question->option_a);
            $option_b = $this->clean_shortcode_text($question->option_b);
            $option_c = $this->clean_shortcode_text($question->option_c);
            $option_d = $this->clean_shortcode_text($question->option_d);
            
            return '[' . $tag . ' question="' . $question_text . '" option_a="' . $option_a . '" option_b="' . $option_b . '" option_c="' . $option_c . '" option_d="' . $option_d . '" correct="' . $correct . '" explanation="' . $explanation . '"]' . "\n";
        }
    }
    
    /**
     * Clean text for shortcode attributes (remove HTML tags and escape quotes)
     */
    private function clean_shortcode_text($text) {
        // Remove HTML tags
        $text = strip_tags($text);
        
        // Escape quotes for shortcode attributes
        $text = str_replace('"', '&quot;', $text);
        
        // Remove line breaks and excessive whitespace
        $text = preg_replace('/\s+/', ' ', $text);
        
        // Trim whitespace
        $text = trim($text);
        
        return $text;
    }
    
    /**
     * Generate Word questions section (questions only, no explanations)
     */
    private function generate_word_questions_section($grouped_questions) {
        $html = "";
        $question_counter = 1;
        $sections = [
            'mcq' => 'Phần I: Câu hỏi trắc nghiệm 1 đáp án đúng',
            'msq' => 'Phần II: Câu hỏi Đúng - sai',
            'sa' => 'Phần III: Trả lời ngắn'
        ];
        
        foreach ($sections as $type => $title) {
            if (empty($grouped_questions[$type])) continue;
            
            $html .= '<div class="section-title"><strong>' . $title . '</strong></div>';
            
            foreach ($grouped_questions[$type] as $question) {
                $html .= '<div class="question">';
                $html .= '<p class="question-text"><span class="question-number"><strong>Câu ' . $question_counter . ':</strong></span> ' . $question->cau_hoi . '</p>';
                
                // Add options for MCQ and MSQ types (no explanations in this section)
                if ($question->type !== 'sa') {
                    $html .= $this->format_word_question_options($question);
                }
                
                $html .= '</div>';
                $question_counter++;
            }
        }
        
        return $html;
    }
    
    /**
     * Generate Word answer key with questions, answers and explanations
     */
    private function generate_word_answer_key($grouped_questions, $options) {
        $html = '<div class="page-break"></div>';
        
        $html .= '<div class="header"><h1><strong>ĐÁP ÁN VÀ LỜI GIẢI</strong></h1></div>';
        
        $question_counter = 1;
        $sections = [
            'mcq' => 'Phần I: Đáp án trắc nghiệm',
            'msq' => 'Phần II: Đáp án đúng - sai',
            'sa' => 'Phần III: Đáp án trả lời ngắn'
        ];
        
        foreach ($sections as $type => $title) {
            if (empty($grouped_questions[$type])) continue;
            
            $html .= '<div class="section-title"><strong>' . $title . '</strong></div>';
            
            foreach ($grouped_questions[$type] as $question) {
                $html .= '<div class="answer-item">';
                $html .= '<p><strong>Câu ' . $question_counter . ':</strong> ' . $question->cau_hoi . '</p>';
                
                // Add options for MCQ and MSQ
                if ($question->type !== 'sa') {
                    $html .= $this->format_word_question_options($question);
                }
                
                // Add correct answer - all question types now use correct_option
                $answer = esc_html($question->correct_option);
                $html .= '<p class="answer"><strong>Lời giải</strong></p>';
                $html .= '<p class="answer"><strong>Đáp án:</strong> ' . $answer . '</p>';
                
                // Add explanation if available
                if (!empty($question->explanation)) {
                    $html .= '<div class="explanation-content">' . $question->explanation . '</div>';
                } else {
                    $html .= '<p class="explanation-content">Không có lời giải</p>';
                }
                
                $html .= '</div>';
                $question_counter++;
            }
        }
        
        return $html;
    }
    
    /**
     * Format question options specifically for Word export
     */
    private function format_word_question_options($question) {
        if ($question->type === 'sa') {
            return '';
        }
        
        // Use different labels based on question type
        $labels = ($question->type === 'msq') ? ['a)', 'b)', 'c)', 'd)'] : ['A.', 'B.', 'C.', 'D.'];
        $options = [$question->option_a, $question->option_b, $question->option_c, $question->option_d];
        
        $html = '<div class="options">';
        foreach ($labels as $i => $label) {
            // Handle missing options gracefully
            $option_text = !empty($options[$i]) ? $options[$i] : '';
            $html .= '<p class="option"><span class="option-label"><strong>' . $label . '</strong></span> ' . $option_text . '</p>';
        }
        $html .= '</div>';
        
        return $html;
    }
}