<?php
/*
Plugin Name: Quiz Display post
Plugin URI:
Description: Plugin hiển thị câu hỏi trắc nghiệm với tính năng tính điểm, xáo trộn và hỗ trợ nhóm câu hỏi
Version: 1.7
Author: Thay Do
*/

if (!defined('ABSPATH')) {
    exit;
}

// Kích hoạt plugin
register_activation_hook(__FILE__, 'quiz_display_activate');

function quiz_display_activate() {
    global $wpdb;

    // Tạo bảng quiz_results
    $table_name = $wpdb->prefix . 'quiz_results';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        quiz_id VARCHAR(255) NOT NULL,
        score_part_1 DECIMAL(5,2) NOT NULL DEFAULT 0.00,
        score_part_2 DECIMAL(5,2) NOT NULL DEFAULT 0.00,
        score_part_3 DECIMAL(5,2) NOT NULL DEFAULT 0.00,
        total_score DECIMAL(5,2) NOT NULL DEFAULT 0.00,
        start_time DATETIME NOT NULL,
        end_time DATETIME NOT NULL,
        student_name VARCHAR(255) NOT NULL,
        post_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // Tạo bảng quiz_answers
    $answers_table = $wpdb->prefix . 'quiz_answers';
    $sql_answers = "CREATE TABLE IF NOT EXISTS $answers_table (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        result_id BIGINT(20) UNSIGNED NOT NULL,
        question_id VARCHAR(255) NOT NULL,
        question_type VARCHAR(50) NOT NULL,
		question_content text NOT NULL,
        student_answer TEXT NOT NULL,
        is_correct TINYINT(1) NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        FOREIGN KEY (result_id) REFERENCES $table_name(id) ON DELETE CASCADE
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    dbDelta($sql_answers);
}

// Enqueue scripts
function quiz_display_enqueue_scripts() {
    wp_enqueue_style('quiz-display-style', plugins_url('css/quiz-style.css', __FILE__));
    wp_enqueue_script('mathjs', 'https://math.booktoan.com/math.js', array(), null, true);
    wp_enqueue_script('quiz-display-script', plugins_url('js/quiz-script.js', __FILE__), array('jquery', 'mathjs'), '1.7', true);

    $settings = get_option('quiz_display_settings');
    wp_localize_script('quiz-display-script', 'quizDisplaySettings', $settings);
    wp_localize_script('quiz-display-script', 'quizData', array(
        'postId' => get_the_ID(),
        'ajaxurl' => admin_url('admin-ajax.php')
    ));
}

add_action('wp_enqueue_scripts', 'quiz_display_enqueue_scripts');

// Hàm cho phép các thẻ HTML cần thiết
function quiz_display_allowed_html() {
    return array(
        'img' => array('src' => true, 'alt' => true, 'title' => true),
        'a' => array('href' => true, 'title' => true),
        'br' => array(),
        'strong' => array(),
        'em' => array(),
        'span' => array('class' => true, 'style' => true)
    );
}

// Làm đẹp biểu thức trong PHP
function process_variables_php($text, &$variables) {
    if (!is_string($text)) return $text;
    $pattern = '/(.*?)(<[^>]+>|$)/s';
    $output = '';
    
    $dependencies = [];
    preg_match_all('/\!([a-zA-Z0-9]+)(?:≠|!=)([a-zA-Z0-9,]+)\!/', $text, $depMatches, PREG_SET_ORDER);
    foreach ($depMatches as $match) {
        $varName = $match[1];
        $otherVars = explode(',', $match[2]);
        $dependencies[$varName] = $otherVars;
    }
    
    preg_match_all($pattern, $text, $matches, PREG_SET_ORDER);
    foreach ($matches as $match) {
        $text_part = $match[1];
        $html_part = $match[2];
        
        if (!empty($text_part)) {
            $text_part = preg_replace_callback(
                '/\!([a-zA-Z0-9]+)\(([^)]+)\)\!/',
                function($matches) use (&$variables, $dependencies) {
                    $varName = $matches[1];
                    if (!array_key_exists($varName, $variables)) {
                        $options = array_map('trim', explode(',', $matches[2]));
                        if (isset($dependencies[$varName])) {
                            $forbiddenValues = [];
                            foreach ($dependencies[$varName] as $depVar) {
                                if (isset($variables[$depVar])) {
                                    $forbiddenValues[] = $variables[$depVar];
                                }
                            }
                            $allowedOptions = array_diff($options, $forbiddenValues);
                            if (!empty($allowedOptions)) {
                                $options = array_values($allowedOptions);
                            }
                        }
                        $variables[$varName] = $options[array_rand($options)];
                    }
                    return $variables[$varName];
                },
                $text_part
            );
            
            $text_part = preg_replace('/\!([a-zA-Z0-9]+)(?:≠|!=)([a-zA-Z0-9,]+)\!/', '', $text_part);
            
            $text_part = preg_replace_callback(
                '/\!([a-zA-Z0-9]+)(?:#([a-zA-Z0-9]+))?(?::(-?\d+):(-?\d+))?\!/',
                function($matches) use (&$variables, $dependencies) {
                    $varName = $matches[1];
                    $notEqualToVar = isset($matches[2]) ? $matches[2] : null;
                    $min = isset($matches[3]) ? (int)$matches[3] : -10;
                    $max = isset($matches[4]) ? (int)$matches[4] : 10;
                    
                    if (!array_key_exists($varName, $variables)) {
                        $forbiddenValues = [];
                        if (isset($dependencies[$varName])) {
                            foreach ($dependencies[$varName] as $depVar) {
                                if (isset($variables[$depVar])) {
                                    $forbiddenValues[] = $variables[$depVar];
                                }
                            }
                        }
                       // Thêm giá trị của biến khác hoặc giá trị 0 tường minh vào danh sách cấm
                        if ($notEqualToVar !== null) { // Kiểm tra xem phần # có tồn tại không
                            if (array_key_exists($notEqualToVar, $variables)) { // Nếu $notEqualToVar là tên của một biến đã tồn tại
                                $forbiddenValues[] = $variables[$notEqualToVar];
                            } elseif ($notEqualToVar === '0') { // Nếu $notEqualToVar là chuỗi '0' (từ cú pháp #0)
                                $forbiddenValues[] = 0; // Thêm số 0 vào danh sách cấm
                            }
						}
                        $maxAttempts = 100;
                        $attempts = 0;
                        do {
                            $value = rand($min, $max);
                            $attempts++;
                            $validValue = !in_array($value, $forbiddenValues);
                            if ($attempts > $maxAttempts) {
                                if ($notEqualToVar && isset($variables[$notEqualToVar])) {
                                    $validValue = ($value !== $variables[$notEqualToVar]);
                                } else {
                                    $validValue = true;
                                }
                            }
                        } while (!$validValue);
                        $variables[$varName] = $value;
                    }
                    return $variables[$varName];
                },
                $text_part
            );
            
            if (substr($text_part, 0, 1) === '+') {
                $text_part = substr($text_part, 1);
            }
            
            $text_part = preg_replace_callback(
                '/([+-]?)(\d*\.?\d+)([x](?:\^?\d*)?(?:_[0-9]+)?)?/',
                function ($matches) {
                    $sign = $matches[1] ?: '';
                    $originalNumber = $matches[2];
                    $coefficient = (float)$originalNumber;
                    $xPart = $matches[3] ?? '';
                    if ($sign === '+' && $coefficient == 0 && empty($xPart)) {
                        return '';
                    }
                    if ($coefficient == 0 && !empty($xPart)) {
                        return '';
                    }
                    if ($coefficient < 0) {
                        $sign = ($sign == '+') ? '-' : '+';
                        $coefficient = abs($coefficient);
                        $originalNumber = abs((float)$originalNumber);
                    }
                    if ($xPart) {
                        if ($coefficient == 1) {
                            return $sign . $xPart;
                        } else {
                            return $sign . $originalNumber . $xPart;
                        }
                    } else {
                        return $sign . $originalNumber;
                    }
                },
                $text_part
            );
            
            $text_part = str_replace('+-', '-', $text_part);
            
            if ($text_part == "=0") {
                $text_part = "0=0";
            } elseif (empty($text_part)) {
                $text_part = "0";
            }
        }
        $output .= $text_part . $html_part;
    }
    return $output;
}

// Shortcode cho bộ câu hỏi
function quiz_set_shortcode($atts, $content = null) {
    $atts = shortcode_atts(array(
        'type' => 'practice',
        'time' => 5,
        'single_choice_points' => 0.25,
        'true_false_points' => 0.25,
        'short_answer_points' => 0.5,
    ), $atts);

    $quiz_id = 'quiz_set_' . uniqid();
    $variables = array();
    $content = do_shortcode(shortcode_unautop($content));

    $quiz_class = ($atts['type'] === 'exam') ? 'quiz-set-exam' : 'quiz-set-practice';
    $post_title = get_the_title(get_the_ID());

    // Kiểm tra type="exam"
    if ($atts['type'] === 'exam') {
        if (!is_user_logged_in()) {
            $login_url = wp_login_url(get_permalink());
            $register_url = wp_registration_url();
            return '<div style="border: 2px solid red; padding: 15px; background-color: #ffe6e6;">
                        <p><strong>Bạn cần đăng nhập để làm bài thi này.</strong></p>
                        <p><a href="' . esc_url($login_url) . '">Đăng nhập</a> | <a href="' . esc_url($register_url) . '">Đăng ký</a></p>
                    </div>';
        } else {
            $current_user = wp_get_current_user();
            $student_name = $current_user->display_name;

            $output = '<div class="quiz-set ' . $quiz_class . '" id="' . $quiz_id . '" 
                        data-type="' . esc_attr($atts['type']) . '" 
                        data-time="' . intval($atts['time']) . '" 
                        data-post-title="' . esc_attr($post_title) . '"
                        data-single-choice-points="' . floatval($atts['single_choice_points']) . '"
                        data-true-false-points="' . floatval($atts['true_false_points']) . '"
                        data-short-answer-points="' . floatval($atts['short_answer_points']) . '"
                        data-auto-start="true">';

            $output .= '<div class="quiz-header">
                            <div class="quiz-student-info">
                                <p>Họ và tên: ' . esc_html($student_name) . '</p>
                            </div>
                            <div class="quiz-timer" style="display:none;">Thời gian còn lại: <span id="timer_' . $quiz_id . '"></span></div>
                        </div>';
            $output .= '<div class="quiz-questions">' . $content . '</div>';
        }
    } else {
        // Xử lý type="practice"
        $output = '<div class="quiz-set ' . $quiz_class . '" id="' . $quiz_id . '" 
                    data-type="' . esc_attr($atts['type']) . '" 
                    data-time="' . intval($atts['time']) . '" 
                    data-post-title="' . esc_attr($post_title) . '"
                    data-single-choice-points="' . floatval($atts['single_choice_points']) . '"
                    data-true-false-points="' . floatval($atts['true_false_points']) . '"
                    data-short-answer-points="' . floatval($atts['short_answer_points']) . '">';
        
        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            $student_name = $current_user->display_name;
            $output .= '<div class="quiz-header">
                            <div class="quiz-student-info">
                                <p>Họ và tên: ' . esc_html($student_name) . '</p>
                            </div>
                            <div class="quiz-timer" style="display:none;">Thời gian: <span id="timer_' . $quiz_id . '"></span></div>
                        </div>';
        } else {
            $output .= '<div class="quiz-header">
                            <div class="quiz-student-info">
                                <label for="student_name_' . $quiz_id . '">Họ và tên (không bắt buộc):</label>
                                <input type="text" name="student_name" id="student_name_' . $quiz_id . '" class="student-name-input">
                            </div>
                            <div class="quiz-timer" style="display:none;">Thời gian: <span id="timer_' . $quiz_id . '"></span></div>
                        </div>';
        }
        $output .= '<div class="quiz-questions">' . $content . '</div>';
    }

    $output .= '<div class="quiz-score" style="display:none;">
                    <h3>Kết quả</h3>
                    <p class="quiz-result-title"></p>
                    <p>Điểm nhóm trắc nghiệm đơn chọn: <span class="score-part-1">0</span></p>
                    <p>Điểm nhóm đúng/sai: <span class="score-part-2">0</span></p>
                    <p>Điểm nhóm trả lời ngắn: <span class="score-part-3">0</span></p>
                    <p><strong><span style="color: red;">Tổng điểm bài thi:</span> <span class="total-score" style="color: red;">0</span></strong></p>
                    <p class="quiz-result-message"></p>
                </div>
                <button class="submit-quiz" style="display:inline-block;">Nộp bài</button>
                <button class="retry-quiz" style="display:none;">Làm lại</button>
            </div>';

    return $output;
}
add_shortcode('quiz_set', 'quiz_set_shortcode');


// Shortcode cho nhóm câu hỏi
function quiz_group_shortcode($atts, $content = null) {
    $atts = shortcode_atts(array(
        'title' => 'Nhóm câu hỏi',
        'single_choice_tron' => 'n,n',
        'true_false_tron' => 'n,n',
        'short_answer_tron' => 'n',
        'single_choice_socau' => 0,
        'true_false_socau' => 0,
        'short_answer_socau' => 0
    ), $atts);

    $group_id = 'quiz_group_' . uniqid();
    $content = do_shortcode(shortcode_unautop($content));

    $output = '<div class="quiz-group" id="' . $group_id . '"
                data-single-choice-tron="' . esc_attr($atts['single_choice_tron']) . '"
                data-true-false-tron="' . esc_attr($atts['true_false_tron']) . '"
                data-short-answer-tron="' . esc_attr($atts['short_answer_tron']) . '"
                data-single-choice-socau="' . intval($atts['single_choice_socau']) . '"
                data-true-false-socau="' . intval($atts['true_false_socau']) . '"
                data-short-answer-socau="' . intval($atts['short_answer_socau']) . '">
                <h4 class="quiz-group-title">' . wp_kses($atts['title'], quiz_display_allowed_html()) . '</h4>
                <div class="group-questions">' . $content . '</div>
               </div>';

    return $output;
}
add_shortcode('q_group', 'quiz_group_shortcode');

// Shortcode cho câu hỏi trắc nghiệm một đáp án
function quiz_question_shortcode($atts, $content = null, $tag = '') {
    $atts = shortcode_atts(array(
        'question' => '',
        'option_a' => '',
        'option_b' => '',
        'option_c' => '',
        'option_d' => '',
        'correct' => 'A',
        'explanation' => ''
    ), $atts, $tag);

    $variables = array();
    foreach ($atts as $key => &$value) {
        $value = process_variables_php($value, $variables);
    }

    $options = array('A' => $atts['option_a'], 'B' => $atts['option_b'], 'C' => $atts['option_c'], 'D' => $atts['option_d']);
    $quiz_id = uniqid();
    $encoded_correct = 'ENC:' . base64_encode($atts['correct']);
    // Lưu nội dung câu hỏi gốc
    $question_content = $atts['question']; // Giữ nguyên LaTeX và [image: url]
    return '<div class="quiz-box" id="quiz-box-' . $quiz_id . '" data-correct="' . esc_attr($encoded_correct) . '" data-options="' . esc_attr(json_encode($options)) . '" data-type="single-choice" data-question-content="' . esc_attr($question_content) . '">
            <div class="question-section"><h5>' . wp_kses($atts['question'], quiz_display_allowed_html()) . '</h5></div>
            <div class="options-section">' . generate_options_html($options, $quiz_id) . '</div>
            <div class="explanation" style="display:none;"><div class="explanation-content">' . wp_kses($atts['explanation'], quiz_display_allowed_html()) . '</div>
            </div>
        </div>';
}
add_shortcode('quiz_question', 'quiz_question_shortcode');

// Shortcode cho câu hỏi trắc nghiệm đúng/sai
function quiz_question_T_F_shortcode($atts, $content = null, $tag = '') {
    $atts = shortcode_atts(array(
        'question' => '',
        'option_a' => '',
        'option_b' => '',
        'option_c' => '',
        'option_d' => '',
        'correct' => '',
        'explanation' => ''
    ), $atts, $tag);

    $variables = array();
    foreach ($atts as $key => &$value) {
        $value = process_variables_php($value, $variables);
    }

    $options = array('A' => $atts['option_a'], 'B' => $atts['option_b'], 'C' => $atts['option_c'], 'D' => $atts['option_d']);
    $quiz_id = uniqid();
    $encoded_correct = 'ENC:' . base64_encode($atts['correct']);
    // Lưu nội dung câu hỏi gốc
    $question_content = $atts['question'];
    return '<div class="quiz-box quiz-box-tf" id="quiz-box-tf-' . $quiz_id . '" data-correct="' . esc_attr($encoded_correct) . '" data-options="' . esc_attr(json_encode($options)) . '" data-type="true-false" data-question-content="' . esc_attr($question_content) . '">
                <div class="question-section"><h5>' . wp_kses($atts['question'], quiz_display_allowed_html()) . '</h5></div>
                <div class="options-section">' . generate_true_false_options_html($options, $quiz_id) . '</div>
                <div class="explanation" style="display:none;"><div class="explanation-content">' . wp_kses($atts['explanation'], quiz_display_allowed_html()) . '</div></div>
            </div>';
}
add_shortcode('quiz_question_T_F', 'quiz_question_T_F_shortcode');

// Shortcode cho câu hỏi trả lời ngắn
function quiz_question_short_answer_shortcode($atts, $content = null, $tag = '') {
    $atts = shortcode_atts(array(
        'question' => '',
        'correct' => '',
        'explanation' => ''
    ), $atts, $tag);

    $variables = array();
    foreach ($atts as $key => &$value) {
        $value = process_variables_php($value, $variables);
    }

    $quiz_id = uniqid();
    $encoded_correct = 'ENC:' . base64_encode($atts['correct']);
    // Lưu nội dung câu hỏi gốc
    $question_content = $atts['question'];
    return '<div class="quiz-box quiz-box-sa" id="quiz-box-sa-' . $quiz_id . '" data-correct="' . esc_attr($encoded_correct) . '" data-type="short-answer" data-question-content="' . esc_attr($question_content) . '">
                <div class="question-section"><h5>' . wp_kses($atts['question'], quiz_display_allowed_html()) . '</h5></div>
                <div class="answer-section"><input type="text" name="short_answer_' . $quiz_id . '" id="short_answer_' . $quiz_id . '" class="short-answer-input" maxlength="4"></div>
                <div class="explanation" style="display:none;"><div class="explanation-content">' . wp_kses($atts['explanation'], quiz_display_allowed_html()) . '</div></div>
            </div>';
}
add_shortcode('quiz_question_TLN', 'quiz_question_short_answer_shortcode');

// Thêm menu quản trị
function quiz_display_admin_menu() {
    add_menu_page('Quiz Display Settings', 'Quiz Display', 'manage_options', 'quiz-display-settings', 'quiz_display_settings_page', 'dashicons-welcome-learn-more');
    add_submenu_page('quiz-display-settings', 'Xem Điểm', 'Xem Điểm', 'manage_options', 'quiz-results', 'quiz_display_results_page');
    add_submenu_page('quiz-display-settings', 'Thống Kê Bài Thi', 'Thống Kê Bài Thi', 'manage_options', 'quiz-stats', 'quiz_display_stats_page');
}
add_action('admin_menu', 'quiz_display_admin_menu');

// Trang cài đặt plugin
function quiz_display_settings_page() {
    ?>
    <div class="wrap">
        <h2><?php echo esc_html(get_admin_page_title()); ?></h2>
        <p><strong>Lưu ý:</strong> Để xáo trộn câu hỏi và đáp án, sử dụng các thuộc tính trong shortcode <code>[quiz_set]</code> và <code>[q_group]</code>.</p>
        <p>Ví dụ:</p>
        <pre><code>[quiz_set type="exam" time="15"]
[q_group title="Đọc đoạn văn và trả lời:" single_choice_tron="y,y" single_choice_socau="2"]
    [quiz_question question="Câu hỏi 1?" option_a="A1" option_b="B1" option_c="C1" option_d="D1" correct="A" explanation="lời giải "]
    [quiz_question question="Câu hỏi 2?" option_a="A2" option_b="B2" option_c="C2" option_d="D2" correct="B" explanation="lời giải "]
[/q_group]
[q_group title="Câu hỏi Đúng/Sai" true_false_tron="y,n" true_false_socau="1"]
    [quiz_question_T_F question="Mệnh đề nào đúng?" option_a="Mệnh đề A" option_b="Mệnh đề B" correct="A" explanation="lời giải "]
[/q_group]
[q_group title="Phần III: Trả lời ngắn" short_answer_tron="y" short_answer_socau="1"]
    [quiz_question_TLN question="Bài toán có đáp số là" correct="1234" explanation="lời giải "]
[/q_group]
[/quiz_set]</code></pre>
        <ul>
            <li><code>type="practice|exam"</code>: Loại bài quiz (luyện tập hoặc kiểm tra).</li>
            <li><code>time="15"</code>: Thời gian làm bài (phút), chỉ áp dụng cho <code>type="exam"</code>.</li>
            <li><code>q_group</code>: Nhóm câu hỏi với các thuộc tính:</li>
            <ul>
                <li><code>title="Tiêu đề nhóm"</code>: Tiêu đề của nhóm câu hỏi.</li>
                <li><code>single_choice_socau="2"</code>: Số câu trắc nghiệm 1 đáp án sẽ được chọn ngẫu nhiên (0 là lấy hết).</li>
                <li><code>true_false_socau="2"</code>: Số câu Đúng/Sai sẽ được chọn ngẫu nhiên (0 là lấy hết).</li>
                <li><code>short_answer_socau="3"</code>: Số câu trả lời ngắn sẽ được chọn ngẫu nhiên (0 là lấy hết).</li>
                <li><code>single_choice_tron="y,y"</code>: Xáo trộn câu hỏi (y/n), xáo trộn đáp án (y/n) cho trắc nghiệm 1 đáp án.</li>
                <li><code>true_false_tron="y,n"</code>: Xáo trộn câu hỏi (y/n), xáo trộn thứ tự mệnh đề (y/n) cho Đúng/Sai.</li>
                <li><code>short_answer_tron="y"</code>: Xáo trộn câu hỏi (y/n) cho trả lời ngắn.</li>
            </ul>
        </ul>
        <p><em>(Hiện tại trang này chỉ có chức năng hiển thị hướng dẫn)</em></p>
    </div>
    <?php
}

// Hàm lưu điểm và đáp án vào CSDL
add_action('wp_ajax_save_quiz_results', 'save_quiz_results');
add_action('wp_ajax_nopriv_save_quiz_results', 'save_quiz_results');
function save_quiz_results() {
    global $wpdb;

    // Thiết lập múi giờ Việt Nam
    date_default_timezone_set('Asia/Ho_Chi_Minh');

    $quiz_id = sanitize_text_field($_POST['quiz_id'] ?? '');
    $score_part_1 = floatval($_POST['score_part_1'] ?? 0);
    $score_part_2 = floatval($_POST['score_part_2'] ?? 0);
    $score_part_3 = floatval($_POST['score_part_3'] ?? 0);
    $total_score = floatval($_POST['total_score'] ?? 0);
    $quiz_type = sanitize_text_field($_POST['type'] ?? 'practice');
    $start_time = sanitize_text_field($_POST['start_time'] ?? date('Y-m-d H:i:s'));
    $end_time = sanitize_text_field($_POST['end_time'] ?? date('Y-m-d H:i:s'));
    $student_name = sanitize_text_field($_POST['student_name'] ?? 'Học sinh khách');
    $post_id = intval($_POST['post_id'] ?? 0);
    $answers = json_decode(stripslashes($_POST['answers'] ?? '[]'), true);

    if (empty($quiz_id)) {
        wp_send_json_error('Thiếu ID bài kiểm tra.');
        return;
    }

    $user_id = get_current_user_id();

    // Xử lý tên học sinh
    if ($quiz_type === 'exam') {
        if (!is_user_logged_in()) {
            wp_send_json_error('Bạn cần đăng nhập để làm bài thi.');
            return;
        }
        $current_user = wp_get_current_user();
        $student_name = $current_user->display_name;
    } elseif ($quiz_type === 'practice') {
        // Không lưu kết quả cho practice
        $response_data = array(
            'student_name' => $student_name,
            'start_time' => $start_time,
            'end_time' => $end_time
        );
        wp_send_json_success($response_data);
        return;
    }

    if (empty($post_id)) {
        wp_send_json_error('Không tìm thấy ID bài viết.');
        return;
    }

    $table_name = $wpdb->prefix . 'quiz_results';
    $data = array(
        'user_id' => $user_id,
        'quiz_id' => $quiz_id,
        'score_part_1' => $score_part_1,
        'score_part_2' => $score_part_2,
        'score_part_3' => $score_part_3,
        'total_score' => $total_score,
        'start_time' => $start_time,
        'end_time' => $end_time,
        'student_name' => $student_name,
        'post_id' => $post_id,
    );

    $result = $wpdb->insert($table_name, $data);
    if ($result === false) {
        wp_send_json_error('Lỗi khi lưu điểm: ' . $wpdb->last_error);
        return;
    }

    $result_id = $wpdb->insert_id;
    $answers_table = $wpdb->prefix . 'quiz_answers';

    foreach ($answers as $answer) {
        $question_content = isset($answer['question_content']) ? $answer['question_content'] : '';
        error_log('Saving question_content: ' . $question_content);
        $question_content = sanitize_text_field($question_content);
        $wpdb->insert($answers_table, array(
            'result_id' => $result_id,
            'question_id' => sanitize_text_field($answer['question_id']),
            'question_type' => sanitize_text_field($answer['type']),
            'question_content' => $question_content,
            'student_answer' => sanitize_text_field($answer['answer']),
            'is_correct' => intval($answer['is_correct'])
        ));
    }

    $response_data = array(
        'student_name' => $student_name,
        'start_time' => $start_time,
        'end_time' => $end_time
    );

    wp_send_json_success($response_data);
}

// Xử lý xóa kết quả
add_action('admin_post_delete_quiz_results', 'delete_quiz_results');
function delete_quiz_results() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'quiz_results';
    $answers_table = $wpdb->prefix . 'quiz_answers';

    if (!current_user_can('manage_options')) {
        wp_die('Bạn không có quyền thực hiện hành động này.');
    }

    $result_ids = isset($_POST['result_ids']) ? array_map('intval', (array)$_POST['result_ids']) : array();
    if (!empty($result_ids)) {
        $ids_placeholder = implode(',', array_fill(0, count($result_ids), '%d'));
        $wpdb->query($wpdb->prepare("DELETE FROM $table_name WHERE id IN ($ids_placeholder)", $result_ids));
        $wpdb->query($wpdb->prepare("DELETE FROM $answers_table WHERE result_id IN ($ids_placeholder)", $result_ids));
    }

    wp_redirect(admin_url('admin.php?page=quiz-results'));
    exit;
}

// Trang hiển thị kết quả trong admin
function quiz_display_results_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'quiz_results';
    $answers_table = $wpdb->prefix . 'quiz_answers';

 
    // Xử lý lọc theo post_id
    $post_id_filter = isset($_GET['post_id']) ? intval($_GET['post_id']) : 0;
    $where_clause = $post_id_filter ? $wpdb->prepare('WHERE post_id = %d', $post_id_filter) : '';

    if (!isset($_GET['result_id'])) {
        // Lấy danh sách bài viết có quiz
        $posts = get_posts(array(
            'post_type' => 'post',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => '_has_quiz',
                    'value' => '1',
                    'compare' => '='
                )
            )
        ));

        // Hiển thị danh sách kết quả
        $results = $wpdb->get_results("SELECT * FROM $table_name $where_clause ORDER BY end_time DESC");
        ?>
        <div class="wrap">
            <h1>Kết quả bài kiểm tra</h1>
            <!-- Bộ lọc theo post_id -->
      
            <!-- Form xóa kết quả -->
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                <input type="hidden" name="action" value="delete_quiz_results">
                <?php wp_nonce_field('delete_quiz_results_nonce'); ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="select-all"></th>
                            <th>ID</th>
							<th>Post ID</th>
                            <th>Học sinh</th>
                            <th>Bài kiểm tra</th>
                            <th>Điểm</th>
							<th>Thời gian bắt đầu</th>
                            <th>Thời gian nộp</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results as $result): ?>
                            <tr>
                                <td><input type="checkbox" name="result_ids[]" value="<?php echo esc_attr($result->id); ?>"></td>
                                <td><?php echo esc_html($result->id); ?></td>
								<td><?php echo esc_html($result->post_id ?: 'N/A'); ?></td>
                                <td><?php echo esc_html($result->student_name); ?></td>
                                <td><?php echo esc_html(get_the_title($result->post_id)); ?></td>
                                <td><?php echo esc_html($result->total_score); ?></td>
                                <td><?php echo esc_html(date('d/m/Y H:i:s', strtotime($result->start_time . ' UTC') + 7 * 3600)); ?></td>
                                <td><?php echo esc_html(date('d/m/Y H:i:s', strtotime($result->end_time . ' UTC') + 7 * 3600)); ?></td>
                                <td><a href="<?php echo admin_url('admin.php?page=quiz-results&result_id=' . $result->id); ?>">Xem chi tiết</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <input type="submit" value="Xóa các mục đã chọn" class="button" onclick="return confirm('Bạn có chắc chắn muốn xóa các mục đã chọn?');">
            </form>
        </div>
        <script>
            document.getElementById('select-all').addEventListener('change', function() {
                var checkboxes = document.querySelectorAll('input[name="result_ids[]"]');
                checkboxes.forEach(function(checkbox) {
                    checkbox.checked = this.checked;
                }, this);
            });
        </script>
        <?php
    } else {
        // Hiển thị chi tiết kết quả
        $result_id = intval($_GET['result_id']);
        $result = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $result_id));
        if ($result) {
            $answers = $wpdb->get_results($wpdb->prepare("SELECT * FROM $answers_table WHERE result_id = %d", $result_id));
            ?>
            <div class="wrap">
                <h1>Chi tiết bài thi của học sinh: <?php echo esc_html($result->student_name); ?></h1>
                <p><strong>Bài kiểm tra:</strong> <?php echo esc_html(get_the_title($result->post_id)); ?></p>
                <p><strong>Điểm:</strong> <?php echo esc_html($result->total_score); ?></p>
                <p><strong>Thời gian bắt đầu:</strong> <?php echo esc_html(date('d/m/Y H:i:s', strtotime($result->start_time . ' UTC') + 7 * 3600)); ?></p>
                <p><strong>Thời gian nộp:</strong> <?php echo esc_html(date('d/m/Y H:i:s', strtotime($result->end_time . ' UTC') + 7 * 3600)); ?></p>
                <h2>Đáp án</h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Câu hỏi</th>
                            <th>Loại</th>
                            <th>Đáp án của học sinh</th>
                            <th>Đúng/Sai</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($answers as $answer): ?>
                            <tr>
                                <td>
                                    <?php
                                    if ($answer->question_content) {
                                        $content = $answer->question_content;
                                        $content = preg_replace('/\[image:([^\]]+)\]/', '<img src="$1" style="max-width: 200px;" />', $content);
                                        echo wp_kses($content, quiz_display_allowed_html());
                                    } else {
                                        echo 'Không có nội dung câu hỏi';
                                    }
                                    ?>
                                </td>
                                <td><?php echo esc_html($answer->question_type); ?></td>
                                <td><?php echo esc_html($answer->student_answer) ?: 'Không trả lời'; ?></td>
                                <td><?php echo $answer->is_correct ? 'Đúng' : 'Sai'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <p><a href="<?php echo admin_url('admin.php?page=quiz-results'); ?>">Quay lại</a></p>
            </div>
            <?php
        } else {
            echo '<div class="wrap"><p>Kết quả không tồn tại.</p></div>';
        }
    }
}
// Thêm liên kết đến trang kết quả bài thi trong menu tài khoản
add_filter('wp_nav_menu_items', 'add_quiz_results_menu_item', 10, 2);
function add_quiz_results_menu_item($items, $args) {
    if (is_user_logged_in() && $args->theme_location == 'primary') { // Thay 'primary' bằng theme location của menu tài khoản
        $results_page = get_page_by_path('ket-qua-bai-thi'); // Giả sử trang có slug 'ket-qua-bai-thi'
        if ($results_page) {
            $items .= '<li><a href="' . esc_url(get_permalink($results_page)) . '">Kết quả bài thi</a></li>';
        }
    }
    return $items;
}

// Shortcode hiển thị kết quả bài thi cho học sinh
function quiz_user_results_shortcode() {
    if (!is_user_logged_in()) {
        return '<p>Bạn cần đăng nhập để xem kết quả bài thi.</p>';
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'quiz_results';
    $user_id = get_current_user_id();

    $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d ORDER BY end_time DESC", $user_id));

    ob_start();
    ?>
    <div class="quiz-user-results">
        <h2>Kết quả bài thi của bạn</h2>
        <?php if (empty($results)): ?>
            <p>Bạn chưa làm bài thi nào.</p>
        <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Bài kiểm tra</th>
                        <th>Điểm</th>
                        <th>Thời gian nộp</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $result): ?>
                        <tr>
                            <td><?php echo esc_html(get_the_title($result->post_id)); ?></td>
                            <td><?php echo esc_html($result->total_score); ?></td>
                            <td><?php echo esc_html(date('d/m/Y H:i:s', strtotime($result->end_time . ' UTC') + 7 * 3600)); ?></td>
                            <td><a href="<?php echo admin_url('admin.php?page=quiz-results&result_id=' . $result->id); ?>">Xem chi tiết</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('quiz_user_results', 'quiz_user_results_shortcode');
// Trang thống kê bài thi
function quiz_display_stats_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'quiz_results';
    $answers_table = $wpdb->prefix . 'quiz_answers';

    $view_details = isset($_GET['view_details']) ? intval($_GET['view_details']) : 0;
    if ($view_details) {
        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT r.*, p.post_title 
             FROM $table_name r 
             JOIN {$wpdb->posts} p ON r.post_id = p.ID 
             WHERE r.id = %d",
            $view_details
        ));

        if ($result) {
            $answers = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $answers_table WHERE result_id = %d ORDER BY id",
                $view_details
            ));

            ?>
            <div class="wrap">
                <h2>Chi tiết bài thi của <?php echo esc_html($result->student_name); ?></h2>
                <p><strong>Tên bài thi:</strong> <?php echo esc_html($result->post_title); ?> (Post ID: <?php echo $result->post_id; ?>)</p>
                <p><strong>Điểm:</strong> Nhóm trắc nghiệm: <?php echo $result->score_part_1; ?>, Nhóm đúng/sai: <?php echo $result->score_part_2; ?>, Nhóm trả lời ngắn: <?php echo $result->score_part_3; ?>, Tổng: <?php echo $result->total_score; ?></p>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Câu hỏi ID</th>
                            <th>Loại câu hỏi</th>
                            <th>Đáp án học sinh</th>
                            <th>Kết quả</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($answers as $answer) : ?>
                            <tr>
                                <td><?php echo esc_html($answer->question_id); ?></td>
                                <td><?php echo esc_html($answer->question_type); ?></td>
                                <td><?php echo esc_html($answer->student_answer); ?></td>
                                <td><?php echo $answer->is_correct ? 'Đúng' : 'Sai'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <p><a href="?page=quiz-stats&post_id=<?php echo $result->post_id; ?>" class="button">Quay lại</a></p>
            </div>
            <?php
            return;
        }
    }

    $post_id_filter = isset($_GET['post_id']) ? intval($_GET['post_id']) : '';
    if ($post_id_filter) {
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT r.*, p.post_title 
             FROM $table_name r 
             JOIN {$wpdb->posts} p ON r.post_id = p.ID 
             WHERE r.post_id = %d 
             ORDER BY r.student_name",
            $post_id_filter
        ));

        $export_url = admin_url('admin-ajax.php?action=export_quiz_csv&post_id=' . $post_id_filter);
        $post = get_post($post_id_filter);
        ?>
        <div class="wrap">
            <h2>Kết quả bài thi: <?php echo esc_html($post->post_title); ?> (Post ID: <?php echo $post_id_filter; ?>)</h2>
            <p><a href="?page=quiz-stats" class="button">Quay lại danh sách bài thi</a> 
                <a href="<?php echo esc_url($export_url); ?>" class="button">Xuất CSV</a>
            </p>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Tên học sinh</th>
                        <th>Điểm nhóm trắc nghiệm</th>
                        <th>Điểm nhóm đúng/sai</th>
                        <th>Điểm nhóm trả lời ngắn</th>
                        <th>Tổng điểm</th>
                        <th>Thời gian nộp bài</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($results)) : ?>
                        <tr><td colspan="7">Không có kết quả nào.</td></tr>
                    <?php else : ?>
                        <?php foreach ($results as $result) : ?>
                            <tr>
                                <td><?php echo esc_html($result->student_name); ?></td>
                                <td><?php echo esc_html($result->score_part_1); ?></td>
                                <td><?php echo esc_html($result->score_part_2); ?></td>
                                <td><?php echo esc_html($result->score_part_3); ?></td>
                                <td><?php echo esc_html($result->total_score); ?></td>
                                <td><?php echo esc_html(date('d/m/Y H:i:s', strtotime($result->end_time . ' UTC') + 7 * 3600)); ?></td>
                                <td><a href="<?php echo admin_url('admin.php?page=quiz-results&result_id=' . $result->id); ?>">Xem chi tiết</a></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    } else {
        $posts = $wpdb->get_results(
            "SELECT DISTINCT p.ID, p.post_title 
             FROM {$wpdb->posts} p 
             JOIN $table_name r ON p.ID = r.post_id 
             WHERE p.post_content LIKE '%[quiz_set type=\"exam\"%'"
        );

        ?>
        <div class="wrap">
            <h2>Thống kê bài thi</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Post ID</th>
                        <th>Tên bài thi</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($posts)) : ?>
                        <tr><td colspan="3">Không có bài thi nào.</td></tr>
                    <?php else : ?>
                        <?php foreach ($posts as $post) : ?>
                            <tr>
                                <td><?php echo esc_html($post->ID); ?></td>
                                <td><?php echo esc_html($post->post_title); ?></td>
                                <td><a href="?page=quiz-stats&post_id=<?php echo $post->ID; ?>">Xem thống kê</a></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
}

// Hàm tạo HTML cho các options
function generate_options_html($options, $quiz_id) {
    $output = '';
    foreach ($options as $key => $value) {
        $output .= '<div class="option" style="display: flex; align-items: center;">
                        <input type="radio" name="question_' . $quiz_id . '" id="question_' . $quiz_id . '_option_' . $key . '" value="' . $key . '" style="margin-right: 5px;">
                        <label for="question_' . $quiz_id . '_option_' . $key . '" style="margin: 0;"><strong>' . $key . '.</strong> ' . $value . '</label>
                    </div>';
    }
    return $output;
}

// Hàm tạo HTML cho các lựa chọn đúng/sai
function generate_true_false_options_html($options, $quiz_id) {
    $output = '';
    $option_letters = array('a', 'b', 'c', 'd');
    $i = 0;
    foreach ($options as $key => $value) {
        $output .= '<div class="option-tf">
                <label class="option-tf-label" for="question_tf_' . $quiz_id . '_option_' . $key . '"><strong>' . $option_letters[$i] . ')</strong> ' . $value . '</label>
                <div class="tf-buttons">
                    <input type="radio" name="question_tf_' . $quiz_id . '_option_' . $key . '" id="question_tf_' . $quiz_id . '_option_' . $key . '_true" value="true">
                    <label class="true-label" for="question_tf_' . $quiz_id . '_option_' . $key . '_true">Đ</label>
                    <input type="radio" name="question_tf_' . $quiz_id . '_option_' . $key . '" id="question_tf_' . $quiz_id . '_option_' . $key . '_false" value="false">
                    <label class="false-label" for="question_tf_' . $quiz_id . '_option_' . $key . '_false">S</label>
                </div>
            </div>';
        $i++;
    }
    return $output;
}// Xuất CSV
add_action('wp_ajax_export_quiz_csv', 'quiz_export_csv');
function quiz_export_csv() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'quiz_results';
    
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized access');
    }
    
    $post_id = isset($_GET['post_id']) ? intval($_GET['post_id']) : 0;
    if (empty($post_id)) {
        wp_die('Missing Post ID');
    }
    
    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT r.*, p.post_title 
         FROM $table_name r 
         LEFT JOIN {$wpdb->posts} p ON r.post_id = p.ID 
         WHERE r.post_id = %d 
         ORDER BY r.student_name",
        $post_id
    ));
    
    if (empty($results)) {
        wp_die('No data found');
    }
    
    if (ob_get_level()) {
        ob_end_clean();
    }
    
    $filename = 'quiz_results_post_' . $post_id . '_' . date('Ymd_His') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    
    $output = fopen('php://output', 'w');
    fputs($output, "\xEF\xBB\xBF");
    
    fputcsv($output, array(
        'ID', 'Tên học sinh', 'Quiz ID', 'Post ID', 'Tên bài thi',
        'Điểm nhóm trắc nghiệm', 'Điểm nhóm đúng/sai', 'Điểm nhóm trả lời ngắn', 'Tổng điểm',
        'Thời gian bắt đầu', 'Thời gian kết thúc'
    ));
    
    foreach ($results as $result) {
        fputcsv($output, array(
            $result->id,
            $result->student_name,
            $result->quiz_id,
            $result->post_id,
            $result->post_title ?: 'N/A',
            $result->score_part_1,
            $result->score_part_2,
            $result->score_part_3,
            $result->total_score,
            date('d/m/Y H:i:s', strtotime($result->start_time . ' UTC') + 7 * 3600),
            date('d/m/Y H:i:s', strtotime($result->end_time . ' UTC') + 7 * 3600)
        ));
    }
    
    fclose($output);
    die();
}