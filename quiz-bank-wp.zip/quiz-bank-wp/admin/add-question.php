<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1><?php _e('Thêm câu hỏi mới', 'quiz-bank'); ?></h1>
    
    <?php if (isset($_GET['message']) && $_GET['message'] === 'error'): ?>
        <div class="notice notice-error is-dismissible">
            <p><?php _e('Có lỗi xảy ra. Vui lòng kiểm tra lại thông tin.', 'quiz-bank'); ?></p>
        </div>
    <?php endif; ?>
    
    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
        <input type="hidden" name="action" value="quiz_bank_save_question">
        <?php wp_nonce_field('quiz_bank_save_question'); ?>
        
        <table class="form-table">
            <tr>
                <th scope="row"><label for="lop"><?php _e('Toán', 'quiz-bank'); ?> *</label></th>
                <td>
                    <select name="lop" id="lop" required>
                        <option value=""><?php _e('Chọn lớp', 'quiz-bank'); ?></option>
                        <option value="12">Toán 12</option>
                        <option value="11">Toán 11</option>
                        <option value="10">Toán 10</option>
                    </select>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="chuong"><?php _e('Chương', 'quiz-bank'); ?> *</label></th>
                <td>
                    <select name="chuong" id="chuong" required>
                        <option value=""><?php _e('Chọn chương', 'quiz-bank'); ?></option>
                    </select>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="bai_hoc"><?php _e('Bài học', 'quiz-bank'); ?> *</label></th>
                <td>
                    <select name="bai_hoc" id="bai_hoc" required>
                        <option value=""><?php _e('Chọn bài học', 'quiz-bank'); ?></option>
                    </select>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="dang"><?php _e('Dạng', 'quiz-bank'); ?> *</label></th>
                <td>
                    <select name="dang" id="dang" required>
                        <option value=""><?php _e('Chọn dạng', 'quiz-bank'); ?></option>
                    </select>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="muc_do"><?php _e('Mức độ', 'quiz-bank'); ?> *</label></th>
                <td>
                    <select name="muc_do" id="muc_do" required>
                        <option value=""><?php _e('Chọn mức độ', 'quiz-bank'); ?></option>
                        <option value="Nhận biết">Nhận biết</option>
                        <option value="Thông hiểu">Thông hiểu</option>
                        <option value="Vận dụng">Vận dụng</option>
                        <option value="Vận dụng cao">Vận dụng cao</option>
                    </select>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="type"><?php _e('Loại câu hỏi', 'quiz-bank'); ?> *</label></th>
                <td>
                    <select name="type" id="type" required>
                        <option value="mcq">MCQ - Trắc nghiệm một lựa chọn</option>
                        <option value="msq">MSQ - Trắc nghiệm nhiều lựa chọn</option>
                        <option value="sa">SA - Câu hỏi ngắn</option>
                    </select>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="cau_hoi"><?php _e('Câu hỏi', 'quiz-bank'); ?> *</label></th>
                <td>
                    <?php wp_editor('', 'cau_hoi', array('textarea_rows' => 5, 'media_buttons' => false)); ?>
                </td>
            </tr>
            
            <tr class="option-row">
                <th scope="row"><label><?php _e('Đáp án A, B', 'quiz-bank'); ?> *</label></th>
                <td>
                    <div style="display: flex; gap: 10px; margin-bottom: 10px;">
                        <div style="flex: 1;">
                            <label for="option_a" style="font-weight: bold;"><?php _e('Đáp án A:', 'quiz-bank'); ?></label>
                            <input type="text" name="option_a" id="option_a" class="regular-text" style="width: 100%; margin-top: 5px;" required>
                        </div>
                        <div style="flex: 1;">
                            <label for="option_b" style="font-weight: bold;"><?php _e('Đáp án B:', 'quiz-bank'); ?></label>
                            <input type="text" name="option_b" id="option_b" class="regular-text" style="width: 100%; margin-top: 5px;" required>
                        </div>
                    </div>
                </td>
            </tr>
            
            <tr class="option-row">
                <th scope="row"><label><?php _e('Đáp án C, D', 'quiz-bank'); ?> *</label></th>
                <td>
                    <div style="display: flex; gap: 10px;">
                        <div style="flex: 1;">
                            <label for="option_c" style="font-weight: bold;"><?php _e('Đáp án C:', 'quiz-bank'); ?></label>
                            <input type="text" name="option_c" id="option_c" class="regular-text" style="width: 100%; margin-top: 5px;" required>
                        </div>
                        <div style="flex: 1;">
                            <label for="option_d" style="font-weight: bold;"><?php _e('Đáp án D:', 'quiz-bank'); ?></label>
                            <input type="text" name="option_d" id="option_d" class="regular-text" style="width: 100%; margin-top: 5px;" required>
                        </div>
                    </div>
                </td>
            </tr>
            
            <tr id="correct-option-row">
                <th scope="row"><label for="correct_option"><?php _e('Đáp án đúng', 'quiz-bank'); ?> *</label></th>
                <td>
                    <select name="correct_option" id="correct_option" required>
                        <option value=""><?php _e('Chọn đáp án đúng', 'quiz-bank'); ?></option>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                        <option value="D">D</option>
                    </select>
                    <p class="description" id="mcq-description"><?php _e('Chọn một đáp án đúng cho MCQ', 'quiz-bank'); ?></p>
                    <p class="description" id="msq-description" style="display: none;"><?php _e('Nhập các đáp án đúng phân cách bằng dấu phẩy (VD: A,C)', 'quiz-bank'); ?></p>
                    <input type="text" name="correct_option_text" id="correct_option_text" class="regular-text" style="display: none;" placeholder="A,C">
                    <input type="hidden" name="correct_option_msq" id="correct_option_msq">
                </td>
            </tr>
            
            <tr id="correct-answer-row" style="display: none;">
                <th scope="row"><label for="correct_answer"><?php _e('Câu trả lời đúng', 'quiz-bank'); ?> *</label></th>
                <td>
                    <input type="text" name="correct_answer" id="correct_answer" class="regular-text">
                    <p class="description"><?php _e('Nhập câu trả lời cho câu hỏi ngắn', 'quiz-bank'); ?></p>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="explanation"><?php _e('Giải thích', 'quiz-bank'); ?></label></th>
                <td>
                    <?php wp_editor('', 'explanation', array('textarea_rows' => 4, 'media_buttons' => false)); ?>
                    <p class="description"><?php _e('Tùy chọn: Giải thích chi tiết đáp án', 'quiz-bank'); ?></p>
                </td>
            </tr>
        </table>
        
        <p class="submit">
            <input type="submit" name="submit" class="button-primary" value="<?php _e('Thêm câu hỏi', 'quiz-bank'); ?>">
            <a href="<?php echo admin_url('admin.php?page=quiz-bank'); ?>" class="button"><?php _e('Hủy', 'quiz-bank'); ?></a>
        </p>
    </form>
</div>

<script type="text/javascript">
jQuery(document).ready(function($) {
    var menuStructure = {};
    
    // Load menu structure from server
    function loadMenuStructure() {
        $.post(quiz_bank_ajax.ajax_url, {
            action: 'quiz_bank_action',
            quiz_action: 'get_menu_structure',
            nonce: quiz_bank_ajax.nonce
        }, function(response) {
            if (response.success) {
                menuStructure = response.data;
            }
        });
    }
    
    // Initialize menu structure
    loadMenuStructure();
    
    // Handle grade selection
    $('#lop').on('change', function() {
        var grade = $(this).val();
        var $chuong = $('#chuong');
        var $baiHoc = $('#bai_hoc');
        
        // Clear and reset chapter and lesson dropdowns
        $chuong.html('<option value="">Chọn chương</option>');
        $baiHoc.html('<option value="">Chọn bài học</option>');
        
        if (grade && menuStructure.grades && menuStructure.grades[grade]) {
            // Populate chapters for selected grade
            var chapters = menuStructure.grades[grade].chapters;
            $.each(chapters, function(chapterId, chapterData) {
                $chuong.append('<option value="' + chapterId + '">' + chapterData.name + '</option>');
            });
        }
    });
    
    // Handle chapter selection
    $('#chuong').on('change', function() {
        var grade = $('#lop').val();
        var chapter = $(this).val();
        var $baiHoc = $('#bai_hoc');
        var $dang = $('#dang');
        
        // Clear lesson and type dropdowns
        $baiHoc.html('<option value="">Chọn bài học</option>');
        $dang.html('<option value="">Chọn dạng</option>');
        
        if (grade && chapter && menuStructure.grades && menuStructure.grades[grade] && menuStructure.grades[grade].chapters[chapter]) {
            // Populate lessons for selected chapter
            var lessons = menuStructure.grades[grade].chapters[chapter].lessons;
            $.each(lessons, function(lessonId, lessonData) {
                $baiHoc.append('<option value="' + lessonId + '">' + lessonData.name + '</option>');
            });
        }
    });
    
    // Handle lesson selection
    $('#bai_hoc').on('change', function() {
        var grade = $('#lop').val();
        var chapter = $('#chuong').val();
        var lesson = $(this).val();
        var $dang = $('#dang');
        
        // Clear type dropdown
        $dang.html('<option value="">Chọn dạng</option>');
        
        if (grade && chapter && lesson && menuStructure.grades && 
            menuStructure.grades[grade] && 
            menuStructure.grades[grade].chapters[chapter] && 
            menuStructure.grades[grade].chapters[chapter].lessons[lesson] &&
            menuStructure.grades[grade].chapters[chapter].lessons[lesson].types) {
            
            // Populate types for selected lesson
            var types = menuStructure.grades[grade].chapters[chapter].lessons[lesson].types;
            $.each(types, function(typeId, typeName) {
                $dang.append('<option value="' + typeId + '">Dạng ' + typeId + ': ' + typeName + '</option>');
            });
        }
    });
    
    // Initialize question type handling
    $('#type').on('change', function() {
        var type = $(this).val();
        if (type === 'sa') {
            // Short Answer - hide MCQ fields, show answer field
            $('.option-row').hide();
            $('#correct-option-row').hide();
            $('#correct-answer-row').show();
            $('#correct_option').prop('required', false);
            $('#correct_answer').prop('required', true);
            $('#option_a, #option_b, #option_c, #option_d').prop('required', false);
        } else if (type === 'msq') {
            // MSQ - show MCQ fields, use text input for multiple correct answers
            $('.option-row').show();
            $('#correct-option-row').show();
            $('#correct-answer-row').hide();
            $('#correct_option').hide().prop('required', false);
            $('#correct_option_text').show().prop('required', true);
            $('#correct_option_msq').prop('required', true);
            $('#mcq-description').hide();
            $('#msq-description').show();
            $('#correct_answer').prop('required', false);
            $('#option_a, #option_b, #option_c, #option_d').prop('required', true);
        } else {
            // MCQ - show MCQ fields, use select for single correct answer
            $('.option-row').show();
            $('#correct-option-row').show();
            $('#correct-answer-row').hide();
            $('#correct_option').show().prop('required', true);
            $('#correct_option_text').hide().prop('required', false);
            $('#mcq-description').show();
            $('#msq-description').hide();
            $('#correct_answer').prop('required', false);
            $('#option_a, #option_b, #option_c, #option_d').prop('required', true);
        }
    });
    
    // Handle form submission for MSQ
    $('form').on('submit', function(e) {
        var type = $('#type').val();
        if (type === 'msq') {
            var textValue = $('#correct_option_text').val();
            if (textValue.trim() === '') {
                alert('Vui lòng nhập đáp án đúng cho câu hỏi MSQ');
                e.preventDefault();
                return false;
            }
            // Validate MSQ format
            var options = textValue.split(',').map(function(opt) { return opt.trim().toUpperCase(); });
            var validOptions = ['A', 'B', 'C', 'D'];
            var isValid = options.every(function(opt) { return validOptions.includes(opt); });
            if (!isValid) {
                alert('Đáp án MSQ chỉ được chứa A, B, C, D phân cách bằng dấu phẩy');
                e.preventDefault();
                return false;
            }
            // Ensure the MSQ value is properly set in both fields
            var formattedValue = textValue.toUpperCase().replace(/\s+/g, '');
            $('#correct_option_msq').val(formattedValue);
            $('#correct_option').val(formattedValue); // Also set the select field
            console.log('MSQ Debug: Setting correct_option_msq to:', formattedValue);
        }
    });
    
    // Initialize on page load
    $('#type').trigger('change');
});
</script>