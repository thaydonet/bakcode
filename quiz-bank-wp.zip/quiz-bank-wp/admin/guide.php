<?php
if (!defined('ABSPATH')) {
    exit;
}

$db = new QuizBankDatabase();
$stats = $db->get_statistics();
?>

<div class="wrap">
    <h1><?php _e('Hướng dẫn sử dụng Plugin Ngân hàng Trắc nghiệm', 'quiz-bank'); ?></h1>
    
    <!-- Statistics -->
    <div class="quiz-bank-stats">
        <div class="stat-box">
            <span class="stat-number"><?php echo $stats['total_questions']; ?></span>
            <div class="stat-label">
                <?php _e('Tổng số câu hỏi', 'quiz-bank'); ?>
                <?php if ($stats['total_questions'] > 0): ?>
                    <div class="stat-breakdown">
                        <?php 
                        $breakdown_parts = array();
                        if ($stats['total_mcq'] > 0) $breakdown_parts[] = $stats['total_mcq'] . ' Trắc nghiệm';
                        if ($stats['total_msq'] > 0) $breakdown_parts[] = $stats['total_msq'] . ' Đúng - Sai';
                        if ($stats['total_sa'] > 0) $breakdown_parts[] = $stats['total_sa'] . ' Trả lời ngắn';
                        echo ' ' . implode('; ', $breakdown_parts) . ' ';
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php foreach ($stats['by_grade'] as $grade => $count): ?>
        <div class="stat-box">
            <span class="stat-number"><?php echo $count; ?></span>
            <div class="stat-label">
                <?php echo sprintf(__('Toán %s', 'quiz-bank'), $grade); ?>
                <?php if ($count > 0 && isset($stats['by_grade_type'][$grade])): ?>
                    <div class="stat-breakdown">
                        <?php 
                        $grade_breakdown = array();
                        $grade_stats = $stats['by_grade_type'][$grade];
                        if ($grade_stats['mcq'] > 0) $grade_breakdown[] = $grade_stats['mcq'] . ' Trắc nghiệm';
                        if ($grade_stats['msq'] > 0) $grade_breakdown[] = $grade_stats['msq'] . ' Đúng - Sai';
                        if ($grade_stats['sa'] > 0) $grade_breakdown[] = $grade_stats['sa'] . ' Trả lời ngắn';
                        echo '(' . implode('; ', $grade_breakdown) . ')';
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        
        <div class="stat-box">
            <span class="stat-number"><?php echo $stats['recent_questions']; ?></span>
            <div class="stat-label">
                <?php _e('Câu hỏi tuần này', 'quiz-bank'); ?>
                <?php if ($stats['recent_questions'] > 0): ?>
                    <div class="stat-breakdown">
                        <?php 
                        $recent_breakdown = array();
                        if ($stats['recent_mcq'] > 0) $recent_breakdown[] = $stats['recent_mcq'] . ' Trắc nghiệm';
                        if ($stats['recent_msq'] > 0) $recent_breakdown[] = $stats['recent_msq'] . ' Đúng - Sai';
                        if ($stats['recent_sa'] > 0) $recent_breakdown[] = $stats['recent_sa'] . ' Trả lời ngắn';
                        echo '(' . implode('; ', $recent_breakdown) . ')';
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <h2><?php _e('1. Tổng quan về Plugin', 'quiz-bank'); ?></h2>
    <p><?php _e('Plugin Ngân hàng Trắc nghiệm được thiết kế để giúp giáo viên quản lý, tổ chức và xuất câu hỏi trắc nghiệm cho các lớp 10, 11, 12. Plugin hỗ trợ phân loại câu hỏi theo lớp, bài học, dạng và loại câu hỏi.', 'quiz-bank'); ?></p>
    
    <h2><?php _e('2. Các chức năng chính', 'quiz-bank'); ?></h2>
    
    <h3><?php _e('2.1. Quản lý câu hỏi', 'quiz-bank'); ?></h3>
    <ul>
        <li><strong><?php _e('Thêm câu hỏi mới:', 'quiz-bank'); ?></strong> <?php _e('Sử dụng menu "Thêm mới" để tạo câu hỏi trắc nghiệm với 4 đáp án A, B, C, D', 'quiz-bank'); ?></li>
        <li><strong><?php _e('Sửa câu hỏi:', 'quiz-bank'); ?></strong> <?php _e('Click "Sửa" trong danh sách câu hỏi để chỉnh sửa', 'quiz-bank'); ?></li>
        <li><strong><?php _e('Xóa câu hỏi:', 'quiz-bank'); ?></strong> <?php _e('Click "Xóa" để xóa câu hỏi (có xác nhận)', 'quiz-bank'); ?></li>
        <li><strong><?php _e('Tìm kiếm và lọc:', 'quiz-bank'); ?></strong> <?php _e('Sử dụng bộ lọc theo lớp, bài học, dạng, loại hoặc tìm kiếm theo từ khóa', 'quiz-bank'); ?></li>
    </ul>
    
    <h3><?php _e('2.2. Phân loại câu hỏi', 'quiz-bank'); ?></h3>
    <ul>
        <li><strong><?php _e('Toán:', 'quiz-bank'); ?></strong> <?php _e('10, 11, 12', 'quiz-bank'); ?></li>
        <li><strong><?php _e('Bài học:', 'quiz-bank'); ?></strong> <?php _e('Tên bài học cụ thể (ví dụ: "Bài 1: Chuyển động thẳng đều")', 'quiz-bank'); ?></li>
        <li><strong><?php _e('Dạng:', 'quiz-bank'); ?></strong> <?php _e('Lý thuyết, Bài tập, Ứng dụng, v.v.', 'quiz-bank'); ?></li>
        <li><strong><?php _e('Loại:', 'quiz-bank'); ?></strong> <?php _e('Nhận biết, Thông hiểu, Vận dụng, Vận dụng cao', 'quiz-bank'); ?></li>
    </ul>
    
    <h3><?php _e('2.3. Xuất câu hỏi', 'quiz-bank'); ?></h3>
    <ol>
        <li><?php _e('Vào trang "Danh sách" câu hỏi', 'quiz-bank'); ?></li>
        <li><?php _e('Sử dụng bộ lọc để tìm câu hỏi cần xuất (nếu cần)', 'quiz-bank'); ?></li>
        <li><?php _e('Chọn câu hỏi bằng cách tick vào checkbox', 'quiz-bank'); ?></li>
        <li><?php _e('Click "Xuất TXT" hoặc "Xuất Word" để tải file', 'quiz-bank'); ?></li>
    </ol>
    
    <h3><?php _e('2.4. Import hàng loạt', 'quiz-bank'); ?></h3>
    <ol>
        <li><?php _e('Tạo file JSON theo cấu trúc mẫu trong trang "Import"', 'quiz-bank'); ?></li>
        <li><?php _e('Vào menu "Import" và chọn file JSON', 'quiz-bank'); ?></li>
        <li><?php _e('Click "Import câu hỏi" để thực hiện', 'quiz-bank'); ?></li>
        <li><?php _e('Kiểm tra kết quả import và các lỗi (nếu có)', 'quiz-bank'); ?></li>
    </ol>
    
    <h2><?php _e('3. Cấu trúc file JSON cho Import', 'quiz-bank'); ?></h2>
    <p><?php _e('File JSON phải có cấu trúc như sau:', 'quiz-bank'); ?></p>
    <pre>{
  "questions": [
    {
     "type": "mcq",
            "question": "Trong các hàm số sau, hàm số nào đồng biến trên $\\mathbb{R}$?",
            "option_a": "$y=x^3-x$",
            "option_b": "$y=x^4$",
            "option_c": "$y=2x+1$",
            "option_d": "$y=\\frac{1}{x}$",
            "correct_option": "C",
           
      "explanation": "Giải thích (tùy chọn)"
    }
  ]
}</pre>
    
    <h2><?php _e('4. Tips sử dụng hiệu quả', 'quiz-bank'); ?></h2>
    <ul>
        <li><?php _e('Đặt tên bài học có hệ thống để dễ tìm kiếm và phân loại', 'quiz-bank'); ?></li>
        <li><?php _e('Sử dụng HTML trong câu hỏi và đáp án để định dạng (in đậm, in nghiêng, công thức)', 'quiz-bank'); ?></li>
        <li><?php _e('Thêm giải thích chi tiết cho câu hỏi khó để học sinh hiểu rõ hơn', 'quiz-bank'); ?></li>
        <li><?php _e('Sử dụng bộ lọc để tạo đề thi theo chủ đề hoặc mức độ', 'quiz-bank'); ?></li>
        <li><?php _e('Backup định kỳ bằng cách xuất toàn bộ câu hỏi', 'quiz-bank'); ?></li>
    </ul>
    
    <h2><?php _e('5. Xử lý sự cố thường gặp', 'quiz-bank'); ?></h2>
    
    <h3><?php _e('5.1. Lỗi import file JSON', 'quiz-bank'); ?></h3>
    <ul>
        <li><?php _e('Kiểm tra cú pháp JSON (dấu ngoặc, dấu phay)', 'quiz-bank'); ?></li>
        <li><?php _e('Đảm bảo tất cả trường bắt buộc có dữ liệu', 'quiz-bank'); ?></li>
        <li><?php _e('Trường correct_option chỉ chấp nhận A, B, C, D', 'quiz-bank'); ?></li>
    </ul>
    
    <h3><?php _e('5.2. Không xuất được file', 'quiz-bank'); ?></h3>
    <ul>
        <li><?php _e('Kiểm tra quyền ghi file của thư mục uploads', 'quiz-bank'); ?></li>
        <li><?php _e('Đảm bảo đã chọn ít nhất một câu hỏi', 'quiz-bank'); ?></li>
        <li><?php _e('Thử làm mới trang và thử lại', 'quiz-bank'); ?></li>
    </ul>
    
    <h3><?php _e('5.3. Hiệu suất chậm', 'quiz-bank'); ?></h3>
    <ul>
        <li><?php _e('Sử dụng bộ lọc để giảm số lượng câu hỏi hiển thị', 'quiz-bank'); ?></li>
        <li><?php _e('Phân trang để xem câu hỏi theo từng nhóm nhỏ', 'quiz-bank'); ?></li>
        <li><?php _e('Xóa các câu hỏi không cần thiết', 'quiz-bank'); ?></li>
    </ul>
    
    <h2><?php _e('6. Liên hệ hỗ trợ', 'quiz-bank'); ?></h2>
    <p><?php _e('Nếu gặp vấn đề khi sử dụng plugin, vui lòng liên hệ với người quản trị hệ thống để được hỗ trợ.', 'quiz-bank'); ?></p>
</div>