<?php
/**
 * Plugin Name: Ngân hàng Trắc nghiệm
 * Plugin URI: https://booktoan.com
 * Description: Plugin quản lý ngân hàng câu hỏi trắc nghiệm cho Toán 10, 11, 12
 * Version: 1.4
 * Author: Thầy Đồ - Qoder
 * License: GPL v2 or later
 * Text Domain: quiz-bank
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('QUIZ_BANK_VERSION', '1.4');
define('QUIZ_BANK_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('QUIZ_BANK_PLUGIN_URL', plugin_dir_url(__FILE__));
define('QUIZ_BANK_TABLE_NAME', 'quiz_bank_questions');

/**
 * Quiz Bank Plugin Main Class
 */
class QuizBankPlugin {
    
    /**
     * Constructor
     */
    public function __construct() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        add_action('plugins_loaded', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_quiz_bank_action', array($this, 'handle_ajax_request'));
        add_action('admin_post_quiz_bank_export', array($this, 'handle_export_download'));
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        $this->create_database_table();
        
        // Add default capability
        $role = get_role('administrator');
        if ($role) {
            $role->add_cap('manage_quiz_bank');
        }
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up temporary files if any
        flush_rewrite_rules();
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Load text domain
        load_plugin_textdomain('quiz-bank', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Check for database updates
        $this->check_database_update();
        
        // Include required files
        $this->include_files();
        
        // Initialize admin handlers for form processing
        if (is_admin()) {
            new QuizBankAdmin();
            new QuizBankImport(); // Initialize import class to register hooks

        }
    }
    
    /**
     * Include required files
     */
    private function include_files() {
        $files = array(
            QUIZ_BANK_PLUGIN_DIR . 'includes/class-quiz-bank-database.php',
            QUIZ_BANK_PLUGIN_DIR . 'includes/class-quiz-bank-admin.php',
            QUIZ_BANK_PLUGIN_DIR . 'includes/class-quiz-bank-export.php',
            QUIZ_BANK_PLUGIN_DIR . 'includes/class-quiz-bank-import.php',
            QUIZ_BANK_PLUGIN_DIR . 'includes/class-quiz-bank-menu-config.php'
        );
        
        foreach ($files as $file) {
            if (file_exists($file)) {
                require_once $file;
            } else {
                error_log('Quiz Bank Plugin: Missing file - ' . $file);
            }
        }
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Ngân hàng Trắc nghiệm', 'quiz-bank'),
            __('Ngân hàng TN', 'quiz-bank'),
            'manage_quiz_bank',
            'quiz-bank',
            array($this, 'admin_page'),
            'dashicons-clipboard',
            30
        );
        
        add_submenu_page(
            'quiz-bank',
            __('Danh sách câu hỏi', 'quiz-bank'),
            __('Danh sách', 'quiz-bank'),
            'manage_quiz_bank',
            'quiz-bank',
            array($this, 'admin_page')
        );
        
        add_submenu_page(
            'quiz-bank',
            __('Thêm câu hỏi', 'quiz-bank'),
            __('Thêm mới', 'quiz-bank'),
            'manage_quiz_bank',
            'quiz-bank-add',
            array($this, 'add_question_page')
        );
        
        add_submenu_page(
            'quiz-bank',
            __('Import câu hỏi', 'quiz-bank'),
            __('Import', 'quiz-bank'),
            'manage_quiz_bank',
            'quiz-bank-import',
            array($this, 'import_page')
        );
        

        
        add_submenu_page(
            'quiz-bank',
            __('Hướng dẫn', 'quiz-bank'),
            __('Hướng dẫn', 'quiz-bank'),
            'manage_quiz_bank',
            'quiz-bank-guide',
            array($this, 'guide_page')
        );
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'quiz-bank') === false) {
            return;
        }
        
        // Enqueue MathJax for LaTeX rendering in admin
        wp_enqueue_script(
            'mathjax',
            'https://polyfill.io/v3/polyfill.min.js?features=es6',
            array(),
            null,
            true
        );
        
        wp_enqueue_script(
            'mathjax-config',
            'https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js',
            array('mathjax'),
            null,
            true
        );
        
        // Add MathJax configuration
        wp_add_inline_script('mathjax', '
            window.MathJax = {
                tex: {
                    inlineMath: [["$", "$"], ["\\(", "\\)"]],
                    displayMath: [["$$", "$$"], ["\\[", "\\]"]],
                    processEscapes: true,
                    processEnvironments: true
                },
                options: {
                    skipHtmlTags: ["script", "noscript", "style", "textarea", "pre"]
                }
            };
        ', 'before');
        
        wp_enqueue_script(
            'quiz-bank-admin',
            QUIZ_BANK_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery', 'mathjax-config'),
            QUIZ_BANK_VERSION,
            true
        );
        
        wp_enqueue_style(
            'quiz-bank-admin',
            QUIZ_BANK_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            QUIZ_BANK_VERSION
        );
        
        wp_localize_script('quiz-bank-admin', 'quiz_bank_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'admin_post_url' => admin_url('admin-post.php'),
            'nonce' => wp_create_nonce('quiz_bank_nonce'),
            'messages' => array(
                'confirm_delete' => __('Bạn có chắc chắn muốn xóa câu hỏi này?', 'quiz-bank'),
                'select_questions' => __('Vui lòng chọn ít nhất một câu hỏi để xuất', 'quiz-bank'),
            )
        ));
    }
    
    /**
     * Handle AJAX requests
     */
    public function handle_ajax_request() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'quiz_bank_nonce')) {
            wp_die(__('Security check failed', 'quiz-bank'));
        }
        
        $action = sanitize_text_field($_POST['quiz_action']);
        
        switch ($action) {
            case 'delete_question':
                $this->ajax_delete_question();
                break;
            case 'export_questions':
                $this->ajax_export_questions();
                break;
            case 'get_chapters':
                $this->ajax_get_chapters();
                break;
            case 'get_lessons':
                $this->ajax_get_lessons();
                break;
            case 'get_types':
                $this->ajax_get_types();
                break;
            case 'get_categories':
                $this->ajax_get_categories();
                break;
            case 'get_menu_structure':
                $this->ajax_get_menu_structure();
                break;
            case 'get_question_stats':
                $this->ajax_get_question_stats();
                break;
            case 'get_selected_question_types':
                $this->ajax_get_selected_question_types();
                break;
            default:
                wp_send_json_error('Invalid action');
                break;
        }
    }
    
    /**
     * AJAX delete question
     */
    private function ajax_delete_question() {
        $question_id = intval($_POST['question_id']);
        
        if ($question_id > 0) {
            $quiz_db = new QuizBankDatabase();
            $result = $quiz_db->delete_question($question_id);
            
            if ($result) {
                wp_send_json_success(__('Câu hỏi đã được xóa thành công', 'quiz-bank'));
            } else {
                wp_send_json_error(__('Có lỗi xảy ra khi xóa câu hỏi', 'quiz-bank'));
            }
        } else {
            wp_send_json_error(__('ID câu hỏi không hợp lệ', 'quiz-bank'));
        }
    }
    
    /**
     * AJAX export questions
     */
    private function ajax_export_questions() {
        $question_ids = array_map('intval', $_POST['question_ids']);
        $format = sanitize_text_field($_POST['format']);
        
        if (empty($question_ids)) {
            wp_send_json_error(__('Không có câu hỏi nào được chọn', 'quiz-bank'));
            return;
        }
        
        $export = new QuizBankExport();
        $result = $export->export_questions($question_ids, $format);
        
        if ($result) {
            wp_send_json_success(array(
                'download_url' => $result,
                'message' => __('Xuất file thành công', 'quiz-bank')
            ));
        } else {
            wp_send_json_error(__('Có lỗi xảy ra khi xuất file', 'quiz-bank'));
        }
    }
    
    /**
     * AJAX get chapters
     */
    private function ajax_get_chapters() {
        $grade = sanitize_text_field($_POST['grade']);
        $menu_config = QuizBankMenuConfig::getInstance();
        $chapter_ids = $menu_config->get_chapters_by_grade($grade);
        
        // Build chapters array with full names
        $chapters = array();
        foreach ($chapter_ids as $chapter_id) {
            $chapters[] = array(
                'id' => $chapter_id,
                'name' => $menu_config->get_chapter_name($grade, $chapter_id)
            );
        }
        
        wp_send_json_success(array('chapters' => $chapters));
    }
    
    /**
     * AJAX get lessons
     */
    private function ajax_get_lessons() {
        $grade = sanitize_text_field($_POST['grade']);
        $chapter = isset($_POST['chapter']) ? sanitize_text_field($_POST['chapter']) : '';
        $menu_config = QuizBankMenuConfig::getInstance();
        
        if (!empty($chapter)) {
            $lesson_ids = $menu_config->get_lessons_by_grade_chapter($grade, $chapter);
            
            // Build lessons array with full names
            $lessons = array();
            foreach ($lesson_ids as $lesson_id) {
                $lessons[] = array(
                    'id' => $lesson_id,
                    'name' => $menu_config->get_lesson_name($grade, $chapter, $lesson_id)
                );
            }
        } else {
            // If no chapter specified, get all lessons for the grade from database
            $quiz_db = new QuizBankDatabase();
            $lesson_ids = $quiz_db->get_lessons_by_grade($grade);
            
            // Build simple lessons array for fallback
            $lessons = array();
            foreach ($lesson_ids as $lesson_id) {
                $lessons[] = array(
                    'id' => $lesson_id,
                    'name' => 'Bài ' . $lesson_id
                );
            }
        }
        
        wp_send_json_success(array('lessons' => $lessons));
    }
    
    /**
     * AJAX get types
     */
    private function ajax_get_types() {
        $grade = sanitize_text_field($_POST['grade']);
        $chapter = isset($_POST['chapter']) ? sanitize_text_field($_POST['chapter']) : '';
        $lesson = sanitize_text_field($_POST['lesson']);
        $menu_config = QuizBankMenuConfig::getInstance();
        
        if (!empty($chapter)) {
            $type_ids = $menu_config->get_types_by_grade_chapter_lesson($grade, $chapter, $lesson);
            
            // Build types array with full names
            $types = array();
            foreach ($type_ids as $type_id) {
                $types[] = array(
                    'id' => $type_id,
                    'name' => $menu_config->get_type_name($grade, $chapter, $lesson, $type_id)
                );
            }
        } else {
            // Fallback to database for backward compatibility
            $quiz_db = new QuizBankDatabase();
            $type_ids = $quiz_db->get_types_by_grade_lesson($grade, $lesson);
            
            // Build simple types array for fallback
            $types = array();
            foreach ($type_ids as $type_id) {
                $types[] = array(
                    'id' => $type_id,
                    'name' => 'Dạng ' . $type_id
                );
            }
        }
        
        wp_send_json_success(array('types' => $types));
    }
    
    /**
     * AJAX get categories
     */
    private function ajax_get_categories() {
        $grade = sanitize_text_field($_POST['grade']);
        $lesson = sanitize_text_field($_POST['lesson']);
        $type = sanitize_text_field($_POST['type']);
        
        // First try to get from menu config
        $menu_config = QuizBankMenuConfig::getInstance();
        $categories = $menu_config->get_categories();
        
        // If no predefined categories, get from database
        if (empty($categories)) {
            $quiz_db = new QuizBankDatabase();
            $categories = $quiz_db->get_categories_by_grade_lesson_type($grade, $lesson, $type);
        }
        
        wp_send_json_success($categories);
    }
    
    /**
     * AJAX get menu structure for JavaScript
     */
    private function ajax_get_menu_structure() {
        $grade = isset($_POST['grade']) ? sanitize_text_field($_POST['grade']) : '';
        $menu_config = QuizBankMenuConfig::getInstance();
        
        if (!empty($grade)) {
            $structure = $menu_config->get_grade_structure($grade);
        } else {
            $structure = $menu_config->get_full_menu_data();
        }
        
        wp_send_json_success($structure);
    }
    
    /**
     * AJAX get question statistics
     */
    private function ajax_get_question_stats() {
        $filters = array(
            'lop' => isset($_POST['lop']) ? sanitize_text_field($_POST['lop']) : '',
            'chuong' => isset($_POST['chuong']) ? sanitize_text_field($_POST['chuong']) : '',
            'bai_hoc' => isset($_POST['bai_hoc']) ? sanitize_text_field($_POST['bai_hoc']) : '',
            'dang' => isset($_POST['dang']) ? sanitize_text_field($_POST['dang']) : '',
            'muc_do' => isset($_POST['muc_do']) ? sanitize_text_field($_POST['muc_do']) : '',
            'search' => isset($_POST['search']) ? sanitize_text_field($_POST['search']) : ''
        );
        
        $quiz_db = new QuizBankDatabase();
        
        // Get total count
        $total_count = $quiz_db->get_questions_count($filters);
        
        // Get count by type
        $mcq_filters = array_merge($filters, array('type' => 'mcq'));
        $msq_filters = array_merge($filters, array('type' => 'msq'));
        $sa_filters = array_merge($filters, array('type' => 'sa'));
        
        $mcq_count = $quiz_db->get_questions_count($mcq_filters);
        $msq_count = $quiz_db->get_questions_count($msq_filters);
        $sa_count = $quiz_db->get_questions_count($sa_filters);
        
        $stats = array(
            'total' => $total_count,
            'mcq' => $mcq_count,
            'msq' => $msq_count,
            'sa' => $sa_count
        );
        
        wp_send_json_success($stats);
    }
    
    /**
     * AJAX get selected question types for accurate counting
     */
    private function ajax_get_selected_question_types() {
        $question_ids = isset($_POST['question_ids']) ? array_map('intval', $_POST['question_ids']) : array();
        
        if (empty($question_ids)) {
            wp_send_json_success(array(
                'mcq' => 0,
                'msq' => 0,
                'sa' => 0
            ));
            return;
        }
        
        $quiz_db = new QuizBankDatabase();
        $questions = $quiz_db->get_questions_by_ids($question_ids);
        
        $mcq_count = 0;
        $msq_count = 0;
        $sa_count = 0;
        
        foreach ($questions as $question) {
            switch ($question->type) {
                case 'mcq':
                    $mcq_count++;
                    break;
                case 'msq':
                    $msq_count++;
                    break;
                case 'sa':
                    $sa_count++;
                    break;
            }
        }
        
        $stats = array(
            'mcq' => $mcq_count,
            'msq' => $msq_count,
            'sa' => $sa_count
        );
        
        wp_send_json_success($stats);
    }
    
    /**
     * Handle direct export download
     */
    public function handle_export_download() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'quiz_bank_nonce')) {
            wp_die(__('Security check failed', 'quiz-bank'));
        }
        
        $question_ids = array_map('intval', $_POST['question_ids']);
        $format = sanitize_text_field($_POST['format']);
        
        // Get export options
        $num_exams = isset($_POST['num_exams']) ? intval($_POST['num_exams']) : 1;
        $shuffle_questions = isset($_POST['shuffle_questions']) && $_POST['shuffle_questions'] === '1';
        $shuffle_answers = isset($_POST['shuffle_answers']) && $_POST['shuffle_answers'] === '1';
        
        if (empty($question_ids)) {
            wp_die(__('Không có câu hỏi nào được chọn', 'quiz-bank'));
        }
        
        $export = new QuizBankExport();
        
        // Prepare export options
        $options = array(
            'exam_mode' => $num_exams > 1 || $shuffle_questions || $shuffle_answers,
            'exam_code' => null,
            'shuffle_questions' => $shuffle_questions,
            'shuffle_answers' => $shuffle_answers,
            'num_exams' => $num_exams
        );
        
        // Use force_download method for immediate download
        $export->force_download($question_ids, $format, $options);
    }
    
    /**
     * Main admin page
     */
    public function admin_page() {
        $admin = new QuizBankAdmin();
        $admin->display_questions_page();
    }
    
    /**
     * Add question page
     */
    public function add_question_page() {
        $admin = new QuizBankAdmin();
        $admin->display_add_question_page();
    }
    
    /**
     * Import page
     */
    public function import_page() {
        $import = new QuizBankImport();
        $import->display_import_page();
    }
    
    /**
     * Guide page
     */
    public function guide_page() {
        include QUIZ_BANK_PLUGIN_DIR . 'admin/guide.php';
    }
    

    
    /**
     * Create database table
     */
    private function create_database_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . QUIZ_BANK_TABLE_NAME;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            lop varchar(10) NOT NULL,
            chuong varchar(50) NOT NULL,
            bai_hoc varchar(255) NOT NULL,
            dang varchar(255) NOT NULL,
            muc_do varchar(100) NOT NULL,
            type enum('mcq','msq','sa') NOT NULL DEFAULT 'mcq',
            cau_hoi text NOT NULL,
            option_a text,
            option_b text,
            option_c text,
            option_d text,
            correct_option varchar(10),
            correct_answer text,
            explanation text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY lop (lop),
            KEY chuong (chuong),
            KEY bai_hoc (bai_hoc),
            KEY dang (dang),
            KEY muc_do (muc_do),
            KEY type (type)
        ) $charset_collate;";
        
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
        
        // Add version option
        $current_version = get_option('quiz_bank_db_version', '0');
        if ($current_version !== '1.3') {
            add_option('quiz_bank_db_version', '1.3');
        }
    }
    
    /**
     * Check for database updates
     */
    private function check_database_update() {
        $current_version = get_option('quiz_bank_db_version', '0');
        
        if ($current_version !== '1.3') {
            $this->create_database_table();
            update_option('quiz_bank_db_version', '1.3');
        }
    }
}

// Initialize the plugin
new QuizBankPlugin();