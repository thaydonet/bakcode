// Quiz Bank Admin JavaScript

// Global variables for persistent selection
var selectedQuestionIds = new Set();
var lastFilterState = {};

// Storage keys
const STORAGE_KEY_SELECTIONS = 'quiz_bank_selected_questions';
const STORAGE_KEY_FILTERS = 'quiz_bank_last_filters';

jQuery(document).ready(function($) {
    
    // Load persistent data from localStorage
    loadPersistentDataFromStorage();
    
    // Initialize
    initializeFilters();
    initializeExportControls();
    initializeQuestionSelection();
    initializeDeleteFunctionality();
    initializeExplanationToggle();
    initializeQuestionStats();
    initializeLaTeXRendering();
    
    // Load persistent selections
    loadPersistentSelections();
    
    // Initialize selected count on page load
    updateSelectedCount();
    updateSelectAllCheckbox();
    
    // Initialize tooltips if available
    if (typeof $.fn.tooltip !== 'undefined') {
        $('[data-tooltip]').tooltip();
    }
    
    // Initialize view toggle
    initializeViewToggle();
    
    // Save to localStorage before page unload
    $(window).on('beforeunload', function() {
        savePersistentDataToStorage();
    });
    
    /**
     * Load persistent data from localStorage
     */
    function loadPersistentDataFromStorage() {
        try {
            // Load selected question IDs
            const savedSelections = localStorage.getItem(STORAGE_KEY_SELECTIONS);
            if (savedSelections) {
                const selectionsArray = JSON.parse(savedSelections);
                selectedQuestionIds = new Set(selectionsArray);
            }
            
            // Load last filter state
            const savedFilters = localStorage.getItem(STORAGE_KEY_FILTERS);
            if (savedFilters) {
                lastFilterState = JSON.parse(savedFilters);
            }
        } catch (e) {
            console.log('Failed to load persistent data:', e);
        }
    }
    
    /**
     * Save persistent data to localStorage
     */
    function savePersistentDataToStorage() {
        try {
            // Save selected question IDs
            const selectionsArray = Array.from(selectedQuestionIds);
            localStorage.setItem(STORAGE_KEY_SELECTIONS, JSON.stringify(selectionsArray));
            
            // Save current filter state
            const currentFilters = {
                lop: $('#filter-lop').val(),
                chuong: $('#filter-chuong').val(),
                bai_hoc: $('#filter-bai-hoc').val(),
                dang: $('#filter-dang').val(),
                muc_do: $('#filter-muc-do').val(),
                type: $('#filter-type').val(),
                search: $('input[name="search"]').val()
            };
            localStorage.setItem(STORAGE_KEY_FILTERS, JSON.stringify(currentFilters));
        } catch (e) {
            console.log('Failed to save persistent data:', e);
        }
    }
    
    /**
     * Initialize filters
     */
    function initializeFilters() {
        $('#filter-lop').on('change', function() {
            const grade = $(this).val();
            savePersistentSelections();
            updateChaptersDropdown(grade);
            updateQuestionStats();
        });
        
        $('#filter-chuong').on('change', function() {
            const grade = $('#filter-lop').val();
            const chapter = $(this).val();
            savePersistentSelections();
            updateLessonsDropdown(grade, chapter);
            updateQuestionStats();
        });
        
        $('#filter-bai-hoc').on('change', function() {
            const grade = $('#filter-lop').val();
            const chapter = $('#filter-chuong').val();
            const lesson = $(this).val();
            savePersistentSelections();
            updateTypesDropdown(grade, chapter, lesson);
            updateQuestionStats();
        });
        
        $('#filter-dang').on('change', function() {
            const grade = $('#filter-lop').val();
            const lesson = $('#filter-bai-hoc').val();
            const type = $(this).val();
            savePersistentSelections();
            updateCategoriesDropdown(grade, lesson, type);
            updateQuestionStats();
        });
        
        $('#filter-muc-do, #filter-type, input[name="search"]').on('change keyup', function() {
            savePersistentSelections();
            updateQuestionStats();
        });
        
        // Load initial data based on current selections
        const currentGrade = $('#filter-lop').val();
        if (currentGrade) {
            updateChaptersDropdown(currentGrade);
        }
        
        // Load initial stats
        updateQuestionStats();
        
        // Listen for form submission and save selections before submit
        $('#quiz-bank-filter-form').on('submit', function() {
            savePersistentSelections();
        });
    }
    
    /**
     * Update chapters dropdown
     */
    function updateChaptersDropdown(grade) {
        if (!grade) {
            $('#filter-chuong').html('<option value="">Tất cả chương</option>');
            $('#filter-bai-hoc').html('<option value="">Tất cả bài học</option>');
            $('#filter-dang').html('<option value="">Tất cả dạng</option>');
            $('#filter-muc-do').html('<option value="">Tất cả mức độ</option>');
            return;
        }
        
        $.post(quiz_bank_ajax.ajax_url, {
            action: 'quiz_bank_action',
            quiz_action: 'get_chapters',
            grade: grade,
            nonce: quiz_bank_ajax.nonce
        }, function(response) {
            if (response.success) {
                let options = '<option value="">Tất cả chương</option>';
                if (response.data.chapters) {
                    // If response includes full names
                    response.data.chapters.forEach(function(chapter) {
                        options += '<option value="' + chapter.id + '">' + chapter.name + '</option>';
                    });
                } else {
                    // Fallback to simple array
                    response.data.forEach(function(chapter) {
                        options += '<option value="' + chapter + '">Chương ' + chapter + '</option>';
                    });
                }
                $('#filter-chuong').html(options);
                // Restore selections after content update
                setTimeout(loadPersistentSelections, 100);
            }
        });
    }
    
    /**
     * Update lessons dropdown
     */
    function updateLessonsDropdown(grade, chapter) {
        if (!grade) {
            $('#filter-bai-hoc').html('<option value="">Tất cả bài học</option>');
            $('#filter-dang').html('<option value="">Tất cả dạng</option>');
            $('#filter-muc-do').html('<option value="">Tất cả mức độ</option>');
            return;
        }
        
        $.post(quiz_bank_ajax.ajax_url, {
            action: 'quiz_bank_action',
            quiz_action: 'get_lessons',
            grade: grade,
            chapter: chapter,
            nonce: quiz_bank_ajax.nonce
        }, function(response) {
            if (response.success) {
                let options = '<option value="">Tất cả bài học</option>';
                if (response.data.lessons) {
                    // If response includes full names
                    response.data.lessons.forEach(function(lesson) {
                        options += '<option value="' + lesson.id + '">' + lesson.name + '</option>';
                    });
                } else {
                    // Fallback to simple array
                    response.data.forEach(function(lesson) {
                        options += '<option value="' + lesson + '">Bài ' + lesson + '</option>';
                    });
                }
                $('#filter-bai-hoc').html(options);
                // Restore selections after content update
                setTimeout(loadPersistentSelections, 100);
            }
        });
    }
    
    /**
     * Update types dropdown
     */
    function updateTypesDropdown(grade, chapter, lesson) {
        if (!grade || !lesson) {
            $('#filter-dang').html('<option value="">Tất cả dạng</option>');
            $('#filter-muc-do').html('<option value="">Tất cả mức độ</option>');
            return;
        }
        
        $.post(quiz_bank_ajax.ajax_url, {
            action: 'quiz_bank_action',
            quiz_action: 'get_types',
            grade: grade,
            chapter: chapter,
            lesson: lesson,
            nonce: quiz_bank_ajax.nonce
        }, function(response) {
            if (response.success) {
                let options = '<option value="">Tất cả dạng</option>';
                if (response.data.types) {
                    // If response includes full names
                    response.data.types.forEach(function(type) {
                        options += '<option value="' + type.id + '">' + type.name + '</option>';
                    });
                } else {
                    // Fallback to simple array
                    response.data.forEach(function(type) {
                        options += '<option value="' + type + '">Dạng ' + type + '</option>';
                    });
                }
                $('#filter-dang').html(options);
                // Restore selections after content update
                setTimeout(loadPersistentSelections, 100);
            }
        });
    }
    
    /**
     * Update categories dropdown
     */
    function updateCategoriesDropdown(grade, lesson, type) {
        if (!grade || !lesson || !type) {
            $('#filter-muc-do').html('<option value="">Tất cả mức độ</option>');
            return;
        }
        
        $.post(quiz_bank_ajax.ajax_url, {
            action: 'quiz_bank_action',
            quiz_action: 'get_categories',
            grade: grade,
            lesson: lesson,
            type: type,
            nonce: quiz_bank_ajax.nonce
        }, function(response) {
            if (response.success) {
                let options = '<option value="">Tất cả mức độ</option>';
                response.data.forEach(function(category) {
                    options += '<option value="' + category + '">' + category + '</option>';
                });
                $('#filter-muc-do').html(options);
                // Restore selections after content update
                setTimeout(loadPersistentSelections, 100);
            }
        });
    }
    
    /**
     * Initialize export controls
     */
    function initializeExportControls() {
        $('#select-all-questions').on('click', function() {
            const visibleCheckboxes = $('.question-checkbox:visible');
            const allVisibleChecked = visibleCheckboxes.filter(':checked').length === visibleCheckboxes.length;
            
            visibleCheckboxes.each(function() {
                const questionId = $(this).val();
                const $card = $(this).closest('.question-card');
                const $row = $(this).closest('tr');
                
                if (allVisibleChecked) {
                    // Uncheck all visible
                    $(this).prop('checked', false);
                    selectedQuestionIds.delete(questionId);
                    $card.removeClass('selected');
                    $row.removeClass('selected');
                } else {
                    // Check all visible
                    $(this).prop('checked', true);
                    selectedQuestionIds.add(questionId);
                    $card.addClass('selected');
                    $row.addClass('selected');
                }
            });
            
            updateSelectAllCheckbox();
            updateSelectedCount();
            savePersistentDataToStorage(); // Save to localStorage
        });
        
        $('#clear-all-selections').on('click', function() {
            if (selectedQuestionIds.size > 0) {
                if (confirm('Bạn có chắc muốn bỏ chọn tất cả câu hỏi đã chọn?')) {
                    // Clear all selections
                    selectedQuestionIds.clear();
                    $('.question-checkbox').prop('checked', false);
                    $('.question-card').removeClass('selected');
                    $('tr').removeClass('selected');
                    
                    updateSelectAllCheckbox();
                    updateSelectedCount();
                    savePersistentDataToStorage(); // Save to localStorage
                }
            }
        });
        
        $('#export-txt').on('click', function() {
            exportQuestions('txt');
        });
        
        $('#export-word').on('click', function() {
            exportQuestions('word');
        });
    }
    
    /**
     * Initialize question selection
     */
    function initializeQuestionSelection() {
        $('#cb-select-all').on('change', function() {
            $('.question-checkbox').prop('checked', this.checked);
            // Update persistent selection
            $('.question-checkbox').each(function() {
                const questionId = $(this).val();
                const $card = $(this).closest('.question-card');
                const $row = $(this).closest('tr');
                
                if (this.checked) {
                    selectedQuestionIds.add(questionId);
                    $card.addClass('selected');
                    $row.addClass('selected');
                } else {
                    selectedQuestionIds.delete(questionId);
                    $card.removeClass('selected');
                    $row.removeClass('selected');
                }
            });
            updateSelectedCount();
            savePersistentDataToStorage(); // Save to localStorage
        });
        
        $(document).on('change', '.question-checkbox', function() {
            const questionId = $(this).val();
            const $card = $(this).closest('.question-card');
            const $row = $(this).closest('tr');
            
            if (this.checked) {
                selectedQuestionIds.add(questionId);
                $card.addClass('selected');
                $row.addClass('selected');
            } else {
                selectedQuestionIds.delete(questionId);
                $card.removeClass('selected');
                $row.removeClass('selected');
            }
            updateSelectAllCheckbox();
            updateSelectedCount();
            savePersistentDataToStorage(); // Save to localStorage
        });
    }
    
    /**
     * Update select all checkbox
     */
    function updateSelectAllCheckbox() {
        const totalCheckboxes = $('.question-checkbox').length;
        const checkedCheckboxes = $('.question-checkbox:checked').length;
        
        $('#cb-select-all').prop({
            'checked': checkedCheckboxes === totalCheckboxes && totalCheckboxes > 0,
            'indeterminate': checkedCheckboxes > 0 && checkedCheckboxes < totalCheckboxes
        });
    }
    
    /**
     * Update selected count with detailed breakdown
     */
    function updateSelectedCount() {
        const totalCount = selectedQuestionIds.size;
        
        if (totalCount === 0) {
            $('#selected-count').text('0 câu được chọn');
            return;
        }
        
        // Get question type counts from server for accurate statistics
        const selectedIdsArray = Array.from(selectedQuestionIds);
        
        $.post(quiz_bank_ajax.ajax_url, {
            action: 'quiz_bank_action',
            quiz_action: 'get_selected_question_types',
            question_ids: selectedIdsArray,
            nonce: quiz_bank_ajax.nonce
        }, function(response) {
            if (response.success) {
                const stats = response.data;
                let countText = totalCount + ' câu được chọn';
                
                if (totalCount > 0) {
                    const details = [];
                    if (stats.mcq > 0) details.push(stats.mcq + ' câu Trắc nghiệm');
                    if (stats.msq > 0) details.push(stats.msq + ' câu Đúng - Sai');
                    if (stats.sa > 0) details.push(stats.sa + ' câu trả lời ngắn');
                    
                    if (details.length > 0) {
                        countText += ' (' + details.join('; ') + ')';
                    }
                }
                
                $('#selected-count').text(countText);
            } else {
                // Fallback to simple count if server request fails
                $('#selected-count').text(totalCount + ' câu được chọn');
            }
        }).fail(function() {
            // Fallback to simple count if server request fails
            $('#selected-count').text(totalCount + ' câu được chọn');
        });
    }
    
    /**
     * Save persistent selections
     */
    function savePersistentSelections() {
        // Update persistent selection from current checkboxes
        $('.question-checkbox:checked').each(function() {
            selectedQuestionIds.add($(this).val());
        });
        
        // Save to localStorage immediately
        savePersistentDataToStorage();
    }
    
    /**
     * Load persistent selections
     */
    function loadPersistentSelections() {
        // Wait for DOM to be ready then restore selections
        setTimeout(function() {
            $('.question-checkbox').each(function() {
                const questionId = $(this).val();
                const $card = $(this).closest('.question-card');
                const $row = $(this).closest('tr');
                
                if (selectedQuestionIds.has(questionId)) {
                    $(this).prop('checked', true);
                    $card.addClass('selected');
                    $row.addClass('selected');
                } else {
                    $(this).prop('checked', false);
                    $card.removeClass('selected');
                    $row.removeClass('selected');
                }
            });
            updateSelectAllCheckbox();
            updateSelectedCount();
        }, 500);
    }
    
    /**
     * Initialize question statistics
     */
    function initializeQuestionStats() {
        // Add stats container if it doesn't exist
        if ($('#question-stats').length === 0) {
            const statsHtml = '<div id="question-stats" class="quiz-bank-stats"></div>';
            $('.quiz-bank-export-controls').after(statsHtml);
        }
    }
    
    /**
     * Update question statistics
     */
    function updateQuestionStats() {
        const filters = {
            lop: $('#filter-lop').val(),
            chuong: $('#filter-chuong').val(),
            bai_hoc: $('#filter-bai-hoc').val(),
            dang: $('#filter-dang').val(),
            muc_do: $('#filter-muc-do').val(),
            search: $('input[name="search"]').val()
        };
        
        $.post(quiz_bank_ajax.ajax_url, {
            action: 'quiz_bank_action',
            quiz_action: 'get_question_stats',
            ...filters,
            nonce: quiz_bank_ajax.nonce
        }, function(response) {
            if (response.success) {
                displayQuestionStats(response.data);
            }
        });
    }
    
    /**
     * Display question statistics
     */
    function displayQuestionStats(stats) {
        let statsHtml = '<div class="stats-row">';
        
        // Total count
        statsHtml += '<div class="stat-item total">';
        statsHtml += '<span class="stat-number">' + stats.total + '</span>';
        statsHtml += '<span class="stat-label">Tổng cộng</span>';
        statsHtml += '</div>';
        
        // MCQ count
        if (stats.mcq > 0) {
            statsHtml += '<div class="stat-item mcq">';
            statsHtml += '<span class="stat-number">' + stats.mcq + '</span>';
            statsHtml += '<span class="stat-label">Trắc nghiệm</span>';
            statsHtml += '</div>';
        }
        
        // MSQ count
        if (stats.msq > 0) {
            statsHtml += '<div class="stat-item msq">';
            statsHtml += '<span class="stat-number">' + stats.msq + '</span>';
            statsHtml += '<span class="stat-label">Đúng - Sai</span>';
            statsHtml += '</div>';
        }
        
        // SA count
        if (stats.sa > 0) {
            statsHtml += '<div class="stat-item sa">';
            statsHtml += '<span class="stat-number">' + stats.sa + '</span>';
            statsHtml += '<span class="stat-label">Trả lời ngắn</span>';
            statsHtml += '</div>';
        }
        
        statsHtml += '</div>';
        
        $('#question-stats').html(statsHtml);
    }
    
    /**
     * Initialize LaTeX rendering
     */
    function initializeLaTeXRendering() {
        // Check if MathJax is available
        if (typeof MathJax !== 'undefined') {
            renderMathJax();
        } else if (typeof latex2html !== 'undefined') {
            // Use latex2html plugin if available
            renderLatex2Html();
        } else {
            // Custom LaTeX rendering for simple formulas
            renderCustomLatex();
        }
        
        // Re-render when new content is loaded
        $(document).on('DOMNodeInserted', '.question-card', function() {
            if (typeof MathJax !== 'undefined') {
                MathJax.typesetPromise([this]);
            } else if (typeof latex2html !== 'undefined') {
                latex2html.render(this);
            } else {
                renderCustomLatex($(this));
            }
        });
        
        // Listen for custom LaTeX render events
        $(document).on('latex-render-needed', function() {
            setTimeout(function() {
                if (typeof MathJax !== 'undefined') {
                    MathJax.typesetPromise();
                } else if (typeof latex2html !== 'undefined') {
                    latex2html.render();
                } else {
                    renderCustomLatex();
                }
            }, 100);
        });
    }
    
    /**
     * Render LaTeX using MathJax
     */
    function renderMathJax() {
        if (typeof MathJax !== 'undefined' && MathJax.typesetPromise) {
            MathJax.typesetPromise();
        }
    }
    
    /**
     * Render LaTeX using latex2html plugin
     */
    function renderLatex2Html() {
        if (typeof latex2html !== 'undefined' && latex2html.render) {
            latex2html.render();
        }
    }
    
    /**
     * Custom LaTeX rendering for simple formulas
     */
    function renderCustomLatex($container) {
        const container = $container || $(document);
        
        // Find all LaTeX expressions in $...$
        container.find('.question-text, .option-text, .explanation-text, .sa-answer').each(function() {
            let html = $(this).html();
            
            // Replace $formula$ with formatted math
            html = html.replace(/\$([^$]+)\$/g, function(match, formula) {
                return '<span class="latex-formula" title="' + formula + '">' + formatLatexFormula(formula) + '</span>';
            });
            
            $(this).html(html);
        });
    }
    
    /**
     * Basic LaTeX formula formatting
     */
    function formatLatexFormula(formula) {
        // Basic replacements for common LaTeX commands
        let formatted = formula;
        
        // Fractions: \frac{a}{b}
        formatted = formatted.replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, 
            '<span class="fraction"><span class="numerator">$1</span><span class="denominator">$2</span></span>');
        
        // Superscript: ^{...} or ^x
        formatted = formatted.replace(/\^\{([^}]+)\}/g, '<sup>$1</sup>');
        formatted = formatted.replace(/\^([a-zA-Z0-9])/g, '<sup>$1</sup>');
        
        // Subscript: _{...} or _x
        formatted = formatted.replace(/_\{([^}]+)\}/g, '<sub>$1</sub>');
        formatted = formatted.replace(/_([a-zA-Z0-9])/g, '<sub>$1</sub>');
        
        // Square root: \sqrt{...}
        formatted = formatted.replace(/\\sqrt\{([^}]+)\}/g, '√($1)');
        
        // Greek letters
        const greekLetters = {
            'alpha': 'α', 'beta': 'β', 'gamma': 'γ', 'delta': 'δ',
            'epsilon': 'ε', 'theta': 'θ', 'lambda': 'λ', 'mu': 'μ',
            'pi': 'π', 'sigma': 'σ', 'phi': 'φ', 'omega': 'ω'
        };
        
        for (let letter in greekLetters) {
            formatted = formatted.replace(new RegExp('\\\\' + letter, 'g'), greekLetters[letter]);
        }
        
        // Math symbols
        formatted = formatted.replace(/\\times/g, '×');
        formatted = formatted.replace(/\\div/g, '÷');
        formatted = formatted.replace(/\\pm/g, '±');
        formatted = formatted.replace(/\\infty/g, '∞');
        formatted = formatted.replace(/\\leq/g, '≤');
        formatted = formatted.replace(/\\geq/g, '≥');
        formatted = formatted.replace(/\\neq/g, '≠');
        formatted = formatted.replace(/\\approx/g, '≈');
        
        return formatted;
    }
    
    /**
     * Export questions with popup options
     */
    function exportQuestions(format) {
        // Use persistent selection instead of just visible checkboxes
        const selectedIds = Array.from(selectedQuestionIds);
        
        if (selectedIds.length === 0) {
            alert(quiz_bank_ajax.messages.select_questions);
            return;
        }
        
        // Show export options popup
        showExportOptionsPopup(format, selectedIds);
    }
    
    /**
     * Show export options popup
     */
    function showExportOptionsPopup(format, selectedIds) {
        // Create popup HTML
        const popupHtml = `
            <div id="export-options-popup" class="export-popup-overlay">
                <div class="export-popup-content">
                    <h3>Tùy chọn xuất đề</h3>
                    <div class="export-option-row">
                        <label for="num-exams">Bạn in mấy đề:</label>
                        <input type="number" id="num-exams" min="1" max="50" value="1">
                    </div>
                    <div class="export-option-row">
                        <label>
                            <input type="checkbox" id="shuffle-questions"> Trộn câu hỏi
                        </label>
                        <small>(Trộn câu hỏi theo từng phần)</small>
                    </div>
                    <div class="export-option-row">
                        <label>
                            <input type="checkbox" id="shuffle-answers"> Trộn đáp án
                        </label>
                        <small>(Chỉ trộn cho phần I - MCQ)</small>
                    </div>
                    <div class="export-popup-buttons">
                        <button type="button" id="export-confirm-btn" class="button button-primary">Xuất đề</button>
                        <button type="button" id="export-cancel-btn" class="button">Hủy</button>
                    </div>
                </div>
            </div>
        `;
        
        // Add popup to page
        $('body').append(popupHtml);
        
        // Handle confirm button
        $('#export-confirm-btn').on('click', function() {
            const numExams = parseInt($('#num-exams').val()) || 1;
            const shuffleQuestions = $('#shuffle-questions').is(':checked');
            const shuffleAnswers = $('#shuffle-answers').is(':checked');
            
            // Close popup
            $('#export-options-popup').remove();
            
            // Proceed with export
            performExportWithOptions(format, selectedIds, numExams, shuffleQuestions, shuffleAnswers);
        });
        
        // Handle cancel button
        $('#export-cancel-btn').on('click', function() {
            $('#export-options-popup').remove();
        });
        
        // Handle click outside popup
        $('#export-options-popup').on('click', function(e) {
            if (e.target === this) {
                $(this).remove();
            }
        });
    }
    
    /**
     * Perform export with options
     */
    function performExportWithOptions(format, selectedIds, numExams, shuffleQuestions, shuffleAnswers) {
        const $button = format === 'txt' ? $('#export-txt') : $('#export-word');
        const originalText = $button.text();
        
        $button.prop('disabled', true).text('Đang xuất...');
        
        // Create a form for file download
        const form = $('<form>', {
            method: 'POST',
            action: quiz_bank_ajax.admin_post_url
        });
        
        // Add hidden fields
        form.append($('<input>', {
            type: 'hidden',
            name: 'action',
            value: 'quiz_bank_export'
        }));
        
        form.append($('<input>', {
            type: 'hidden',
            name: 'nonce',
            value: quiz_bank_ajax.nonce
        }));
        
        form.append($('<input>', {
            type: 'hidden',
            name: 'format',
            value: format
        }));
        
        // Add export options
        form.append($('<input>', {
            type: 'hidden',
            name: 'num_exams',
            value: numExams
        }));
        
        form.append($('<input>', {
            type: 'hidden',
            name: 'shuffle_questions',
            value: shuffleQuestions ? '1' : '0'
        }));
        
        form.append($('<input>', {
            type: 'hidden',
            name: 'shuffle_answers',
            value: shuffleAnswers ? '1' : '0'
        }));
        
        // Add question IDs
        selectedIds.forEach(function(id) {
            form.append($('<input>', {
                type: 'hidden',
                name: 'question_ids[]',
                value: id
            }));
        });
        
        // Submit the form
        $('body').append(form);
        form.submit();
        form.remove();
        
        // Reset button after a short delay
        setTimeout(function() {
            $button.prop('disabled', false).text(originalText);
            showNotice('success', 'File sẽ được tải xuống tự động');
        }, 1000);
    }
    
    /**
     * Initialize delete functionality
     */
    function initializeDeleteFunctionality() {
        $(document).on('click', '.delete-question', function() {
            if (!confirm(quiz_bank_ajax.messages.confirm_delete)) {
                return;
            }
            
            const questionId = $(this).data('id');
            const $row = $(this).closest('tr');
            const $card = $(this).closest('.question-card');
            const $button = $(this);
            
            $button.prop('disabled', true).text('Đang xóa...');
            
            $.post(quiz_bank_ajax.ajax_url, {
                action: 'quiz_bank_action',
                quiz_action: 'delete_question',
                question_id: questionId,
                nonce: quiz_bank_ajax.nonce
            }, function(response) {
                if (response.success) {
                    // Remove table row or card
                    if ($row.length) {
                        $row.fadeOut(300, function() {
                            $(this).remove();
                            updateSelectedCount();
                            updateSelectAllCheckbox();
                        });
                    } else {
                        $card.fadeOut(300, function() {
                            $(this).remove();
                            updateSelectedCount();
                            updateSelectAllCheckbox();
                        });
                    }
                    showNotice('success', response.data);
                } else {
                    showNotice('error', response.data || 'Có lỗi xảy ra khi xóa câu hỏi');
                    $button.prop('disabled', false).text('Xóa');
                }
            }).fail(function() {
                showNotice('error', 'Có lỗi xảy ra khi xóa câu hỏi');
                $button.prop('disabled', false).text('Xóa');
            });
        });
    }
    
    /**
     * Show notice
     */
    function showNotice(type, message) {
        const noticeClass = type === 'success' ? 'notice-success' : 'notice-error';
        const notice = $('<div class="notice ' + noticeClass + ' is-dismissible"><p>' + message + '</p></div>');
        
        $('.wrap h1').after(notice);
        
        // Auto dismiss after 3 seconds
        setTimeout(function() {
            notice.fadeOut();
        }, 3000);
        
        // Manual dismiss
        notice.on('click', '.notice-dismiss', function() {
            notice.fadeOut();
        });
    }
    
    // Initialize tooltips if available
    if (typeof $.fn.tooltip !== 'undefined') {
        $('[data-tooltip]').tooltip();
    }
    
    // Initialize view toggle
    initializeViewToggle();
    
    /**
     * Initialize view toggle between grid and table
     */
    function initializeViewToggle() {
        // Get saved view preference
        var savedView = localStorage.getItem('quiz-bank-view') || 'grid';
        
        // Set initial view
        if (savedView === 'table') {
            switchToTableView();
        } else {
            switchToGridView();
        }
        
        // Handle grid view button
        $('#grid-view').on('click', function() {
            switchToGridView();
            localStorage.setItem('quiz-bank-view', 'grid');
        });
        
        // Handle table view button
        $('#table-view').on('click', function() {
            switchToTableView();
            localStorage.setItem('quiz-bank-view', 'table');
        });
    }
    
    function switchToGridView() {
        $('.quiz-bank-questions-grid').show();
        $('.quiz-bank-questions-table').hide();
        $('#grid-view').addClass('active');
        $('#table-view').removeClass('active');
    }
    
    function switchToTableView() {
        $('.quiz-bank-questions-grid').hide();
        $('.quiz-bank-questions-table').show();
        $('#table-view').addClass('active');
        $('#grid-view').removeClass('active');
    }
    
    /**
     * Initialize explanation toggle functionality
     */
    function initializeExplanationToggle() {
        $(document).on('click', '.explanation-toggle', function() {
            const questionId = $(this).data('question-id');
            const $explanation = $('#explanation-' + questionId);
            const $icon = $(this).find('.dashicons');
            const $text = $(this).find('.toggle-text');
            
            if ($explanation.is(':visible')) {
                $explanation.slideUp(300);
                $icon.removeClass('dashicons-hidden').addClass('dashicons-visibility');
                $text.text('Hiện lời giải');
                $(this).removeClass('active');
            } else {
                $explanation.slideDown(300);
                $icon.removeClass('dashicons-visibility').addClass('dashicons-hidden');
                $text.text('Ẩn lời giải');
                $(this).addClass('active');
            }
        });
    }
});

