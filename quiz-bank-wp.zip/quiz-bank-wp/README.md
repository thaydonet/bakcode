# Plugin Ngân hàng Trắc nghiệm WordPress

## Mô tả

Plugin Ngân hàng Trắc nghiệm là một công cụ mạnh mẽ được thiết kế dành cho giáo viên và cơ sở giáo dục để quản lý, tổ chức và xuất câu hỏi trắc nghiệm cho các lớp 10, 11, 12. Plugin hỗ trợ phân loại câu hỏi chi tiết và nhiều tính năng hữu ích.

## Tính năng chính

### 🎯 Quản lý câu hỏi
- **Thêm câu hỏi mới**: Tạo câu hỏi trắc nghiệm với 4 đáp án A, B, C, D
- **Sửa/Xóa câu hỏi**: Chỉnh sửa hoặc xóa câu hỏi có sẵn
- **Tìm kiếm và lọc**: Bộ lọc theo lớp, bài học, dạng, loại hoặc tìm kiếm từ khóa
- **Phân trang**: Hiển thị danh sách câu hỏi có phân trang

### 📊 Phân loại câu hỏi
- **Lớp**: 10, 11, 12
- **Bài học**: Tên bài học cụ thể (ví dụ: "Bài 1: Chuyển động thẳng đều")
- **Dạng**: Lý thuyết, Bài tập, Ứng dụng, v.v.
- **Mức độ**: Nhận biết, Thông hiểu, Vận dụng, Vận dụng cao
- **Loại câu hỏi**: 
  - **MCQ**: Multiple Choice Question (Trắc nghiệm một lựa chọn)
  - **MSQ**: Multiple Select Question (Trắc nghiệm nhiều lựa chọn) 
  - **SA**: Short Answer (Câu hỏi ngắn)

### 📤 Xuất câu hỏi
- **Xuất file TXT**: Định dạng văn bản thuần túy
- **Xuất file Word**: Định dạng HTML tương thích với Microsoft Word
- **Chọn multiple**: Chọn nhiều câu hỏi để xuất cùng lúc
- **Định dạng đẹp**: File xuất có cấu trúc rõ ràng, dễ đọc

### 📥 Import hàng loạt
- **Import JSON**: Nhập câu hỏi từ file JSON
- **Validation**: Kiểm tra tính hợp lệ của dữ liệu
- **Báo cáo kết quả**: Thống kê số câu thành công/lỗi
- **Cấu trúc mẫu**: Có sẵn template JSON để tham khảo

## Cài đặt

### Yêu cầu hệ thống
- WordPress 5.0 trở lên
- PHP 7.4 trở lên
- MySQL 5.6 trở lên

### Cách cài đặt

1. **Upload plugin**:
   - Upload thư mục `quiz-bank-wp` vào `/wp-content/plugins/`
   - Hoặc upload file ZIP qua Admin Dashboard

2. **Kích hoạt plugin**:
   - Vào `Plugins` trong WordPress Admin
   - Tìm "Ngân hàng Trắc nghiệm" và click "Activate"

3. **Thiết lập quyền**:
   - Plugin tự động tạo bảng database
   - Cấp quyền `manage_quiz_bank` cho Administrator

## Sử dụng

### Thêm câu hỏi mới

1. Vào menu **Ngân hàng TN** > **Thêm mới**
2. Điền đầy đủ thông tin:
   - Lớp (10/11/12)
   - Bài học
   - Dạng câu hỏi
   - Loại câu hỏi
   - Nội dung câu hỏi
   - 4 đáp án A, B, C, D
   - Đáp án đúng
   - Giải thích (tùy chọn)
3. Click **Thêm câu hỏi**

### Quản lý câu hỏi

1. Vào menu **Ngân hàng TN** > **Danh sách**
2. Sử dụng bộ lọc để tìm câu hỏi
3. Click **Sửa** để chỉnh sửa
4. Click **Xóa** để xóa câu hỏi (có xác nhận)

### Xuất câu hỏi

1. Vào **Danh sách** câu hỏi
2. Sử dụng checkbox để chọn câu hỏi cần xuất
3. Click **Xuất TXT** hoặc **Xuất Word**
4. File sẽ được tải về tự động

### Import hàng loạt

1. **Chọn thông tin chung**:
   - Vào menu **Import**
   - Chọn lớp (10/11/12)
   - Nhập tên bài học
   - Tùy chọn: Nhập dạng câu hỏi

2. **Tạo file JSON theo cấu trúc mẫu**:

```json
{
  "questions": [
    {
      "type": "mcq",
      "question": "Trong các hàm số sau, hàm số nào đồng biến trên $\\mathbb{R}$?",
      "option_a": "$y=x^3-x$",
      "option_b": "$y=x^4$",
      "option_c": "$y=2x+1$",
      "option_d": "$y=\\frac{1}{x}$",
      "correct_option": "C",
      "muc_do": "Nhận biết",
      "explanation": "Giải thích..."
    },
    {
      "type": "msq",
      "question": "Chọn các phương án đúng:",
      "option_a": "Đáp án A",
      "option_b": "Đáp án B",
      "option_c": "Đáp án C",
      "option_d": "Đáp án D",
      "correct_option": "A,C",
      "muc_do": "Vận dụng"
    },
    {
      "type": "sa",
      "question": "Viết công thức tính diện tích hình tròn:",
      "correct_option": "S = πr²",
      "muc_do": "Nhận biết"
    }
  ]
}
```

3. **Upload và import**:
   - Chọn file JSON
   - Click **Import câu hỏi**
   - Kiểm tra kết quả import

## Cấu trúc thư mục

```
quiz-bank-wp/
├── quiz-bank.php              # File plugin chính
├── README.md                  # Tài liệu hướng dẫn
├── admin/                     # Giao diện quản trị
│   ├── questions-list.php     # Danh sách câu hỏi
│   ├── add-question.php       # Thêm câu hỏi
│   ├── edit-question.php      # Sửa câu hỏi
│   ├── import.php             # Import câu hỏi
│   └── guide.php              # Hướng dẫn sử dụng
├── includes/                  # Classes chính
│   ├── class-quiz-bank-database.php    # Xử lý database
│   ├── class-quiz-bank-admin.php       # Giao diện admin
│   ├── class-quiz-bank-export.php      # Xuất file
│   └── class-quiz-bank-import.php      # Import file
├── assets/                    # CSS & JavaScript
│   ├── css/
│   │   └── admin.css          # Style cho admin
│   └── js/
│       └── admin.js           # JavaScript cho admin
└── languages/                 # File ngôn ngữ
```

## Database Schema

Plugin tạo bảng `wp_quiz_bank_questions` với cấu trúc:

```sql
CREATE TABLE wp_quiz_bank_questions (
    id int(11) NOT NULL AUTO_INCREMENT,
    lop varchar(10) NOT NULL,
    bai_hoc varchar(255) NOT NULL,
    dang varchar(255) NOT NULL,
    loai varchar(100) NOT NULL,
    cau_hoi text NOT NULL,
    option_a text NOT NULL,
    option_b text NOT NULL,
    option_c text NOT NULL,
    option_d text NOT NULL,
    correct_option char(1) NOT NULL,
    explanation text,
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY lop (lop),
    KEY bai_hoc (bai_hoc),
    KEY dang (dang),
    KEY loai (loai)
);
```

## Hooks & Filters

### Actions
- `quiz_bank_question_added` - Sau khi thêm câu hỏi
- `quiz_bank_question_updated` - Sau khi cập nhật câu hỏi
- `quiz_bank_question_deleted` - Sau khi xóa câu hỏi

### Filters
- `quiz_bank_export_content` - Tùy chỉnh nội dung xuất
- `quiz_bank_import_validation` - Tùy chỉnh validation import

## Bảo mật

- ✅ Sử dụng WordPress nonces cho tất cả forms
- ✅ Sanitization và validation đầy đủ
- ✅ Escape output để tránh XSS
- ✅ Kiểm tra quyền user capabilities
- ✅ Prepared statements cho database queries

## Hiệu suất

- ✅ Database indexes cho tìm kiếm nhanh
- ✅ Pagination để giảm tải
- ✅ AJAX cho các thao tác không reload trang
- ✅ Lazy loading cho dropdown filters

## Xử lý lỗi thường gặp

### Lỗi import JSON
- Kiểm tra cú pháp JSON
- Đảm bảo có tất cả trường bắt buộc
- `correct_option` chỉ chấp nhận A, B, C, D

### Không xuất được file
- Kiểm tra quyền ghi thư mục `wp-content/uploads/`
- Đảm bảo đã chọn ít nhất 1 câu hỏi
- Kiểm tra dung lượng file không quá giới hạn

### Plugin không hoạt động
- Kiểm tra phiên bản WordPress và PHP
- Kiểm tra conflict với plugin khác
- Xem error log trong WordPress

## Changelog

### Version 1.0.0
- ✅ Quản lý câu hỏi CRUD đầy đủ
- ✅ Phân loại theo lớp, bài, dạng, loại
- ✅ Xuất file TXT và Word
- ✅ Import hàng loạt từ JSON
- ✅ Giao diện admin responsive
- ✅ Bảo mật và validation

## Support

Nếu gặp vấn đề khi sử dụng plugin:

1. Xem trang **Hướng dẫn** trong plugin
2. Kiểm tra [Documentation](./admin/guide.php)
3. Liên hệ admin hệ thống

## License

GPL v2 or later

## Credits

Developed by Quiz Bank Developer Team
WordPress Plugin Architecture following WordPress Coding Standards