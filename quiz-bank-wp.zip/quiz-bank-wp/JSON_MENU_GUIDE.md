# JSON Menu Configuration Guide

## 🎯 **Tổng quan (Overview)**

Hệ thống mới sử dụng file `menu.json` để quản lý tất cả danh mục một cách tập trung. Điều này giúp:
- ✅ **Dễ dàng chỉnh sửa** - Chỉ cần sửa 1 file JSON
- ✅ **Tập trung quản lý** - Tất cả cấu trúc ở 1 chỗ
- ✅ **Không cần code** - Không cần sửa JavaScript
- ✅ **Hỗ trợ đa lớp** - Dễ dàng thêm lớp 10, 11, 12

## 📁 **Cấu trúc File menu.json**

```json
{
  "grades": {
    "12": {
      "name": "Toán 12",
      "chapters": {
        "1": {
          "name": "Chương 1: Ứng dụng đạo hàm",
          "lessons": {
            "1": {
              "name": "Bài 1: Sự đồng biến, nghịch biến",
              "types": {
                "1": "Dạng 1: Xét tính đơn điệu",
                "2": "Dạng 2: Tìm khoảng đơn điệu",
                "3": "Dạng 3: Tham số m"
              }
            }
          }
        }
      }
    }
  },
  "categories": [
    "Nhận biết",
    "Thông hiểu", 
    "Vận dụng",
    "Vận dụng cao"
  ]
}
```

## 🔧 **Cách thêm/sửa danh mục**

### **1. Thêm Chương mới:**
```json
"chapters": {
  "1": {"name": "Chương 1: ...", "lessons": {...}},
  "2": {"name": "Chương 2: ...", "lessons": {...}},
  "4": {
    "name": "Chương 4: Tích phân",
    "lessons": {
      "1": {
        "name": "Bài 1: Nguyên hàm",
        "types": {
          "1": "Dạng 1: Nguyên hàm cơ bản",
          "2": "Dạng 2: Nguyên hàm từng phần"
        }
      }
    }
  }
}
```

### **2. Thêm Bài học mới:**
```json
"lessons": {
  "1": {"name": "Bài 1: ...", "types": {...}},
  "2": {"name": "Bài 2: ...", "types": {...}},
  "4": {
    "name": "Bài 4: Bài học mới",
    "types": {
      "1": "Dạng 1: Kiến thức cơ bản",
      "2": "Dạng 2: Bài tập nâng cao"
    }
  }
}
```

### **3. Thêm Dạng mới:**
```json
"types": {
  "1": "Dạng 1: Cơ bản",
  "2": "Dạng 2: Nâng cao", 
  "3": "Dạng 3: Ứng dụng",
  "4": "Dạng 4: Dạng mới thêm"
}
```

### **4. Thêm lớp mới (Lớp 10):**
```json
"grades": {
  "10": {
    "name": "Toán 10",
    "chapters": {
      "1": {
        "name": "Chương 1: Mệnh đề và tập hợp",
        "lessons": {
          "1": {
            "name": "Bài 1: Mệnh đề",
            "types": {
              "1": "Dạng 1: Xét tính đúng sai",
              "2": "Dạng 2: Mệnh đề phủ định"
            }
          }
        }
      }
    }
  },
  "11": {...},
  "12": {...}
}
```

## 🛠 **Tính năng mới đã implemented**

### **A. PHP Classes:**
- ✅ `QuizBankMenuConfig` - Class quản lý menu từ JSON
- ✅ Singleton pattern - Chỉ load 1 lần
- ✅ Error handling - Fallback nếu JSON lỗi
- ✅ Caching - Không load lại JSON nhiều lần

### **B. AJAX Handlers:**
- ✅ `get_menu_structure` - Lấy cấu trúc menu cho JavaScript
- ✅ Cập nhật `get_chapters`, `get_lessons`, `get_types` - Sử dụng JSON config
- ✅ Backward compatibility - Vẫn hoạt động với database cũ

### **C. JavaScript Updates:**
- ✅ Dynamic loading - Load menu structure từ server
- ✅ All forms updated - add-question.php, edit-question.php, import.php
- ✅ Better naming - Hiển thị tên đầy đủ thay vì chỉ số

## 📝 **Ví dụ thực tế**

### **Menu.json hoàn chỉnh cho 3 lớp:**
```json
{
  "grades": {
    "10": {
      "name": "Toán 10", 
      "chapters": {
        "1": {
          "name": "Chương 1: Mệnh đề và tập hợp",
          "lessons": {
            "1": {
              "name": "Bài 1: Mệnh đề",
              "types": {
                "1": "Dạng 1: Xét tính đúng sai",
                "2": "Dạng 2: Mệnh đề phủ định"
              }
            },
            "2": {
              "name": "Bài 2: Tập hợp", 
              "types": {
                "1": "Dạng 1: Các phép toán tập hợp",
                "2": "Dạng 2: Biểu diễn tập hợp"
              }
            }
          }
        }
      }
    },
    "11": {
      "name": "Toán 11",
      "chapters": {
        "1": {
          "name": "Chương 1: Hàm số lượng giác",
          "lessons": {
            "1": {
              "name": "Bài 1: Góc lượng giác",
              "types": {
                "1": "Dạng 1: Đổi đơn vị góc",
                "2": "Dạng 2: Góc có cùng tia cuối"
              }
            }
          }
        }
      }
    },
    "12": {
      "name": "Toán 12",
      "chapters": {
        "1": {
          "name": "Chương 1: Ứng dụng đạo hàm",
          "lessons": {
            "1": {
              "name": "Bài 1: Sự đồng biến, nghịch biến",
              "types": {
                "1": "Dạng 1: Xét tính đơn điệu",
                "2": "Dạng 2: Tìm khoảng đơn điệu",
                "3": "Dạng 3: Tham số m"
              }
            }
          }
        }
      }
    }
  },
  "categories": [
    "Nhận biết",
    "Thông hiểu", 
    "Vận dụng",
    "Vận dụng cao"
  ]
}
```

## 🚀 **Cách sử dụng**

### **1. Chỉnh sửa danh mục:**
- Mở file `menu.json`
- Chỉnh sửa theo cấu trúc JSON
- Lưu file
- Reload trang admin

### **2. Kiểm tra cấu trúc JSON:**
- Sử dụng JSON validator online
- Đảm bảo không có lỗi syntax
- Kiểm tra encoding UTF-8

### **3. Backup:**
- Luôn backup file `menu.json` trước khi sửa
- Git commit thay đổi

## ⚠️ **Lưu ý quan trọng**

1. **JSON Format:** File phải đúng chuẩn JSON (không comment, đúng syntax)
2. **UTF-8 Encoding:** Đảm bảo file được save với UTF-8
3. **ID Format:** Sử dụng string cho tất cả ID ("1", "2", "3")
4. **Backup:** Luôn backup trước khi thay đổi
5. **Testing:** Test trên dev environment trước

## 🎉 **Lợi ích**

- ✅ **Centralized Management** - Quản lý tập trung
- ✅ **Easy Updates** - Dễ dàng cập nhật
- ✅ **Multi-Grade Support** - Hỗ trợ đa lớp  
- ✅ **No Code Changes** - Không cần sửa code
- ✅ **Version Control** - Dễ dàng track changes
- ✅ **Scalable** - Dễ dàng mở rộng